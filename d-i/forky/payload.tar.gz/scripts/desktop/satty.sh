#!/bin/sh
# Pinned Satty release installation helpers. This file is sourced, not executed.

desktop_satty_fail() {
  rm -rf -- "${TARGET_ROOT}${satty_work_dir:-/tmp/invalid-satty-work-dir}" 2>__INSTALLER_PATH_DIR_DEV__/null || true
  installer_fatal "$*"
}

desktop_satty_validate_unsigned_integer() {
  satty_value_name=$1
  satty_value=$2

  case "$satty_value" in
    ''|*[!0-9]*)
      installer_fatal "${satty_value_name} must be an unsigned integer"
      ;;
  esac
}

desktop_satty_validate_policy() {
  : "${LABWC_SATTY_VERSION:?LABWC_SATTY_VERSION must be set}"
  : "${LABWC_SATTY_ARCHITECTURE:?LABWC_SATTY_ARCHITECTURE must be set}"
  : "${LABWC_SATTY_URL:?LABWC_SATTY_URL must be set}"
  : "${LABWC_SATTY_SHA256:?LABWC_SATTY_SHA256 must be set}"
  : "${LABWC_SATTY_GLIBC_VERSION:?LABWC_SATTY_GLIBC_VERSION must be set}"
  : "${LABWC_SATTY_GLIBC_ARCHITECTURE:?LABWC_SATTY_GLIBC_ARCHITECTURE must be set}"
  : "${LABWC_SATTY_GLIBC_LIBC6_SHA256:?LABWC_SATTY_GLIBC_LIBC6_SHA256 must be set}"
  : "${LABWC_SATTY_GLIBC_GCONV_SHA256:?LABWC_SATTY_GLIBC_GCONV_SHA256 must be set}"
  : "${LABWC_SATTY_GLIBC_RUNTIME_ROOT:?LABWC_SATTY_GLIBC_RUNTIME_ROOT must be set}"

  case "$LABWC_SATTY_VERSION" in
    *[!0-9.]*|.*|*.|*..*)
      installer_fatal "LABWC_SATTY_VERSION is invalid: ${LABWC_SATTY_VERSION}"
      ;;
  esac
  case "$LABWC_SATTY_ARCHITECTURE" in
    amd64) ;;
    *)
      installer_fatal "LABWC_SATTY_ARCHITECTURE is unsupported: ${LABWC_SATTY_ARCHITECTURE}"
      ;;
  esac
  case "$LABWC_SATTY_URL" in
    https://*/*) ;;
    *)
      installer_fatal "LABWC_SATTY_URL does not match the pinned Satty release contract"
      ;;
  esac
  case "$LABWC_SATTY_SHA256" in
    *[!0123456789abcdef]*|'')
      installer_fatal "LABWC_SATTY_SHA256 must contain lowercase hexadecimal characters"
      ;;
  esac
  [ "${#LABWC_SATTY_SHA256}" -eq 64 ] ||
    installer_fatal "LABWC_SATTY_SHA256 must contain 64 characters"

  printf '%s\n' "$LABWC_SATTY_GLIBC_VERSION" | grep -Eq '^[0-9]+\.[0-9]+-[0-9]+$' ||
    installer_fatal "LABWC_SATTY_GLIBC_VERSION must be a Debian package version"
  [ "$LABWC_SATTY_GLIBC_ARCHITECTURE" = amd64 ] ||
    installer_fatal "LABWC_SATTY_GLIBC_ARCHITECTURE must remain pinned to amd64"
  case "$LABWC_SATTY_GLIBC_LIBC6_SHA256" in
    *[!0123456789abcdef]*|'')
      installer_fatal "LABWC_SATTY_GLIBC_LIBC6_SHA256 must contain lowercase hexadecimal characters"
      ;;
  esac
  [ "${#LABWC_SATTY_GLIBC_LIBC6_SHA256}" -eq 64 ] ||
    installer_fatal "LABWC_SATTY_GLIBC_LIBC6_SHA256 must contain 64 characters"
  case "$LABWC_SATTY_GLIBC_GCONV_SHA256" in
    *[!0123456789abcdef]*|'')
      installer_fatal "LABWC_SATTY_GLIBC_GCONV_SHA256 must contain lowercase hexadecimal characters"
      ;;
  esac
  [ "${#LABWC_SATTY_GLIBC_GCONV_SHA256}" -eq 64 ] ||
    installer_fatal "LABWC_SATTY_GLIBC_GCONV_SHA256 must contain 64 characters"
  [ "$LABWC_SATTY_GLIBC_RUNTIME_ROOT" = "__INSTALLER_PATH_DIR_OPT__/glibc/${LABWC_SATTY_GLIBC_VERSION}/satty" ] ||
    installer_fatal "LABWC_SATTY_GLIBC_RUNTIME_ROOT must match LABWC_SATTY_GLIBC_VERSION"
}

desktop_satty_preflight_target_architecture() {
  desktop_satty_validate_policy

  SATTY_TARGET_ARCHITECTURE=$(capture_in_target "detect target architecture for Satty" __INSTALLER_PATH_DIR_USR_BIN__/dpkg --print-architecture)
  [ -n "$SATTY_TARGET_ARCHITECTURE" ] ||
    installer_fatal "target architecture detection returned no output before Satty installation"
  [ "$SATTY_TARGET_ARCHITECTURE" = "$LABWC_SATTY_ARCHITECTURE" ] ||
    installer_fatal "Satty ${LABWC_SATTY_VERSION} is pinned for ${LABWC_SATTY_ARCHITECTURE}, but the target architecture is ${SATTY_TARGET_ARCHITECTURE}"
}

desktop_satty_validate_private_deb() {
  satty_private_deb=$1
  satty_private_deb_host=$2
  satty_private_expected_package=$3
  satty_private_expected_version=$4
  satty_private_expected_architecture=$5
  satty_private_expected_sha256=$6

  [ -f "$satty_private_deb_host" ] && [ ! -L "$satty_private_deb_host" ] ||
    desktop_satty_fail "private Satty GLIBC download is missing package: ${satty_private_expected_package}"

  satty_private_deb_sha256=$(
    capture_in_target "hash private ${satty_private_expected_package} package" __INSTALLER_PATH_DIR_USR_BIN__/sha256sum "$satty_private_deb" |
      awk '{print $1}'
  )
  [ "$satty_private_deb_sha256" = "$satty_private_expected_sha256" ] ||
    desktop_satty_fail "downloaded ${satty_private_expected_package} package SHA-256 does not match the pinned Debian package"

  satty_private_package=$(capture_in_target "read private package name" __INSTALLER_PATH_DIR_USR_BIN__/dpkg-deb -f "$satty_private_deb" Package)
  satty_private_version=$(capture_in_target "read private package version" __INSTALLER_PATH_DIR_USR_BIN__/dpkg-deb -f "$satty_private_deb" Version)
  satty_private_architecture=$(capture_in_target "read private package architecture" __INSTALLER_PATH_DIR_USR_BIN__/dpkg-deb -f "$satty_private_deb" Architecture)
  [ "$satty_private_package" = "$satty_private_expected_package" ] ||
    desktop_satty_fail "downloaded private package has unexpected Package: ${satty_private_package:-unset}"
  [ "$satty_private_version" = "$satty_private_expected_version" ] ||
    desktop_satty_fail "downloaded ${satty_private_expected_package} package has unexpected Version: ${satty_private_version:-unset}"
  [ "$satty_private_architecture" = "$satty_private_expected_architecture" ] ||
    desktop_satty_fail "downloaded ${satty_private_expected_package} package has unexpected Architecture: ${satty_private_architecture:-unset}"

  SATTY_PRIVATE_PACKAGE_SHA256=$satty_private_deb_sha256
}

desktop_satty_download_private_deb() {
  satty_private_download_name=$1
  satty_private_download_url=$2
  satty_private_download_path=$3

  if ! attempt_in_target "download private Satty ${satty_private_download_name} package from Debian Snapshot" \
    __INSTALLER_PATH_DIR_USR_BIN__/env -i \
      HOME=__INSTALLER_PATH_DIR_ROOT_HOME__ \
      LC_ALL=C \
      PATH=__INSTALLER_PATH_DIR_USR_LOCAL__/sbin:__INSTALLER_PATH_DIR_USR_LOCAL__/bin:__INSTALLER_PATH_DIR_USR_SBIN__:__INSTALLER_PATH_DIR_USR_BIN__:__INSTALLER_PATH_DIR_SBIN__:__INSTALLER_PATH_DIR_BIN__ \
      __INSTALLER_PATH_DIR_USR_BIN__/curl \
        --fail \
        --silent \
        --show-error \
        --location \
        --proto '=https' \
        --proto-redir '=https' \
        --connect-timeout 15 \
        --max-time 180 \
        --max-redirs 4 \
        --retry 3 \
        --retry-all-errors \
            --user-agent 'unattended-installer-satty/1.0' \
        --header 'Accept: application/vnd.debian.binary-package, application/octet-stream;q=0.9, */*;q=0.1' \
        --output "$satty_private_download_path" \
        --url "$satty_private_download_url"
  then
    desktop_satty_fail "failed to download private Satty ${satty_private_download_name} package from Debian Snapshot"
  fi
}

desktop_satty_install_private_glibc() {
  satty_glibc_work_dir="${satty_work_dir}/glibc"
  satty_glibc_extract_dir="${satty_glibc_work_dir}/extract"
  satty_glibc_work_host="${TARGET_ROOT}${satty_glibc_work_dir}"
  satty_glibc_extract_host="${TARGET_ROOT}${satty_glibc_extract_dir}"
  satty_glibc_runtime_host="${TARGET_ROOT}${LABWC_SATTY_GLIBC_RUNTIME_ROOT}"
  satty_glibc_deb="${satty_glibc_work_dir}/libc6_${LABWC_SATTY_GLIBC_VERSION}_${LABWC_SATTY_GLIBC_ARCHITECTURE}.deb"
  satty_glibc_deb_host="${TARGET_ROOT}${satty_glibc_deb}"
  satty_glibc_gconv_deb="${satty_glibc_work_dir}/libc-gconv-modules-extra_${LABWC_SATTY_GLIBC_VERSION}_${LABWC_SATTY_GLIBC_ARCHITECTURE}.deb"
  satty_glibc_gconv_deb_host="${TARGET_ROOT}${satty_glibc_gconv_deb}"
  satty_glibc_snapshot_base=${LABWC_SATTY_GLIBC_SNAPSHOT_BASE_URL:?LABWC_SATTY_GLIBC_SNAPSHOT_BASE_URL must be set}
  satty_glibc_deb_url="${satty_glibc_snapshot_base}/libc6_${LABWC_SATTY_GLIBC_VERSION}_${LABWC_SATTY_GLIBC_ARCHITECTURE}.deb"
  satty_glibc_gconv_deb_url="${satty_glibc_snapshot_base}/libc-gconv-modules-extra_${LABWC_SATTY_GLIBC_VERSION}_${LABWC_SATTY_GLIBC_ARCHITECTURE}.deb"

  satty_libgcc_status=$(capture_in_target "check target libgcc runtime before private GLIBC installation" __INSTALLER_PATH_DIR_USR_BIN__/dpkg-query -W -f='${Status}' libgcc-s1)
  [ "$satty_libgcc_status" = "install ok installed" ] ||
    desktop_satty_fail "target libgcc-s1 runtime is not installed"

  install -d -m 0700 "$satty_glibc_work_host"
  desktop_satty_download_private_deb \
    libc6 \
    "$satty_glibc_deb_url" \
    "$satty_glibc_deb"
  desktop_satty_download_private_deb \
    libc-gconv-modules-extra \
    "$satty_glibc_gconv_deb_url" \
    "$satty_glibc_gconv_deb"

  desktop_satty_validate_private_deb \
    "$satty_glibc_deb" \
    "$satty_glibc_deb_host" \
    libc6 \
    "$LABWC_SATTY_GLIBC_VERSION" \
    "$LABWC_SATTY_GLIBC_ARCHITECTURE" \
    "$LABWC_SATTY_GLIBC_LIBC6_SHA256"
  satty_glibc_deb_sha256=$SATTY_PRIVATE_PACKAGE_SHA256

  desktop_satty_validate_private_deb \
    "$satty_glibc_gconv_deb" \
    "$satty_glibc_gconv_deb_host" \
    libc-gconv-modules-extra \
    "$LABWC_SATTY_GLIBC_VERSION" \
    "$LABWC_SATTY_GLIBC_ARCHITECTURE" \
    "$LABWC_SATTY_GLIBC_GCONV_SHA256"
  satty_glibc_gconv_deb_sha256=$SATTY_PRIVATE_PACKAGE_SHA256

  satty_glibc_depends=$(capture_in_target "read private libc6 dependencies" __INSTALLER_PATH_DIR_USR_BIN__/dpkg-deb -f "$satty_glibc_deb" Depends)
  case "$satty_glibc_depends" in
    *"libgcc-s1"*) ;;
    *) desktop_satty_fail "downloaded libc6 package no longer declares libgcc-s1" ;;
  esac
  case "$satty_glibc_depends" in
    *"libc-gconv-modules-extra (= ${LABWC_SATTY_GLIBC_VERSION})"*) ;;
    *) desktop_satty_fail "downloaded libc6 package has an unexpected gconv dependency: ${satty_glibc_depends}" ;;
  esac

  install -d -m 0700 "$satty_glibc_extract_host"
  if ! attempt_in_target "extract private Satty GLIBC runtime" \
    __INSTALLER_PATH_DIR_USR_BIN__/dpkg-deb -x "$satty_glibc_deb" "$satty_glibc_extract_dir"
  then
    desktop_satty_fail "failed to extract the private Satty GLIBC runtime"
  fi
  if ! attempt_in_target "extract private Satty GLIBC gconv modules" \
    __INSTALLER_PATH_DIR_USR_BIN__/dpkg-deb -x "$satty_glibc_gconv_deb" "$satty_glibc_extract_dir"
  then
    desktop_satty_fail "failed to extract the private Satty GLIBC gconv modules"
  fi

  satty_glibc_loader=
  for satty_glibc_loader_candidate in \
    "$satty_glibc_extract_host/usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2" \
    "$satty_glibc_extract_host/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2" \
    "$satty_glibc_extract_host/lib64/ld-linux-x86-64.so.2"
  do
    if [ -x "$satty_glibc_loader_candidate" ]; then
      satty_glibc_loader=$satty_glibc_loader_candidate
      break
    fi
  done
  [ -n "$satty_glibc_loader" ] ||
    desktop_satty_fail "extracted private GLIBC runtime is missing the amd64 loader"

  install -d -m 0755 ${TARGET_ROOT}${DIR_OPT}/glibc/2.44-1
  rm -rf -- "$satty_glibc_runtime_host"
  mv "$satty_glibc_extract_host" "$satty_glibc_runtime_host"
  chown -R root:root "$satty_glibc_runtime_host"
  chmod -R go-w "$satty_glibc_runtime_host"
  printf 'package=libc6\nversion=%s\narchitecture=%s\nlibc6_sha256=%s\ngconv_sha256=%s\n' \
    "$LABWC_SATTY_GLIBC_VERSION" \
    "$LABWC_SATTY_GLIBC_ARCHITECTURE" \
    "$satty_glibc_deb_sha256" \
    "$satty_glibc_gconv_deb_sha256" \
    >"${satty_glibc_runtime_host}/.release"
  chmod 0644 "${satty_glibc_runtime_host}/.release"
  SATTY_GLIBC_PACKAGE_SHA256=$satty_glibc_deb_sha256
  SATTY_GLIBC_GCONV_PACKAGE_SHA256=$satty_glibc_gconv_deb_sha256
}

desktop_install_satty() {
  [ -n "${SATTY_TARGET_ARCHITECTURE:-}" ] || desktop_satty_preflight_target_architecture
  target_architecture=$SATTY_TARGET_ARCHITECTURE

  satty_work_dir="/tmp/satty-install.$$"
  satty_archive="${satty_work_dir}/satty.tar.gz"
  satty_extract_dir="${satty_work_dir}/extract"
  satty_archive_host="${TARGET_ROOT}${satty_archive}"
  satty_extract_host="${TARGET_ROOT}${satty_extract_dir}"

  rm -rf -- "${TARGET_ROOT}${satty_work_dir}"
  install -d -m 0700 "$satty_extract_host"

  if ! attempt_in_target "download pinned Satty release" \
    __INSTALLER_PATH_DIR_USR_BIN__/env -i \
      HOME=__INSTALLER_PATH_DIR_ROOT_HOME__ \
      LC_ALL=C \
      PATH=__INSTALLER_PATH_DIR_USR_LOCAL__/sbin:__INSTALLER_PATH_DIR_USR_LOCAL__/bin:__INSTALLER_PATH_DIR_USR_SBIN__:__INSTALLER_PATH_DIR_USR_BIN__:__INSTALLER_PATH_DIR_SBIN__:__INSTALLER_PATH_DIR_BIN__ \
      __INSTALLER_PATH_DIR_USR_BIN__/curl \
        --fail \
        --silent \
        --show-error \
        --location \
        --proto '=https' \
        --proto-redir '=https' \
        --connect-timeout 15 \
        --max-time 180 \
        --max-redirs 8 \
        --retry 3 \
        --retry-all-errors \
        --user-agent 'unattended-installer-satty/1.0' \
        --header 'Accept: application/gzip, application/octet-stream;q=0.9, */*;q=0.1' \
        --output "$satty_archive" \
        --url "$LABWC_SATTY_URL"
  then
    desktop_satty_fail "Satty ${LABWC_SATTY_VERSION} download failed"
  fi

  [ -f "$satty_archive_host" ] && [ ! -L "$satty_archive_host" ] ||
    desktop_satty_fail "downloaded Satty archive is not a regular file"
  satty_archive_sha256=$(
    capture_in_target "hash downloaded Satty archive" __INSTALLER_PATH_DIR_USR_BIN__/sha256sum "$satty_archive" |
      awk '{print $1}'
  )
  [ "$satty_archive_sha256" = "$LABWC_SATTY_SHA256" ] ||
    desktop_satty_fail "downloaded Satty archive SHA-256 does not match the pinned release"

  satty_member_list=$(capture_in_target "list downloaded Satty archive" __INSTALLER_PATH_DIR_BIN__/tar -tzf "$satty_archive")
  if ! printf '%s\n' "$satty_member_list" |
    awk '
      /^\// { bad = 1 }
      /(^|\/)\.\.($|\/)/ { bad = 1 }
      END { exit bad ? 1 : 0 }
    '
  then
    desktop_satty_fail "downloaded Satty archive contains an unsafe member path"
  fi
  satty_verbose_member_list=$(capture_in_target "inspect downloaded Satty archive types" __INSTALLER_PATH_DIR_BIN__/tar -tvzf "$satty_archive")
  if ! printf '%s\n' "$satty_verbose_member_list" |
    awk '$1 !~ /^[-d]/ { bad = 1 } END { exit bad ? 1 : 0 }'
  then
    desktop_satty_fail "downloaded Satty archive contains unsupported member types"
  fi

  for satty_required_member in \
    ./LICENSE \
    ./README.md \
    ./assets/satty.svg \
    ./completions/_satty \
    ./completions/satty.bash \
    ./completions/satty.fish \
    ./man/satty.1 \
    ./satty \
    ./satty.desktop
  do
    printf '%s\n' "$satty_member_list" | grep -Fqx "$satty_required_member" ||
      desktop_satty_fail "downloaded Satty archive is missing ${satty_required_member}"
  done

  if ! attempt_in_target "extract pinned Satty archive" \
    __INSTALLER_PATH_DIR_BIN__/tar \
      --no-same-owner \
      --no-same-permissions \
      -xzf "$satty_archive" \
      -C "$satty_extract_dir"
  then
    desktop_satty_fail "failed to extract the pinned Satty archive"
  fi

  [ -x "$satty_extract_host/satty" ] ||
    desktop_satty_fail "extracted Satty binary is not executable"
  satty_file_type=$(capture_in_target "inspect extracted Satty binary" __INSTALLER_PATH_DIR_USR_BIN__/file -b "${satty_extract_dir}/satty")
  case "$satty_file_type" in
    *"ELF 64-bit"*"x86-64"*) ;;
    *)
      desktop_satty_fail "extracted Satty binary has an unexpected file type: ${satty_file_type:-unset}"
      ;;
  esac

  install -d -m 0755 \
    ${TARGET_ROOT}${DIR_USR_LOCAL_LIBEXEC}/satty \
    ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/applications \
    ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/bash-completion/completions \
    ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/doc/satty \
    ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/fish/vendor_completions.d \
    ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/man/man1 \
    ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/satty/completions \
    ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/zsh/site-functions \
    ${TARGET_ROOT}${DIR_USR_SHARE}/icons/hicolor/scalable/apps
  install -m 0755 "$satty_extract_host/satty" ${TARGET_ROOT}${DIR_USR_LOCAL_LIBEXEC}/satty/satty
  install -m 0644 "$satty_extract_host/satty.desktop" ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/applications/satty.desktop
  install -m 0644 "$satty_extract_host/assets/satty.svg" ${TARGET_ROOT}${DIR_USR_SHARE}/icons/hicolor/scalable/apps/satty.svg
  install -m 0644 "$satty_extract_host/man/satty.1" ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/man/man1/satty.1
  install -m 0644 "$satty_extract_host/completions/satty.bash" ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/bash-completion/completions/satty
  install -m 0644 "$satty_extract_host/completions/_satty" ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/zsh/site-functions/_satty
  install -m 0644 "$satty_extract_host/completions/satty.fish" ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/fish/vendor_completions.d/satty.fish
  install -m 0644 "$satty_extract_host"/completions/* ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/satty/completions/
  install -m 0644 "$satty_extract_host/LICENSE" ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/doc/satty/LICENSE
  install -m 0644 "$satty_extract_host/README.md" ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/doc/satty/README.md

  desktop_satty_install_private_glibc
  desktop_stage_role_asset FILE_TARGET_BIN_SATTY __INSTALLER_PATH_DIR_USR_LOCAL__/bin/satty 0755

  printf 'version=%s\nurl=%s\narchive_sha256=%s\nglibc_version=%s\nglibc_package_sha256=%s\nglibc_gconv_package_sha256=%s\n' \
    "$LABWC_SATTY_VERSION" \
    "$LABWC_SATTY_URL" \
    "$LABWC_SATTY_SHA256" \
    "$LABWC_SATTY_GLIBC_VERSION" \
    "$SATTY_GLIBC_PACKAGE_SHA256" \
    "$SATTY_GLIBC_GCONV_PACKAGE_SHA256" \
    >${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/satty/release
  chmod 0644 ${TARGET_ROOT}${DIR_USR_LOCAL_SHARE}/satty/release

  run_in_target "refresh Satty desktop metadata" __INSTALLER_PATH_DIR_BIN__/sh -eu -c '
__INSTALLER_PATH_DIR_USR_BIN__/update-desktop-database __INSTALLER_PATH_DIR_USR_LOCAL__/share/applications
if command -v gtk-update-icon-cache >__INSTALLER_PATH_DIR_DEV__/null 2>&1; then
  gtk-update-icon-cache -f -q __INSTALLER_PATH_DIR_USR_SHARE__/icons/hicolor
fi
' sh

  rm -rf -- "${TARGET_ROOT}${satty_work_dir}"
  desktop_log "installed_satty version=${LABWC_SATTY_VERSION} architecture=${target_architecture} archive_sha256=${LABWC_SATTY_SHA256} private_glibc=${LABWC_SATTY_GLIBC_VERSION} glibc_package_sha256=${SATTY_GLIBC_PACKAGE_SHA256} glibc_gconv_package_sha256=${SATTY_GLIBC_GCONV_PACKAGE_SHA256}"
}
