#!/bin/sh
# Btrfs-family runtime layout helpers.
# shellcheck disable=SC2034

if [ "${RUNTIME_COMMON_READY:-0}" != 1 ]; then
  if [ -n "${RUNTIME_COMMON_LIB:-}" ] && [ -r "$RUNTIME_COMMON_LIB" ]; then
    # shellcheck disable=SC1090
    . "$RUNTIME_COMMON_LIB" || return "$?"
  else
    echo "fatal: runtime common helper is unavailable; set RUNTIME_COMMON_LIB before sourcing ${0##*/}" >&2
    exit 1
  fi
fi

RUNTIME_RECIPE_TEMPLATES="btrfs-01.recipe.tmpl btrfs-02.recipe.tmpl btrfs-03.recipe.tmpl btrfs-04.recipe.tmpl btrfs-05.recipe.tmpl btrfs-06.recipe.tmpl btrfs-home-native.recipe.tmpl btrfs-home-reserved.recipe.tmpl"

runtime_secure_boot_state_mode() {
  secure_boot_mode=${SECURE_BOOT_MODE:-}
  secure_boot_state_mode=${SECURE_BOOT_STATE_MODE:-}
  if [ -n "$secure_boot_mode" ] && [ -n "$secure_boot_state_mode" ] && [ "$secure_boot_mode" != "$secure_boot_state_mode" ]; then
    runtime_fatal "SECURE_BOOT_MODE and SECURE_BOOT_STATE_MODE disagree: '${secure_boot_mode}' != '${secure_boot_state_mode}'"
    return 1
  fi
  mode=${secure_boot_mode:-${secure_boot_state_mode:-luks}}
  case "$mode" in
    luks|direct)
      printf '%s\n' "$mode"
      ;;
    *)
      runtime_fatal "SECURE_BOOT_MODE/SECURE_BOOT_STATE_MODE must be 'luks' or 'direct', got '${mode}'"
      return 1
      ;;
  esac
}

runtime_crypto_answers_required() {
  runtime_any_crypto_enabled || [ "$(runtime_secure_boot_state_mode)" = "luks" ]
}

runtime_sum_preserved_partition_sizes_mb() {
  # Disk-coordinate extent includes gaps and all prior operating systems.
  printf '%s\n' "${RUNTIME_EXISTING_END_MB:-0}"
}

runtime_compute_layout_sizing() {
  if [ "${RUNTIME_PARTITION_MODE:-fresh}" = reuse ]; then
    runtime_apply_reuse_sizing
    return "$?"
  fi
  runtime_validate_partition_sizes

  disk_total_mb=$(runtime_policy_disk_budget_mb)
  ram_total_mib=$(runtime_total_ram_mib)
  preserved_total_mb=$(runtime_sum_preserved_partition_sizes_mb)

  runtime_require_positive_integer SIZE_LAYOUT_SAFETY_MARGIN_MB "${SIZE_LAYOUT_SAFETY_MARGIN_MB:-}"
  usable_budget_mb=$((disk_total_mb - preserved_total_mb - SIZE_LAYOUT_SAFETY_MARGIN_MB))
  if [ "$usable_budget_mb" -le 0 ]; then
    runtime_fatal "usable install budget on ${DEV_INSTALL_DISK} collapsed to ${usable_budget_mb} MB after preserved partitions and safety margin"
  fi

  runtime_require_positive_integer SIZE_PART_ROOT_TARGET_MB "${SIZE_PART_ROOT_TARGET_MB:-}"
  runtime_require_positive_integer SIZE_PART_HOME_TARGET_MB "${SIZE_PART_HOME_TARGET_MB:-}"
  runtime_require_positive_integer SIZE_PART_OPT_TARGET_MB "${SIZE_PART_OPT_TARGET_MB:-}"
  runtime_require_positive_integer SIZE_PART_DATA_TARGET_MB "${SIZE_PART_DATA_TARGET_MB:-}"
  runtime_require_positive_integer SIZE_PART_POOL_TARGET_MB "${SIZE_PART_POOL_TARGET_MB:-$SIZE_PART_POOL_MB}"
  runtime_require_positive_integer SIZE_PART_VAR_TMP_TARGET_MB "${SIZE_PART_VAR_TMP_TARGET_MB:-}"
  raw_zram_mb=$(runtime_compute_raw_zram_partition_mb "$usable_budget_mb" "$usable_budget_mb")
  SWAP_SIZE_MIB=$(runtime_compute_swap_partition_mib "$usable_budget_mb" "$ram_total_mib")
  DEV_PART_RAW_SWAP_MB=$(runtime_mib_to_recipe_mb SWAP_SIZE_MIB "$SWAP_SIZE_MIB")

  if [ "${DUALBOOT_ENABLED:-false}" = "true" ]; then
    DEV_PART_EFI_MB=$(runtime_get_partition_size_mb "$RUNTIME_EFI_SLOT") || \
      runtime_fatal "missing measured EFI partition size for dual-boot slot ${RUNTIME_EFI_SLOT}"
    efi_recipe_mb=0
  else
    DEV_PART_EFI_MB=$SIZE_PART_EFI_MB
    efi_recipe_mb=$DEV_PART_EFI_MB
  fi

  DEV_PART_BOOT_MB=$SIZE_PART_BOOT_MB
  DEV_PART_ROOT_MB=$SIZE_PART_ROOT_MB
  DEV_PART_HOME_MB=$SIZE_PART_HOME_MB
  DEV_PART_OPT_MB=$SIZE_PART_OPT_MB
  DEV_PART_DATA_MB=$SIZE_PART_DATA_MB
  DEV_PART_POOL_MB=$SIZE_PART_POOL_MB
  DEV_PART_VAR_TMP_MB=$SIZE_PART_VAR_TMP_MB
  DEV_PART_VAR_LIB_SHSIGNED_MB=$SIZE_PART_VAR_LIB_SHSIGNED_MB
  DEV_PART_VAR_LOG_JOURNAL_MB=$SIZE_PART_VAR_LOG_JOURNAL_MB
  DEV_PART_RAW_ZRAM_MB=$raw_zram_mb

  [ "$SIZE_PART_ROOT_TARGET_MB" -ge "$DEV_PART_ROOT_MB" ] || runtime_fatal "SIZE_PART_ROOT_TARGET_MB must be >= SIZE_PART_ROOT_MB"
  [ "$SIZE_PART_HOME_TARGET_MB" -ge "$DEV_PART_HOME_MB" ] || runtime_fatal "SIZE_PART_HOME_TARGET_MB must be >= SIZE_PART_HOME_MB"
  [ "$SIZE_PART_OPT_TARGET_MB" -ge "$DEV_PART_OPT_MB" ] || runtime_fatal "SIZE_PART_OPT_TARGET_MB must be >= SIZE_PART_OPT_MB"
  [ "$SIZE_PART_DATA_TARGET_MB" -ge "$DEV_PART_DATA_MB" ] || runtime_fatal "SIZE_PART_DATA_TARGET_MB must be >= SIZE_PART_DATA_MB"
  [ "${SIZE_PART_POOL_TARGET_MB:-$SIZE_PART_POOL_MB}" -ge "$DEV_PART_POOL_MB" ] || runtime_fatal "SIZE_PART_POOL_TARGET_MB must be >= SIZE_PART_POOL_MB"
  [ "$SIZE_PART_VAR_TMP_TARGET_MB" -ge "$DEV_PART_VAR_TMP_MB" ] || runtime_fatal "SIZE_PART_VAR_TMP_TARGET_MB must be >= SIZE_PART_VAR_TMP_MB"

  base_total_mb=$((efi_recipe_mb + DEV_PART_BOOT_MB + DEV_PART_ROOT_MB + DEV_PART_HOME_MB + DEV_PART_OPT_MB + DEV_PART_DATA_MB + DEV_PART_POOL_MB + DEV_PART_VAR_TMP_MB + DEV_PART_VAR_LIB_SHSIGNED_MB + DEV_PART_VAR_LOG_JOURNAL_MB + DEV_PART_RAW_SWAP_MB + DEV_PART_RAW_ZRAM_MB))
  if [ "$base_total_mb" -gt "$usable_budget_mb" ]; then
    overflow_mb=$((base_total_mb - usable_budget_mb))

    pool_floor_mb=$(runtime_min "$DEV_PART_POOL_MB" "${SIZE_PART_POOL_MIN_MB:-1024}")
    data_floor_mb=$(runtime_min "$DEV_PART_DATA_MB" "${SIZE_PART_DATA_MIN_MB:-1024}")
    home_floor_mb=$(runtime_min "$DEV_PART_HOME_MB" "${SIZE_PART_HOME_MIN_MB:-1024}")
    opt_floor_mb=$(runtime_min "$DEV_PART_OPT_MB" "${SIZE_PART_OPT_MIN_MB:-512}")
    var_tmp_floor_mb=$(runtime_min "$DEV_PART_VAR_TMP_MB" "${SIZE_PART_VAR_TMP_MIN_MB:-512}")
    var_log_journal_floor_mb=$(runtime_min "$DEV_PART_VAR_LOG_JOURNAL_MB" "${SIZE_PART_VAR_LOG_JOURNAL_MIN_MB:-256}")
    boot_floor_mb=$(runtime_min "$DEV_PART_BOOT_MB" "${SIZE_PART_BOOT_MIN_MB:-512}")
    root_floor_mb=$(runtime_min "$DEV_PART_ROOT_MB" "${SIZE_PART_ROOT_MIN_MB:-4096}")
    if [ "${DUALBOOT_ENABLED:-false}" = true ]; then
      efi_floor_mb=$DEV_PART_EFI_MB
    else
      efi_floor_mb=$(runtime_min "$DEV_PART_EFI_MB" "${SIZE_PART_EFI_MIN_MB:-256}")
    fi

    runtime_apply_fill_result DEV_PART_POOL_MB overflow_mb \
      "$(runtime_shrink_partition_to_floor "$DEV_PART_POOL_MB" "$pool_floor_mb" "$overflow_mb")"
    runtime_apply_fill_result DEV_PART_DATA_MB overflow_mb \
      "$(runtime_shrink_partition_to_floor "$DEV_PART_DATA_MB" "$data_floor_mb" "$overflow_mb")"
    runtime_apply_fill_result DEV_PART_HOME_MB overflow_mb \
      "$(runtime_shrink_partition_to_floor "$DEV_PART_HOME_MB" "$home_floor_mb" "$overflow_mb")"
    runtime_apply_fill_result DEV_PART_OPT_MB overflow_mb \
      "$(runtime_shrink_partition_to_floor "$DEV_PART_OPT_MB" "$opt_floor_mb" "$overflow_mb")"
    runtime_apply_fill_result DEV_PART_VAR_TMP_MB overflow_mb \
      "$(runtime_shrink_partition_to_floor "$DEV_PART_VAR_TMP_MB" "$var_tmp_floor_mb" "$overflow_mb")"
    runtime_apply_fill_result DEV_PART_VAR_LOG_JOURNAL_MB overflow_mb \
      "$(runtime_shrink_partition_to_floor "$DEV_PART_VAR_LOG_JOURNAL_MB" "$var_log_journal_floor_mb" "$overflow_mb")"
    if [ "${DUALBOOT_ENABLED:-false}" != true ]; then
      runtime_apply_fill_result DEV_PART_EFI_MB overflow_mb \
        "$(runtime_shrink_partition_to_floor "$DEV_PART_EFI_MB" "$efi_floor_mb" "$overflow_mb")"
      efi_recipe_mb=$DEV_PART_EFI_MB
    fi
    runtime_apply_fill_result DEV_PART_BOOT_MB overflow_mb \
      "$(runtime_shrink_partition_to_floor "$DEV_PART_BOOT_MB" "$boot_floor_mb" "$overflow_mb")"
    runtime_apply_fill_result DEV_PART_ROOT_MB overflow_mb \
      "$(runtime_shrink_partition_to_floor "$DEV_PART_ROOT_MB" "$root_floor_mb" "$overflow_mb")"

    base_total_mb=$((efi_recipe_mb + DEV_PART_BOOT_MB + DEV_PART_ROOT_MB + DEV_PART_HOME_MB + DEV_PART_OPT_MB + DEV_PART_DATA_MB + DEV_PART_POOL_MB + DEV_PART_VAR_TMP_MB + DEV_PART_VAR_LIB_SHSIGNED_MB + DEV_PART_VAR_LOG_JOURNAL_MB + DEV_PART_RAW_SWAP_MB + DEV_PART_RAW_ZRAM_MB))
  fi
  if [ "$base_total_mb" -gt "$usable_budget_mb" ]; then
    runtime_fatal "disk budget ${usable_budget_mb} MB is too small for the minimum Debian layout (${base_total_mb} MB)"
  fi

  elastic_budget_mb=$((usable_budget_mb - base_total_mb))

  runtime_apply_fill_result DEV_PART_ROOT_MB elastic_budget_mb \
    "$(runtime_fill_partition_to_target "$DEV_PART_ROOT_MB" "$SIZE_PART_ROOT_TARGET_MB" "$elastic_budget_mb")"

  runtime_apply_fill_result DEV_PART_HOME_MB elastic_budget_mb \
    "$(runtime_fill_partition_to_target "$DEV_PART_HOME_MB" "$SIZE_PART_HOME_TARGET_MB" "$elastic_budget_mb")"

  runtime_apply_fill_result DEV_PART_OPT_MB elastic_budget_mb \
    "$(runtime_fill_partition_to_target "$DEV_PART_OPT_MB" "$SIZE_PART_OPT_TARGET_MB" "$elastic_budget_mb")"

  runtime_apply_fill_result DEV_PART_VAR_TMP_MB elastic_budget_mb \
    "$(runtime_fill_partition_to_target "$DEV_PART_VAR_TMP_MB" "$SIZE_PART_VAR_TMP_TARGET_MB" "$elastic_budget_mb")"

  runtime_apply_fill_result DEV_PART_DATA_MB elastic_budget_mb \
    "$(runtime_fill_partition_to_target "$DEV_PART_DATA_MB" "$SIZE_PART_DATA_TARGET_MB" "$elastic_budget_mb")"

  runtime_apply_fill_result DEV_PART_POOL_MB elastic_budget_mb \
    "$(runtime_fill_partition_to_target "$DEV_PART_POOL_MB" "${SIZE_PART_POOL_TARGET_MB:-$SIZE_PART_POOL_MB}" "$elastic_budget_mb")"

  DEV_PART_ROOT_MB=$((DEV_PART_ROOT_MB + elastic_budget_mb))

  RUNTIME_DISK_TOTAL_MB=$disk_total_mb
  RUNTIME_LAYOUT_SAFETY_MARGIN_MB=$SIZE_LAYOUT_SAFETY_MARGIN_MB
  RUNTIME_PRESERVED_TOTAL_MB=$preserved_total_mb
  RUNTIME_USABLE_BUDGET_MB=$usable_budget_mb
  RUNTIME_BASE_LAYOUT_MB=$base_total_mb
  RUNTIME_INSTALL_RAM_MIB=$ram_total_mib
}

runtime_modules_load_file_has_denied_modules() {
  denylist=$1
  src=$2
  [ -r "$src" ] || return 1
  while IFS= read -r line || [ -n "$line" ]; do
    line=$(printf '%s' "$line" | sed 's/[[:space:]]*#.*$//; s/^[[:space:]]*//; s/[[:space:]]*$//')
    [ -n "$line" ] || continue
    module_name=${line%%[[:space:]]*}
    case " $denylist " in
      *" ${module_name} "*) return 0 ;;
    esac
  done <"$src"
  return 1
}

runtime_filter_modules_load_file() {
  denylist=$1
  src=$2
  dest=$3
  [ -r "$src" ] || runtime_fatal "modules-load file is not readable: ${src}"

  install -d -m 0755 "$(dirname "$dest")"
  tmp="${dest}.tmp.$$"
  : >"$tmp"
  while IFS= read -r line || [ -n "$line" ]; do
    trimmed_line=$(printf '%s' "$line" | sed 's/[[:space:]]*#.*$//; s/^[[:space:]]*//; s/[[:space:]]*$//')
    if [ -n "$trimmed_line" ]; then
      module_name=${trimmed_line%%[[:space:]]*}
      case " $denylist " in
        *" ${module_name} "*) continue ;;
      esac
    fi
    printf '%s\n' "$line" >>"$tmp" || {
      rm -f "$tmp"
      runtime_fatal "failed to filter modules-load file: ${src}"
    }
  done <"$src"

  install -m 0644 "$tmp" "$dest"
  rm -f "$tmp"
}

runtime_validate_partition_sizes() {
  runtime_require_positive_integer DEV_PART_EFI_MB "${DEV_PART_EFI_MB:-}"
  runtime_require_positive_integer DEV_PART_BOOT_MB "${DEV_PART_BOOT_MB:-}"
  runtime_require_positive_integer DEV_PART_ROOT_MB "${DEV_PART_ROOT_MB:-}"
  runtime_require_positive_integer DEV_PART_HOME_MB "${DEV_PART_HOME_MB:-}"
  runtime_require_positive_integer DEV_PART_OPT_MB "${DEV_PART_OPT_MB:-}"
  runtime_require_positive_integer DEV_PART_DATA_MB "${DEV_PART_DATA_MB:-}"
  runtime_require_positive_integer DEV_PART_POOL_MB "${DEV_PART_POOL_MB:-}"
  runtime_require_positive_integer DEV_PART_VAR_TMP_MB "${DEV_PART_VAR_TMP_MB:-}"
  runtime_require_positive_integer DEV_PART_VAR_LIB_SHSIGNED_MB "${DEV_PART_VAR_LIB_SHSIGNED_MB:-}"
  runtime_require_positive_integer DEV_PART_VAR_LOG_JOURNAL_MB "${DEV_PART_VAR_LOG_JOURNAL_MB:-}"
  runtime_require_positive_integer DEV_PART_RAW_SWAP_MB "${DEV_PART_RAW_SWAP_MB:-}"
  runtime_require_positive_integer DEV_PART_RAW_ZRAM_MB "${DEV_PART_RAW_ZRAM_MB:-}"
}

runtime_load_default_slots_from_env() {
  if [ -n "${DEFAULT_EFI_SLOT:-}" ]; then
    runtime_require_positive_integer DEFAULT_EFI_SLOT "$DEFAULT_EFI_SLOT"
  else
    DEFAULT_EFI_SLOT=$(runtime_partition_slot_from_path DEV_PART_EFI "${DEV_PART_EFI}")
  fi
  if [ -n "${DEFAULT_BOOT_SLOT:-}" ]; then
    runtime_require_positive_integer DEFAULT_BOOT_SLOT "$DEFAULT_BOOT_SLOT"
  else
    DEFAULT_BOOT_SLOT=$(runtime_partition_slot_from_path DEV_PART_BOOT "${DEV_PART_BOOT}")
  fi
  if [ -n "${DEFAULT_ROOT_SLOT:-}" ]; then
    runtime_require_positive_integer DEFAULT_ROOT_SLOT "$DEFAULT_ROOT_SLOT"
  else
    DEFAULT_ROOT_SLOT=$(runtime_partition_slot_from_path DEV_PART_ROOT "${DEV_PART_ROOT}")
  fi
  if [ -n "${DEFAULT_HOME_SLOT:-}" ]; then
    runtime_require_positive_integer DEFAULT_HOME_SLOT "$DEFAULT_HOME_SLOT"
  else
    DEFAULT_HOME_SLOT=$(runtime_partition_slot_from_path DEV_PART_HOME "${DEV_PART_HOME}")
  fi
  if [ -n "${DEFAULT_OPT_SLOT:-}" ]; then
    runtime_require_positive_integer DEFAULT_OPT_SLOT "$DEFAULT_OPT_SLOT"
  else
    DEFAULT_OPT_SLOT=$(runtime_partition_slot_from_path DEV_PART_OPT "${DEV_PART_OPT}")
  fi
  if [ -n "${DEFAULT_DATA_SLOT:-}" ]; then
    runtime_require_positive_integer DEFAULT_DATA_SLOT "$DEFAULT_DATA_SLOT"
  else
    DEFAULT_DATA_SLOT=$(runtime_partition_slot_from_path DEV_PART_DATA "${DEV_PART_DATA}")
  fi
  if [ -n "${DEFAULT_POOL_SLOT:-}" ]; then
    runtime_require_positive_integer DEFAULT_POOL_SLOT "$DEFAULT_POOL_SLOT"
  else
    DEFAULT_POOL_SLOT=$(runtime_partition_slot_from_path DEV_PART_POOL "${DEV_PART_POOL}")
  fi
  if [ -n "${DEFAULT_VAR_TMP_SLOT:-}" ]; then
    runtime_require_positive_integer DEFAULT_VAR_TMP_SLOT "$DEFAULT_VAR_TMP_SLOT"
  else
    DEFAULT_VAR_TMP_SLOT=$(runtime_partition_slot_from_path DEV_PART_VAR_TMP "${DEV_PART_VAR_TMP}")
  fi
  if [ -n "${DEFAULT_VAR_LIB_SHSIGNED_SLOT:-}" ]; then
    runtime_require_positive_integer DEFAULT_VAR_LIB_SHSIGNED_SLOT "$DEFAULT_VAR_LIB_SHSIGNED_SLOT"
  else
    DEFAULT_VAR_LIB_SHSIGNED_SLOT=$(runtime_partition_slot_from_path DEV_PART_VAR_LIB_SHSIGNED "${DEV_PART_VAR_LIB_SHSIGNED}")
  fi
  if [ -n "${DEFAULT_VAR_LOG_JOURNAL_SLOT:-}" ]; then
    runtime_require_positive_integer DEFAULT_VAR_LOG_JOURNAL_SLOT "$DEFAULT_VAR_LOG_JOURNAL_SLOT"
  else
    DEFAULT_VAR_LOG_JOURNAL_SLOT=$(runtime_partition_slot_from_path DEV_PART_VAR_LOG_JOURNAL "${DEV_PART_VAR_LOG_JOURNAL}")
  fi
  if [ -n "${DEFAULT_RAW_SWAP_SLOT:-}" ]; then
    runtime_require_positive_integer DEFAULT_RAW_SWAP_SLOT "$DEFAULT_RAW_SWAP_SLOT"
  else
    DEFAULT_RAW_SWAP_SLOT=$(runtime_partition_slot_from_path DEV_PART_RAW_SWAP "${DEV_PART_RAW_SWAP}")
  fi
  if [ -n "${DEFAULT_RAW_ZRAM_SLOT:-}" ]; then
    runtime_require_positive_integer DEFAULT_RAW_ZRAM_SLOT "$DEFAULT_RAW_ZRAM_SLOT"
  else
    DEFAULT_RAW_ZRAM_SLOT=$(runtime_partition_slot_from_path DEV_PART_RAW_ZRAM "${DEV_PART_RAW_ZRAM}")
  fi

  if [ "$DEFAULT_EFI_SLOT" -ge "$DEFAULT_BOOT_SLOT" ] || \
     [ "$DEFAULT_BOOT_SLOT" -ge "$DEFAULT_ROOT_SLOT" ] || \
     [ "$DEFAULT_ROOT_SLOT" -ge "$DEFAULT_HOME_SLOT" ] || \
     [ "$DEFAULT_HOME_SLOT" -ge "$DEFAULT_OPT_SLOT" ] || \
     [ "$DEFAULT_OPT_SLOT" -ge "$DEFAULT_DATA_SLOT" ] || \
     [ "$DEFAULT_DATA_SLOT" -ge "$DEFAULT_POOL_SLOT" ] || \
     [ "$DEFAULT_POOL_SLOT" -ge "$DEFAULT_VAR_TMP_SLOT" ] || \
     [ "$DEFAULT_VAR_TMP_SLOT" -ge "$DEFAULT_VAR_LIB_SHSIGNED_SLOT" ] || \
     [ "$DEFAULT_VAR_LIB_SHSIGNED_SLOT" -ge "$DEFAULT_VAR_LOG_JOURNAL_SLOT" ] || \
     [ "$DEFAULT_VAR_LOG_JOURNAL_SLOT" -ge "$DEFAULT_RAW_SWAP_SLOT" ] || \
     [ "$DEFAULT_RAW_SWAP_SLOT" -ge "$DEFAULT_RAW_ZRAM_SLOT" ]
  then
    runtime_fatal "Btrfs default slot numbering must stay strictly increasing from EFI through raw zram backing"
  fi
}

runtime_assign_default_slots() {
  DUALBOOT_ENABLED=false
  DUALBOOT_EFI_SLOT=
  DUALBOOT_DEBIAN_SLOT=
  RUNTIME_PRESERVED_SLOTS=
  RUNTIME_EFI_SLOT=$DEFAULT_EFI_SLOT
  RUNTIME_BOOT_SLOT=$DEFAULT_BOOT_SLOT
  RUNTIME_ROOT_SLOT=$DEFAULT_ROOT_SLOT
  RUNTIME_HOME_SLOT=$DEFAULT_HOME_SLOT
  RUNTIME_OPT_SLOT=$DEFAULT_OPT_SLOT
  RUNTIME_DATA_SLOT=$DEFAULT_DATA_SLOT
  RUNTIME_POOL_SLOT=$DEFAULT_POOL_SLOT
  RUNTIME_VAR_TMP_SLOT=$DEFAULT_VAR_TMP_SLOT
  RUNTIME_VAR_LIB_SHSIGNED_SLOT=$DEFAULT_VAR_LIB_SHSIGNED_SLOT
  RUNTIME_VAR_LOG_JOURNAL_SLOT=$DEFAULT_VAR_LOG_JOURNAL_SLOT
  RUNTIME_RAW_SWAP_SLOT=$DEFAULT_RAW_SWAP_SLOT
  RUNTIME_RAW_ZRAM_SLOT=$DEFAULT_RAW_ZRAM_SLOT
}

runtime_assign_dualboot_slots() {
  DUALBOOT_ENABLED=true
  RUNTIME_EFI_SLOT=$RUNTIME_DETECTED_EFI_SLOT
  DUALBOOT_EFI_SLOT=$RUNTIME_EFI_SLOT
  layout_offset=0
    RUNTIME_BOOT_SLOT=$(runtime_policy_slot "$layout_offset") || runtime_fatal 'not enough GPT partition numbers for the complete layout'
    layout_offset=$((layout_offset + 1))
    RUNTIME_ROOT_SLOT=$(runtime_policy_slot "$layout_offset") || runtime_fatal 'not enough GPT partition numbers for the complete layout'
    layout_offset=$((layout_offset + 1))
    RUNTIME_HOME_SLOT=$(runtime_policy_slot "$layout_offset") || runtime_fatal 'not enough GPT partition numbers for the complete layout'
    layout_offset=$((layout_offset + 1))
    RUNTIME_OPT_SLOT=$(runtime_policy_slot "$layout_offset") || runtime_fatal 'not enough GPT partition numbers for the complete layout'
    layout_offset=$((layout_offset + 1))
    RUNTIME_DATA_SLOT=$(runtime_policy_slot "$layout_offset") || runtime_fatal 'not enough GPT partition numbers for the complete layout'
    layout_offset=$((layout_offset + 1))
    RUNTIME_POOL_SLOT=$(runtime_policy_slot "$layout_offset") || runtime_fatal 'not enough GPT partition numbers for the complete layout'
    layout_offset=$((layout_offset + 1))
    RUNTIME_VAR_TMP_SLOT=$(runtime_policy_slot "$layout_offset") || runtime_fatal 'not enough GPT partition numbers for the complete layout'
    layout_offset=$((layout_offset + 1))
    RUNTIME_VAR_LIB_SHSIGNED_SLOT=$(runtime_policy_slot "$layout_offset") || runtime_fatal 'not enough GPT partition numbers for the complete layout'
    layout_offset=$((layout_offset + 1))
    RUNTIME_VAR_LOG_JOURNAL_SLOT=$(runtime_policy_slot "$layout_offset") || runtime_fatal 'not enough GPT partition numbers for the complete layout'
    layout_offset=$((layout_offset + 1))
    RUNTIME_RAW_SWAP_SLOT=$(runtime_policy_slot "$layout_offset") || runtime_fatal 'not enough GPT partition numbers for the complete layout'
    layout_offset=$((layout_offset + 1))
    RUNTIME_RAW_ZRAM_SLOT=$(runtime_policy_slot "$layout_offset") || runtime_fatal 'not enough GPT partition numbers for the complete layout'
    layout_offset=$((layout_offset + 1))
  DUALBOOT_DEBIAN_SLOT=$RUNTIME_BOOT_SLOT
  RUNTIME_PRESERVED_SLOTS=
}

runtime_apply_layout_from_cmdline() {
  installer_resolve_install_target_defaults
  : "${DEV_INSTALL_DISK:?DEV_INSTALL_DISK must be set}"
  runtime_derive_part_prefix
  runtime_validate_partition_sizes
  runtime_load_default_slots_from_env

  PARTMAN_RECIPE_NAME=${PARTMAN_RECIPE_NAME:-btrfs-ext4-xfs-layout}
  runtime_prepare_layout_policy
  if [ "$RUNTIME_PARTITION_MODE" != fresh ]; then
    runtime_assign_dualboot_slots
  else
    runtime_assign_default_slots
  fi

  RUNTIME_DEBIAN_START_SLOT=$RUNTIME_BOOT_SLOT
  RUNTIME_DEBIAN_END_SLOT=$RUNTIME_RAW_ZRAM_SLOT
  DEV_PART_EFI=$(runtime_partition_path "$RUNTIME_EFI_SLOT")
  DEV_PART_BOOT=$(runtime_partition_path "$RUNTIME_BOOT_SLOT")
  DEV_PART_ROOT=$(runtime_partition_path "$RUNTIME_ROOT_SLOT")
  DEV_PART_HOME=$(runtime_partition_path "$RUNTIME_HOME_SLOT")
  DEV_PART_OPT=$(runtime_partition_path "$RUNTIME_OPT_SLOT")
  DEV_PART_DATA=$(runtime_partition_path "$RUNTIME_DATA_SLOT")
  DEV_PART_POOL=$(runtime_partition_path "$RUNTIME_POOL_SLOT")
  DEV_PART_VAR_TMP=$(runtime_partition_path "$RUNTIME_VAR_TMP_SLOT")
  DEV_PART_VAR_LIB_SHSIGNED=$(runtime_partition_path "$RUNTIME_VAR_LIB_SHSIGNED_SLOT")
  DEV_PART_VAR_LOG_JOURNAL=$(runtime_partition_path "$RUNTIME_VAR_LOG_JOURNAL_SLOT")
  DEV_PART_RAW_SWAP=$(runtime_partition_path "$RUNTIME_RAW_SWAP_SLOT")
  DEV_PART_RAW_ZRAM=$(runtime_partition_path "$RUNTIME_RAW_ZRAM_SLOT")
  ZRAM_BACKING_RAW_DEVICE=$DEV_PART_RAW_ZRAM
  ZRAM_BACKING_MAPPER_NAME=${ZRAM_BACKING_MAPPER_NAME:-zram-writeback}
  ZRAM_BACKING_DEVICE="/dev/mapper/${ZRAM_BACKING_MAPPER_NAME}"
  SWAP_FALLBACK_RAW_DEVICE=$DEV_PART_RAW_SWAP
  SWAP_FALLBACK_MAPPER_NAME=${SWAP_FALLBACK_MAPPER_NAME:-swap-fallback}
  SWAP_FALLBACK_MAPPER="/dev/mapper/${SWAP_FALLBACK_MAPPER_NAME}"
}

runtime_write_runtime_env() {
  dest=$1
  runtime_ensure_system_identity
  runtime_compute_layout_sizing
  runtime_validate_crypto_layout
  runtime_prepare_parent_dir "$dest" 0700
  {
    runtime_write_layout_policy_env
    printf 'SYSTEM_PREFIX=%s\n' "$(runtime_shell_quote "$SYSTEM_PREFIX")"
    printf 'SYSTEM_HOSTNAME=%s\n' "$(runtime_shell_quote "$SYSTEM_HOSTNAME")"
    printf 'SYSTEM_DOMAIN=%s\n' "$(runtime_shell_quote "$SYSTEM_DOMAIN")"
    printf 'DUALBOOT_ENABLED=%s\n' "$(runtime_shell_quote "$DUALBOOT_ENABLED")"
    printf 'CRYPTO_LUKS2_ROOT=%s\n' "$(runtime_shell_quote "$CRYPTO_LUKS2_ROOT")"
    printf 'CRYPTO_LUKS2_HOME=%s\n' "$(runtime_shell_quote "$CRYPTO_LUKS2_HOME")"
    printf 'ROOT_CRYPT_NAME=%s\n' "$(runtime_shell_quote cryptroot)"
    printf 'HOME_CRYPT_NAME=%s\n' "$(runtime_shell_quote crypthome)"
    printf 'DUALBOOT_EFI_SLOT=%s\n' "$(runtime_shell_quote "${DUALBOOT_EFI_SLOT:-}")"
    printf 'DUALBOOT_DEBIAN_SLOT=%s\n' "$(runtime_shell_quote "${DUALBOOT_DEBIAN_SLOT:-}")"
    printf 'RUNTIME_PRESERVED_SLOTS=%s\n' "$(runtime_shell_quote "${RUNTIME_PRESERVED_SLOTS:-}")"
    printf 'PARTMAN_RECIPE_NAME=%s\n' "$(runtime_shell_quote "$PARTMAN_RECIPE_NAME")"
    printf 'DEV_INSTALL_DISK=%s\n' "$(runtime_shell_quote "$DEV_INSTALL_DISK")"
    printf 'DEV_PART_PREFIX=%s\n' "$(runtime_shell_quote "$DEV_PART_PREFIX")"
    printf 'RUNTIME_DISK_TOTAL_MB=%s\n' "$(runtime_shell_quote "$RUNTIME_DISK_TOTAL_MB")"
    printf 'RUNTIME_LAYOUT_SAFETY_MARGIN_MB=%s\n' "$(runtime_shell_quote "$RUNTIME_LAYOUT_SAFETY_MARGIN_MB")"
    printf 'RUNTIME_PRESERVED_TOTAL_MB=%s\n' "$(runtime_shell_quote "$RUNTIME_PRESERVED_TOTAL_MB")"
    printf 'RUNTIME_USABLE_BUDGET_MB=%s\n' "$(runtime_shell_quote "$RUNTIME_USABLE_BUDGET_MB")"
    printf 'RUNTIME_BASE_LAYOUT_MB=%s\n' "$(runtime_shell_quote "$RUNTIME_BASE_LAYOUT_MB")"
    printf 'RUNTIME_INSTALL_RAM_MIB=%s\n' "$(runtime_shell_quote "$RUNTIME_INSTALL_RAM_MIB")"
    printf 'RUNTIME_EFI_SLOT=%s\n' "$(runtime_shell_quote "$RUNTIME_EFI_SLOT")"
    printf 'RUNTIME_BOOT_SLOT=%s\n' "$(runtime_shell_quote "$RUNTIME_BOOT_SLOT")"
    printf 'RUNTIME_ROOT_SLOT=%s\n' "$(runtime_shell_quote "$RUNTIME_ROOT_SLOT")"
    printf 'RUNTIME_HOME_SLOT=%s\n' "$(runtime_shell_quote "$RUNTIME_HOME_SLOT")"
    printf 'RUNTIME_OPT_SLOT=%s\n' "$(runtime_shell_quote "$RUNTIME_OPT_SLOT")"
    printf 'RUNTIME_DATA_SLOT=%s\n' "$(runtime_shell_quote "$RUNTIME_DATA_SLOT")"
    printf 'RUNTIME_POOL_SLOT=%s\n' "$(runtime_shell_quote "$RUNTIME_POOL_SLOT")"
    printf 'RUNTIME_VAR_TMP_SLOT=%s\n' "$(runtime_shell_quote "$RUNTIME_VAR_TMP_SLOT")"
    printf 'RUNTIME_VAR_LIB_SHSIGNED_SLOT=%s\n' "$(runtime_shell_quote "$RUNTIME_VAR_LIB_SHSIGNED_SLOT")"
    printf 'RUNTIME_VAR_LOG_JOURNAL_SLOT=%s\n' "$(runtime_shell_quote "$RUNTIME_VAR_LOG_JOURNAL_SLOT")"
    printf 'RUNTIME_RAW_SWAP_SLOT=%s\n' "$(runtime_shell_quote "$RUNTIME_RAW_SWAP_SLOT")"
    printf 'RUNTIME_RAW_ZRAM_SLOT=%s\n' "$(runtime_shell_quote "$RUNTIME_RAW_ZRAM_SLOT")"
    printf 'RUNTIME_DEBIAN_START_SLOT=%s\n' "$(runtime_shell_quote "$RUNTIME_DEBIAN_START_SLOT")"
    printf 'RUNTIME_DEBIAN_END_SLOT=%s\n' "$(runtime_shell_quote "$RUNTIME_DEBIAN_END_SLOT")"
    printf 'DEV_PART_EFI=%s\n' "$(runtime_shell_quote "$DEV_PART_EFI")"
    printf 'DEV_PART_BOOT=%s\n' "$(runtime_shell_quote "$DEV_PART_BOOT")"
    printf 'DEV_PART_ROOT=%s\n' "$(runtime_shell_quote "$DEV_PART_ROOT")"
    printf 'DEV_PART_HOME=%s\n' "$(runtime_shell_quote "$DEV_PART_HOME")"
    printf 'DEV_PART_OPT=%s\n' "$(runtime_shell_quote "$DEV_PART_OPT")"
    printf 'DEV_PART_DATA=%s\n' "$(runtime_shell_quote "$DEV_PART_DATA")"
    printf 'DEV_PART_POOL=%s\n' "$(runtime_shell_quote "$DEV_PART_POOL")"
    printf 'DEV_PART_VAR_TMP=%s\n' "$(runtime_shell_quote "$DEV_PART_VAR_TMP")"
    printf 'DEV_PART_VAR_LIB_SHSIGNED=%s\n' "$(runtime_shell_quote "$DEV_PART_VAR_LIB_SHSIGNED")"
    printf 'DEV_PART_VAR_LOG_JOURNAL=%s\n' "$(runtime_shell_quote "$DEV_PART_VAR_LOG_JOURNAL")"
    printf 'DEV_PART_RAW_SWAP=%s\n' "$(runtime_shell_quote "$DEV_PART_RAW_SWAP")"
    printf 'DEV_PART_RAW_ZRAM=%s\n' "$(runtime_shell_quote "$DEV_PART_RAW_ZRAM")"
    printf 'ZRAM_BACKING_RAW_DEVICE=%s\n' "$(runtime_shell_quote "$ZRAM_BACKING_RAW_DEVICE")"
    printf 'ZRAM_BACKING_MAPPER_NAME=%s\n' "$(runtime_shell_quote "$ZRAM_BACKING_MAPPER_NAME")"
    printf 'ZRAM_BACKING_DEVICE=%s\n' "$(runtime_shell_quote "$ZRAM_BACKING_DEVICE")"
    printf 'SWAP_FALLBACK_RAW_DEVICE=%s\n' "$(runtime_shell_quote "$SWAP_FALLBACK_RAW_DEVICE")"
    printf 'SWAP_FALLBACK_MAPPER_NAME=%s\n' "$(runtime_shell_quote "$SWAP_FALLBACK_MAPPER_NAME")"
    printf 'SWAP_FALLBACK_MAPPER=%s\n' "$(runtime_shell_quote "$SWAP_FALLBACK_MAPPER")"
    printf 'DEV_PART_EFI_MB=%s\n' "$(runtime_shell_quote "$DEV_PART_EFI_MB")"
    printf 'DEV_PART_BOOT_MB=%s\n' "$(runtime_shell_quote "$DEV_PART_BOOT_MB")"
    printf 'DEV_PART_ROOT_MB=%s\n' "$(runtime_shell_quote "$DEV_PART_ROOT_MB")"
    printf 'DEV_PART_HOME_MB=%s\n' "$(runtime_shell_quote "$DEV_PART_HOME_MB")"
    printf 'DEV_PART_OPT_MB=%s\n' "$(runtime_shell_quote "$DEV_PART_OPT_MB")"
    printf 'DEV_PART_DATA_MB=%s\n' "$(runtime_shell_quote "$DEV_PART_DATA_MB")"
    printf 'DEV_PART_POOL_MB=%s\n' "$(runtime_shell_quote "$DEV_PART_POOL_MB")"
    printf 'DEV_PART_VAR_TMP_MB=%s\n' "$(runtime_shell_quote "$DEV_PART_VAR_TMP_MB")"
    printf 'DEV_PART_VAR_LIB_SHSIGNED_MB=%s\n' "$(runtime_shell_quote "$DEV_PART_VAR_LIB_SHSIGNED_MB")"
    printf 'DEV_PART_VAR_LOG_JOURNAL_MB=%s\n' "$(runtime_shell_quote "$DEV_PART_VAR_LOG_JOURNAL_MB")"
    printf 'DEV_PART_RAW_SWAP_MB=%s\n' "$(runtime_shell_quote "$DEV_PART_RAW_SWAP_MB")"
    printf 'DEV_PART_RAW_ZRAM_MB=%s\n' "$(runtime_shell_quote "$DEV_PART_RAW_ZRAM_MB")"
    printf 'SWAP_SIZE_MIB=%s\n' "$(runtime_shell_quote "$SWAP_SIZE_MIB")"
    if [ "$DUALBOOT_ENABLED" = true ]; then
      printf 'RUNTIME_PARTITION_%s_SIZE_MB=%s\n' "$RUNTIME_EFI_SLOT" "$(runtime_shell_quote "$DEV_PART_EFI_MB")"
    fi
  } >"$dest"
  chmod 0600 "$dest"
}

runtime_emit_debian_partition_recipe() {
  # Runtime sizing has already allocated the backing/swap budgets. Only root
  # may grow to absorb the remaining alignment/free-space remainder.
  runtime_render_recipe btrfs-01.recipe.tmpl \
    DEV_PART_BOOT_MB "${DEV_PART_BOOT_MB}"
  if runtime_root_crypto_enabled; then
    runtime_render_recipe btrfs-02.recipe.tmpl \
      ROOT_PRIORITY "$((DEV_PART_ROOT_MB + 1))" \
      ROOT_MAX_MB "$(runtime_partman_root_max_mb)" \
      DEV_PART_ROOT_MB "${DEV_PART_ROOT_MB}"
  else
    runtime_render_recipe btrfs-03.recipe.tmpl \
      ROOT_PRIORITY "$((DEV_PART_ROOT_MB + 1))" \
      ROOT_MAX_MB "$(runtime_partman_root_max_mb)" \
      DEV_PART_ROOT_MB "${DEV_PART_ROOT_MB}"
  fi
  if runtime_home_crypto_enabled; then
    runtime_render_recipe btrfs-home-reserved.recipe.tmpl DEV_PART_HOME_MB "$DEV_PART_HOME_MB"
  else
    runtime_render_recipe btrfs-home-native.recipe.tmpl DEV_PART_HOME_MB "$DEV_PART_HOME_MB"
  fi
  runtime_render_recipe btrfs-04.recipe.tmpl \
    DEV_PART_OPT_MB "${DEV_PART_OPT_MB}" \
    DEV_PART_DATA_MB "${DEV_PART_DATA_MB}" \
    DEV_PART_POOL_MB "${DEV_PART_POOL_MB}" \
    DEV_PART_VAR_TMP_MB "${DEV_PART_VAR_TMP_MB}" \
    DEV_PART_VAR_LIB_SHSIGNED_MB "${DEV_PART_VAR_LIB_SHSIGNED_MB}" \
    DEV_PART_VAR_LOG_JOURNAL_MB "${DEV_PART_VAR_LOG_JOURNAL_MB}" \
    DEV_PART_RAW_SWAP_MB "${DEV_PART_RAW_SWAP_MB}" \
    DEV_PART_RAW_ZRAM_MB "${DEV_PART_RAW_ZRAM_MB}"
}

runtime_emit_default_recipe() {
  runtime_render_recipe btrfs-05.recipe.tmpl \
    PARTMAN_RECIPE_NAME "${PARTMAN_RECIPE_NAME}" \
    DEV_PART_EFI_MB "${DEV_PART_EFI_MB}"
  runtime_emit_debian_partition_recipe
}

runtime_emit_dualboot_recipe() {
  runtime_render_recipe btrfs-06.recipe.tmpl \
    PARTMAN_RECIPE_NAME "${PARTMAN_RECIPE_NAME}"
  runtime_emit_debian_partition_recipe
}

runtime_write_expert_recipe() {
  runtime_prepare_recipe_templates
  dest=$1
  runtime_compute_layout_sizing
  runtime_prepare_parent_dir "$dest" 0700
  if [ "$DUALBOOT_ENABLED" = "true" ]; then
    runtime_emit_dualboot_recipe >"$dest"
  else
    runtime_emit_default_recipe >"$dest"
  fi
  chmod 0600 "$dest"
}

runtime_write_partman_fragment() {
  dest=$1
  recipe_file=$2
  runtime_prepare_parent_dir "$dest" 0700

  {
    printf '##########  Runtime Partitioning  ##########\n'
    printf '# Generated inside the installer before partman runs.\n'
    printf 'd-i partman-efi/confirm boolean true\n'
    printf 'd-i partman-efi/confirm seen true\n'
    runtime_emit_partman_driver_answers
    printf 'd-i partman-auto/choose_recipe select %s\n' "$PARTMAN_RECIPE_NAME"
    printf 'd-i partman-auto/choose_recipe seen true\n'
    printf 'd-i partman-auto/expert_recipe_file string %s\n' "$recipe_file"
    printf 'd-i partman-auto/expert_recipe_file seen true\n'
    printf 'd-i partman/choose_partition select finish\n'
    printf 'd-i partman/choose_partition seen true\n'
    printf 'd-i partman/confirm boolean true\n'
    printf 'd-i partman/confirm seen true\n'
    printf 'd-i partman/confirm_nochanges boolean true\n'
    printf 'd-i partman/confirm_nochanges seen true\n'
    printf 'd-i partman/confirm_nooverwrite boolean true\n'
    printf 'd-i partman/confirm_nooverwrite seen true\n'
    printf 'd-i partman-auto/confirm boolean true\n'
    printf 'd-i partman-auto/confirm seen true\n'
  } >"$dest"
  chmod 0644 "$dest"
}

runtime_write_identity_answers() {
  dest=$1

  runtime_ensure_system_identity
  runtime_prepare_parent_dir "$dest" 0700
  {
    printf '##########  Runtime Identity Configuration  ##########\n'
    printf '# Generated inside the installer before netcfg finishes.\n'
    printf 'd-i netcfg/get_hostname string %s\n' "$SYSTEM_HOSTNAME"
    printf 'd-i netcfg/get_hostname seen true\n'
    printf 'd-i netcfg/get_domain string %s\n' "$SYSTEM_DOMAIN"
    printf 'd-i netcfg/get_domain seen true\n'
    printf 'd-i netcfg/hostname string %s\n' "$SYSTEM_HOSTNAME"
    printf 'd-i netcfg/hostname seen true\n'
  } >"$dest"
  chmod 0600 "$dest"
}

runtime_seed_partman_answers() {
  recipe_file=$1
  runtime_seed_generated_answers runtime_write_partman_fragment "$recipe_file"
}
