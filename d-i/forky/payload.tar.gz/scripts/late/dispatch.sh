#!/bin/sh
set -eu

RUNTIME_DIR=${INSTALLER_RUNTIME_DIR:-/tmp/install-runtime}
BOOTSTRAP_LIB=${INSTALLER_BOOTSTRAP_LIB:-${RUNTIME_DIR}/bootstrap/bootstrap.sh}
if [ ! -s "$BOOTSTRAP_LIB" ]; then
  SELF_DIR=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
  BOOTSTRAP_LIB="${SELF_DIR}/../common/bootstrap.sh"
fi
[ -s "$BOOTSTRAP_LIB" ] || {
  dispatch_message="installer bootstrap library is unavailable: ${BOOTSTRAP_LIB}"
  printf 'fatal: %s\n' "$dispatch_message" >&2
  if [ -c /dev/tty4 ] && [ -w /dev/tty4 ]; then
    printf '[late-dispatch] fatal: %s\n' "$dispatch_message" >/dev/tty4 || :
  fi
  if command -v logger >/dev/null 2>&1; then
    logger -t preseed-late-dispatch "fatal: $dispatch_message" 2>/dev/null || :
  fi
  exit 1
}
# shellcheck disable=SC1090,SC1091
. "$BOOTSTRAP_LIB"
bootstrap_source_common_lib "${1:-}"
[ -n "${BOOTSTRAP_PREPARED_SOURCE_ROOT:-}" ] || \
  installer_fatal 'target payload must be prepared by the first base-stage hook before late_command'
installer_init_log_file "$(installer_runtime_log_file)" "" "late dispatch" late-dispatch late_command
installer_operation_context_repo scripts/late/dispatch.sh 25 late_dispatch
trap 'installer_finalize_log "$?"' EXIT

seed_base=$(installer_seed_base "${1:-}")
installer_ensure_context_loaded "$seed_base"
host_profile=$(installer_resolve_host_profile "")
hook_family=${INSTALLER_HOOK_FAMILY:-${INSTALLER_HOST_FAMILY}}
shared_hook_path=$(installer_repo_file_value hooks/installer/late_command.sh)
shared_hook_dest="${BOOTSTRAP_PREPARED_SOURCE_ROOT}/${shared_hook_path}"
shared_module_dir="${BOOTSTRAP_PREPARED_SOURCE_ROOT}/${DIR_SCRIPTS_LATE}"
SHARED_LATE_COMMAND=$shared_hook_dest
INSTALLER_LATE_MODULE_DIR=$shared_module_dir
export SHARED_LATE_COMMAND INSTALLER_LATE_MODULE_DIR
shared_modules="core target-assets iocost volatile-storage storage-maintenance mullvad templates network network-sharing grub security dbus-broker podman zram-swap btrfs-family f2fs-family account"
if installer_class_selected optional/cuda-legacy 2>/dev/null; then
  shared_modules="${shared_modules} cuda-legacy"
fi

# Load the validated composite host environment before any late module is
# fetched. Shared modules are sourced directly by the storage-family child
# shell, so their canonical path tokens must be rendered while they are still
# private installer files rather than after a function has already been
# defined with literal placeholder words.
dispatch_host_env="${RUNTIME_DIR}/bootstrap/dispatch-host.env"
installer_fetch_host_env "$seed_base" "$host_profile" "$dispatch_host_env" 0600
# shellcheck disable=SC1090,SC1091
installer_load_data_env "$dispatch_host_env"

late_dispatch_module_source() {
  case "$1" in
    core) late_dispatch_selector=scripts/late/core.sh ;;
    target-assets) late_dispatch_selector=scripts/late/target-assets.sh ;;
    iocost) late_dispatch_selector=scripts/late/iocost.sh ;;
    volatile-storage) late_dispatch_selector=scripts/late/volatile-storage.sh ;;
    storage-maintenance) late_dispatch_selector=scripts/late/storage-maintenance.sh ;;
    mullvad) late_dispatch_selector=scripts/late/mullvad.sh ;;
    templates) late_dispatch_selector=scripts/late/templates.sh ;;
    network) late_dispatch_selector=scripts/late/network.sh ;;
    network-sharing) late_dispatch_selector=scripts/late/network-sharing.sh ;;
    grub) late_dispatch_selector=scripts/late/grub.sh ;;
    security) late_dispatch_selector=scripts/late/security.sh ;;
    dbus-broker) late_dispatch_selector=scripts/late/dbus-broker.sh ;;
    podman) late_dispatch_selector=scripts/late/podman.sh ;;
    zram-swap) late_dispatch_selector=scripts/late/zram-swap.sh ;;
    btrfs-family) late_dispatch_selector=scripts/late/btrfs-family.sh ;;
    f2fs-family) late_dispatch_selector=scripts/late/f2fs-family.sh ;;
    account) late_dispatch_selector=scripts/late/account.sh ;;
    cuda-legacy) late_dispatch_selector=scripts/late/cuda-legacy.sh ;;
    *) installer_fatal "unsupported shared late module: ${1:-unset}" ;;
  esac
  installer_repo_file_value "$late_dispatch_selector"
}

[ -f "$shared_hook_dest" ] && [ ! -L "$shared_hook_dest" ] || installer_fatal 'prepared late entrypoint is missing'
for shared_module in $shared_modules; do
  installer_operation_context_repo scripts/late/dispatch.sh 96 "fetch_shared_module:${shared_module}"
  shared_module_source=$(late_dispatch_module_source "$shared_module") || {
    late_dispatch_status=$?
    installer_fatal_status "$late_dispatch_status" \
      "late-dispatch shared module selector resolution failed: module=${shared_module}"
  }
  [ "${BOOTSTRAP_PREPARED_SOURCE_ROOT}/${shared_module_source}" = "${shared_module_dir}/${shared_module}.sh" ] &&
    [ -f "${shared_module_dir}/${shared_module}.sh" ] && [ ! -L "${shared_module_dir}/${shared_module}.sh" ] ||
    installer_fatal "prepared late module is missing or has an unexpected source: ${shared_module}"
done
dispatch_storage_foundation() {
case "$hook_family" in
  btrfs|vm)
    installer_operation_context_repo scripts/late/dispatch.sh 113 "run_btrfs_family_late_command:${hook_family}"
    if INSTALLER_BOOTSTRAP_LIB=$BOOTSTRAP_LIB \
       INSTALLER_LATE_MODULE_DIR=$shared_module_dir \
       SHARED_LATE_COMMAND=$shared_hook_dest \
         /bin/sh -eu -c '. "$SHARED_LATE_COMMAND"; run_btrfs_family_late_command "$@"' sh \
         "$hook_family" "$seed_base" "$host_profile"
    then
      :
    else
      late_dispatch_status=$?
      installer_fatal_status "$late_dispatch_status" \
        "Btrfs-family late command failed: family=${hook_family} profile=${host_profile:-unset}"
    fi
    ;;
  f2fs)
    installer_operation_context_repo scripts/late/dispatch.sh 128 run_f2fs_family_late_command
    if INSTALLER_BOOTSTRAP_LIB=$BOOTSTRAP_LIB \
       INSTALLER_LATE_MODULE_DIR=$shared_module_dir \
       SHARED_LATE_COMMAND=$shared_hook_dest \
         /bin/sh -eu -c '. "$SHARED_LATE_COMMAND"; run_f2fs_family_late_command "$@"' sh \
         "$seed_base" "$host_profile"
    then
      :
    else
      late_dispatch_status=$?
      installer_fatal_status "$late_dispatch_status" \
        "F2FS-family late command failed: profile=${host_profile:-unset}"
    fi
    ;;
  *)
    installer_fatal "unsupported shared late storage family: ${hook_family}"
    ;;
esac
}

run_helper_script() {
  helper_path=$1
  shift

  helper_dest=${BOOTSTRAP_PREPARED_SOURCE_ROOT}/${helper_path}
  [ -f "$helper_dest" ] && [ ! -L "$helper_dest" ] || installer_fatal 'prepared late stage is missing'
  installer_operation_context_repo scripts/late/dispatch.sh 155 "late_helper:${helper_path}"
  /bin/sh -eu "$helper_dest" "$@" </dev/null
}

# Every late provider is selected, ordered and deduplicated by the frozen plan.
installer_assert_class_plan
plan_stages="${RUNTIME_DIR}/state/late-stages.tsv"
installer_plan_stage_records late >"$plan_stages" ||
  installer_fatal 'invalid late stage record'
installer_publish_class_receipt
# Every provider, including CrowdSec and server Whisper, needs the resolved
# identity independently of the optional desktop storage stage's execution.
INSTALLER_LATE_ACCOUNT_ENV=${INSTALLER_LATE_ACCOUNT_ENV:-${DIR_INSTALLER_LATE_ENV}/account.env}
export INSTALLER_LATE_ACCOUNT_ENV
installer_operation_context_repo scripts/late/dispatch.sh 166 prepare_late_account_env
installer_prepare_late_account_env "$seed_base" "$INSTALLER_LATE_ACCOUNT_ENV"
bootstrap_source_common_support_libs "$seed_base" "${DIR_INSTALLER_LATE_ENV}/account-provisioning" target
installer_stage_account_creation
while IFS='|' read -r stage_id stage_phase stage_selector || [ -n "$stage_id" ]; do
  if installer_phase_stage_begin "$stage_phase" "$stage_id"; then
    :
  else
    stage_status=$?
    [ "$stage_status" = 1 ] && continue
    installer_fatal_status "$stage_status" 'cannot claim late phase stage ownership'
  fi
  INSTALLER_LOG_STAGE=late_command
  INSTALLER_LOG_TAG=$stage_id
  export INSTALLER_LOG_STAGE INSTALLER_LOG_TAG
  installer_info "starting selected stage ${stage_id}"
  # desktop.session has its own child invocation below; do not retain the
  # preceding provider's diagnostic context when this stage fails.
  installer_operation_context_repo "$stage_selector" 1 "late_stage:${stage_id}"
  case "$stage_id:$INSTALLER_HOST_VARIANT" in
    desktop.storage:desktop) dispatch_storage_foundation ;;
    *)
      stage_source=$(installer_repo_file_value "$stage_selector")
      stage_destination="${BOOTSTRAP_PREPARED_SOURCE_ROOT}/${stage_source}"
      case "$stage_id" in
        desktop.session)
          [ -f "$stage_destination" ] && [ ! -L "$stage_destination" ] || installer_fatal 'prepared desktop stage is missing'
          INSTALLER_LATE_MODULE_DIR=$shared_module_dir /bin/sh -eu "$stage_destination" "$seed_base" "$host_profile"
          ;;
        *) run_helper_script "$stage_source" "$TARGET_ROOT" ;;
      esac
      ;;
  esac
  installer_phase_stage_finish "$stage_phase" "$stage_id"
  installer_info "completed selected stage ${stage_id}"
done <"$plan_stages"

# All selected stages have consumed their private rendered payload inputs.
# Keep them on failure for diagnosis; no installed application consumes them.
if [ -d "${TARGET_ROOT}${DIR_INSTALLER_TARGET_DEFAULTS}" ]; then
  bootstrap_source_common_support_libs "$seed_base" "${DIR_INSTALLER_LATE_ENV}/defaults-cleanup" target
  installer_run_target_setup scripts/common/primary-defaults.py 'remove private primary-account payload staging' \
    cleanup "$DIR_INSTALLER_TARGET_DEFAULTS"
fi
# The late phase owns all consumers of this private workspace. Preserve it on
# any stage failure; successful cleanup runs under the same phase ownership.
installer_run_bounded 180 chroot "$TARGET_ROOT" "${DIR_USR_BIN}/env" -i \
  HOME="$DIR_ROOT_HOME" PATH="${DIR_USR_BIN}:${DIR_BIN}" LC_ALL=C.UTF-8 \
  "${DIR_USR_BIN}/perl" -f "${DIR_INSTALLER_TARGET_STAGE}/render.pl" \
  "$DIR_INSTALLER_TARGET_STAGE" --cleanup
rm -f -- "$FILE_INSTALLER_TARGET_RENDER_READY"
BOOTSTRAP_PREPARED_SOURCE_ROOT=
BOOTSTRAP_PREPARED_SEED_BASE=
