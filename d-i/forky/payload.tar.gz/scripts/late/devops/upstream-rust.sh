#!/bin/sh
# shellcheck disable=SC2154
# Sourced installer module; edit this file directly.

devops_install_upstream_tools() {
  helper_repo_path=$(installer_repo_file_value scripts/late/devops-tools.py)
  helper_target_path=/tmp/installer-devops-tools.py
  helper_host_path="${target_root}${helper_target_path}"
  policy_target_path=/tmp/installer-devops-tools-policy.json
  policy_host_path="${target_root}${policy_target_path}"
  plugins_manifest_target_path=/tmp/installer-yt-dlp-plugins.json
  plugins_manifest_host_path="${target_root}${plugins_manifest_target_path}"
  plugins_manifest_source_path="${tmp_env_dir}/yt-dlp-plugins.json.tmpl.$$"
  plugins_manifest_rendered_path="${tmp_env_dir}/yt-dlp-plugins.json.$$"

  [ ! -e "$helper_host_path" ] && [ ! -L "$helper_host_path" ] ||
    devops_fatal "temporary upstream DevOps tool installer path already exists"
  [ ! -e "$policy_host_path" ] && [ ! -L "$policy_host_path" ] ||
    devops_fatal "temporary upstream DevOps tool policy path already exists"
  [ ! -e "$plugins_manifest_host_path" ] && [ ! -L "$plugins_manifest_host_path" ] ||
    devops_fatal "temporary yt-dlp plugin manifest path already exists"

  bootstrap_fetch_seed_file \
    "$seed_base" \
    "$helper_repo_path" \
    "$helper_host_path" \
    0700 \
    "DevOps upstream-tool installer ${helper_repo_path}"
  chown root:root "$helper_host_path"

  bootstrap_fetch_seed_file \
    "$seed_base" \
    "$(installer_repo_file_value scripts/late/devops/yt-dlp-plugins.json)" \
    "$plugins_manifest_source_path" \
    0600 \
    "yt-dlp plugin manifest"
  installer_apply_scalar_placeholders \
    "$plugins_manifest_source_path" \
    "$plugins_manifest_rendered_path" \
    DEVOPS_YT_DLP_VERSION "$DEVOPS_YT_DLP_VERSION" \
    DEVOPS_YT_DLP_EJS_VERSION "$DEVOPS_YT_DLP_EJS_VERSION" \
    DEVOPS_YT_DLP_PLUGIN_BGUTIL_VERSION "$DEVOPS_YT_DLP_PLUGIN_BGUTIL_VERSION" \
    DEVOPS_YT_DLP_PLUGIN_BGUTIL_ZIP_URL "$DEVOPS_YT_DLP_PLUGIN_BGUTIL_ZIP_URL" \
    DEVOPS_YT_DLP_PLUGIN_BGUTIL_ZIP_SHA256 "$DEVOPS_YT_DLP_PLUGIN_BGUTIL_ZIP_SHA256" \
    DEVOPS_YT_DLP_PLUGIN_BGUTIL_BINARY_URL "$DEVOPS_YT_DLP_PLUGIN_BGUTIL_BINARY_URL" \
    DEVOPS_YT_DLP_PLUGIN_BGUTIL_BINARY_SHA256 "$DEVOPS_YT_DLP_PLUGIN_BGUTIL_BINARY_SHA256" \
    DEVOPS_YT_DLP_PLUGIN_RAJIKO_VERSION "$DEVOPS_YT_DLP_PLUGIN_RAJIKO_VERSION" \
    DEVOPS_YT_DLP_PLUGIN_RAJIKO_ZIP_URL "$DEVOPS_YT_DLP_PLUGIN_RAJIKO_ZIP_URL" \
    DEVOPS_YT_DLP_PLUGIN_RAJIKO_ZIP_SHA256 "$DEVOPS_YT_DLP_PLUGIN_RAJIKO_ZIP_SHA256" \
    DEVOPS_YT_DLP_PLUGIN_APPLE_DEVELOPER_VERSION "$DEVOPS_YT_DLP_PLUGIN_APPLE_DEVELOPER_VERSION" \
    DEVOPS_YT_DLP_PLUGIN_APPLE_DEVELOPER_MODULE_URL "$DEVOPS_YT_DLP_PLUGIN_APPLE_DEVELOPER_MODULE_URL" \
    DEVOPS_YT_DLP_PLUGIN_APPLE_DEVELOPER_MODULE_SHA256 "$DEVOPS_YT_DLP_PLUGIN_APPLE_DEVELOPER_MODULE_SHA256" \
    DEVOPS_YT_DLP_PLUGIN_SRT_FIX_VERSION "$DEVOPS_YT_DLP_PLUGIN_SRT_FIX_VERSION" \
    DEVOPS_YT_DLP_PLUGIN_SRT_FIX_MODULE_URL "$DEVOPS_YT_DLP_PLUGIN_SRT_FIX_MODULE_URL" \
    DEVOPS_YT_DLP_PLUGIN_SRT_FIX_MODULE_SHA256 "$DEVOPS_YT_DLP_PLUGIN_SRT_FIX_MODULE_SHA256" \
    DEVOPS_YT_DLP_PLUGIN_RETURN_YOUTUBE_DISLIKE_VERSION "$DEVOPS_YT_DLP_PLUGIN_RETURN_YOUTUBE_DISLIKE_VERSION" \
    DEVOPS_YT_DLP_PLUGIN_RETURN_YOUTUBE_DISLIKE_MODULE_URL "$DEVOPS_YT_DLP_PLUGIN_RETURN_YOUTUBE_DISLIKE_MODULE_URL" \
    DEVOPS_YT_DLP_PLUGIN_RETURN_YOUTUBE_DISLIKE_MODULE_SHA256 "$DEVOPS_YT_DLP_PLUGIN_RETURN_YOUTUBE_DISLIKE_MODULE_SHA256" \
    DEVOPS_YT_DLP_PLUGIN_FIXUP_MTIME_VERSION "$DEVOPS_YT_DLP_PLUGIN_FIXUP_MTIME_VERSION" \
    DEVOPS_YT_DLP_PLUGIN_FIXUP_MTIME_MODULE_URL "$DEVOPS_YT_DLP_PLUGIN_FIXUP_MTIME_MODULE_URL" \
    DEVOPS_YT_DLP_PLUGIN_FIXUP_MTIME_MODULE_SHA256 "$DEVOPS_YT_DLP_PLUGIN_FIXUP_MTIME_MODULE_SHA256" || {
      rm -f -- "$plugins_manifest_source_path" "$plugins_manifest_rendered_path"
      devops_fatal "failed to render yt-dlp plugin manifest"
    }
  installer_assert_no_unresolved_installer_placeholders \
    "$plugins_manifest_rendered_path" \
    "yt-dlp plugin manifest" || {
      rm -f -- "$plugins_manifest_source_path" "$plugins_manifest_rendered_path"
      devops_fatal "yt-dlp plugin manifest has unresolved installer placeholders"
    }
  install -m 0600 "$plugins_manifest_rendered_path" "$plugins_manifest_host_path"
  rm -f -- "$plugins_manifest_source_path" "$plugins_manifest_rendered_path"
  chown root:root "$plugins_manifest_host_path"

  if ! run_in_target \
    "render private upstream DevOps tool policy" \
    __INSTALLER_PATH_DIR_USR_BIN__/python3 -c \
      'import json, os, pathlib, sys
path = pathlib.Path(sys.argv[1])
items = sys.argv[2:]
if len(items) % 2:
    raise SystemExit("policy key/value arguments are unbalanced")
keys = items[0::2]
if len(keys) != len(set(keys)):
    raise SystemExit("policy contains duplicate keys")
payload = dict(zip(keys, items[1::2]))
flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
if hasattr(os, "O_NOFOLLOW"):
    flags |= os.O_NOFOLLOW
descriptor = os.open(path, flags, 0o600)
try:
    with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
except BaseException:
    path.unlink(missing_ok=True)
    raise' \
      "$policy_target_path" \
      DEVOPS_UPSTREAM_POLICY_SCHEMA "$DEVOPS_UPSTREAM_POLICY_SCHEMA" \
      DEVOPS_UPSTREAM_ARCHITECTURE "$DEVOPS_UPSTREAM_ARCHITECTURE" \
      DEVOPS_UPSTREAM_DOWNLOAD_TIMEOUT_SECONDS "$DEVOPS_UPSTREAM_DOWNLOAD_TIMEOUT_SECONDS" \
      DEVOPS_UPSTREAM_NPM_TIMEOUT_SECONDS "$DEVOPS_UPSTREAM_NPM_TIMEOUT_SECONDS" \
      DEVOPS_UPSTREAM_MAKE_TIMEOUT_SECONDS "$DEVOPS_UPSTREAM_MAKE_TIMEOUT_SECONDS" \
      DEVOPS_UPSTREAM_VERIFY_TIMEOUT_SECONDS "$DEVOPS_UPSTREAM_VERIFY_TIMEOUT_SECONDS" \
      DEVOPS_UPSTREAM_MAX_ARCHIVE_MEMBERS "$DEVOPS_UPSTREAM_MAX_ARCHIVE_MEMBERS" \
      DEVOPS_UPSTREAM_MAX_EXTRACTED_BYTES "$DEVOPS_UPSTREAM_MAX_EXTRACTED_BYTES" \
      DEVOPS_DENO_VERSION "$DEVOPS_DENO_VERSION" \
      DEVOPS_DENO_URL "$DEVOPS_DENO_URL" \
      DEVOPS_DENO_SHA256 "$DEVOPS_DENO_SHA256" \
      DEVOPS_DENO_ARCHITECTURE "$DEVOPS_DENO_ARCHITECTURE" \
      DEVOPS_DENO_ARCHIVE_FILENAME "$DEVOPS_DENO_ARCHIVE_FILENAME" \
      DEVOPS_DENO_ARCHIVE_FILES "$DEVOPS_DENO_ARCHIVE_FILES" \
      DEVOPS_DENO_INSTALL_ROOT "$DEVOPS_DENO_INSTALL_ROOT" \
      DEVOPS_DENO_BINARY_PATH "$DEVOPS_DENO_BINARY_PATH" \
      DEVOPS_YT_DLP_VERSION "$DEVOPS_YT_DLP_VERSION" \
      DEVOPS_YT_DLP_URL "$DEVOPS_YT_DLP_URL" \
      DEVOPS_YT_DLP_SHA256 "$DEVOPS_YT_DLP_SHA256" \
      DEVOPS_YT_DLP_ARCHITECTURE "$DEVOPS_YT_DLP_ARCHITECTURE" \
      DEVOPS_YT_DLP_ARCHIVE_FILENAME "$DEVOPS_YT_DLP_ARCHIVE_FILENAME" \
      DEVOPS_YT_DLP_INSTALL_ROOT "$DEVOPS_YT_DLP_INSTALL_ROOT" \
      DEVOPS_YT_DLP_BINARY_PATH "$DEVOPS_YT_DLP_BINARY_PATH" \
      DEVOPS_YT_DLP_PAYLOAD_PATH "$DEVOPS_YT_DLP_PAYLOAD_PATH" \
      DEVOPS_YT_DLP_EJS_VERSION "$DEVOPS_YT_DLP_EJS_VERSION" \
      DEVOPS_YT_DLP_PLUGINS_MANIFEST_PATH "$plugins_manifest_target_path" \
      DEVOPS_ANSIBLE_CORE_VERSION "$DEVOPS_ANSIBLE_CORE_VERSION" \
      DEVOPS_ANSIBLE_CORE_URL "$DEVOPS_ANSIBLE_CORE_URL" \
      DEVOPS_ANSIBLE_CORE_SHA256 "$DEVOPS_ANSIBLE_CORE_SHA256" \
      DEVOPS_ANSIBLE_CORE_ARCHITECTURE "$DEVOPS_ANSIBLE_CORE_ARCHITECTURE" \
      DEVOPS_ANSIBLE_CORE_ARCHIVE_FILENAME "$DEVOPS_ANSIBLE_CORE_ARCHIVE_FILENAME" \
      DEVOPS_ANSIBLE_CORE_PACKAGE_ROOTS "$DEVOPS_ANSIBLE_CORE_PACKAGE_ROOTS" \
      DEVOPS_ANSIBLE_CORE_DIST_INFO_ROOT "$DEVOPS_ANSIBLE_CORE_DIST_INFO_ROOT" \
      DEVOPS_ANSIBLE_CORE_MAX_ARCHIVE_MEMBERS "$DEVOPS_ANSIBLE_CORE_MAX_ARCHIVE_MEMBERS" \
      DEVOPS_ANSIBLE_CORE_MAX_EXTRACTED_BYTES "$DEVOPS_ANSIBLE_CORE_MAX_EXTRACTED_BYTES" \
      DEVOPS_ANSIBLE_CORE_INSTALL_ROOT "$DEVOPS_ANSIBLE_CORE_INSTALL_ROOT" \
      DEVOPS_ANSIBLE_CORE_BINARY_PATH "$DEVOPS_ANSIBLE_CORE_BINARY_PATH" \
      DEVOPS_OPENTOFU_VERSION "$DEVOPS_OPENTOFU_VERSION" \
      DEVOPS_OPENTOFU_URL "$DEVOPS_OPENTOFU_URL" \
      DEVOPS_OPENTOFU_SHA256 "$DEVOPS_OPENTOFU_SHA256" \
      DEVOPS_OPENTOFU_ARCHITECTURE "$DEVOPS_OPENTOFU_ARCHITECTURE" \
      DEVOPS_OPENTOFU_ARCHIVE_FILENAME "$DEVOPS_OPENTOFU_ARCHIVE_FILENAME" \
      DEVOPS_OPENTOFU_ARCHIVE_FILES "$DEVOPS_OPENTOFU_ARCHIVE_FILES" \
      DEVOPS_OPENTOFU_INSTALL_ROOT "$DEVOPS_OPENTOFU_INSTALL_ROOT" \
      DEVOPS_OPENTOFU_BINARY_PATH "$DEVOPS_OPENTOFU_BINARY_PATH" \
      DEVOPS_TERRAFORM_VERSION "$DEVOPS_TERRAFORM_VERSION" \
      DEVOPS_TERRAFORM_URL "$DEVOPS_TERRAFORM_URL" \
      DEVOPS_TERRAFORM_SHA256 "$DEVOPS_TERRAFORM_SHA256" \
      DEVOPS_TERRAFORM_ARCHITECTURE "$DEVOPS_TERRAFORM_ARCHITECTURE" \
      DEVOPS_TERRAFORM_ARCHIVE_FILENAME "$DEVOPS_TERRAFORM_ARCHIVE_FILENAME" \
      DEVOPS_TERRAFORM_ARCHIVE_FILES "$DEVOPS_TERRAFORM_ARCHIVE_FILES" \
      DEVOPS_TERRAFORM_INSTALL_ROOT "$DEVOPS_TERRAFORM_INSTALL_ROOT" \
      DEVOPS_TERRAFORM_BINARY_PATH "$DEVOPS_TERRAFORM_BINARY_PATH" \
      DEVOPS_PACKER_VERSION "$DEVOPS_PACKER_VERSION" \
      DEVOPS_PACKER_URL "$DEVOPS_PACKER_URL" \
      DEVOPS_PACKER_SHA256 "$DEVOPS_PACKER_SHA256" \
      DEVOPS_PACKER_ARCHITECTURE "$DEVOPS_PACKER_ARCHITECTURE" \
      DEVOPS_PACKER_ARCHIVE_FILENAME "$DEVOPS_PACKER_ARCHIVE_FILENAME" \
      DEVOPS_PACKER_ARCHIVE_FILES "$DEVOPS_PACKER_ARCHIVE_FILES" \
      DEVOPS_PACKER_INSTALL_ROOT "$DEVOPS_PACKER_INSTALL_ROOT" \
      DEVOPS_PACKER_BINARY_PATH "$DEVOPS_PACKER_BINARY_PATH" \
      DEVOPS_WRANGLER_VERSION "$DEVOPS_WRANGLER_VERSION" \
      DEVOPS_WRANGLER_URL "$DEVOPS_WRANGLER_URL" \
      DEVOPS_WRANGLER_SHA512 "$DEVOPS_WRANGLER_SHA512" \
      DEVOPS_WRANGLER_NPM_INTEGRITY "$DEVOPS_WRANGLER_NPM_INTEGRITY" \
      DEVOPS_WRANGLER_ARCHITECTURE "$DEVOPS_WRANGLER_ARCHITECTURE" \
      DEVOPS_WRANGLER_ARCHIVE_FILENAME "$DEVOPS_WRANGLER_ARCHIVE_FILENAME" \
      DEVOPS_WRANGLER_ARCHIVE_ROOT "$DEVOPS_WRANGLER_ARCHIVE_ROOT" \
      DEVOPS_WRANGLER_PACKAGE_NAME "$DEVOPS_WRANGLER_PACKAGE_NAME" \
      DEVOPS_WRANGLER_NODE_REQUIREMENT "$DEVOPS_WRANGLER_NODE_REQUIREMENT" \
      DEVOPS_WRANGLER_NODE_ROOT "$DEVOPS_WRANGLER_NODE_ROOT" \
      DEVOPS_WRANGLER_NPM_REGISTRY_URL "$DEVOPS_WRANGLER_NPM_REGISTRY_URL" \
      DEVOPS_WRANGLER_INSTALL_ROOT "$DEVOPS_WRANGLER_INSTALL_ROOT" \
      DEVOPS_WRANGLER_BINARY_PATH "$DEVOPS_WRANGLER_BINARY_PATH" \
      DEVOPS_APTLY_RELEASE_VERSION "$DEVOPS_APTLY_RELEASE_VERSION" \
      DEVOPS_APTLY_RELEASE_URL "$DEVOPS_APTLY_RELEASE_URL" \
      DEVOPS_APTLY_RELEASE_SHA256 "$DEVOPS_APTLY_RELEASE_SHA256" \
      DEVOPS_APTLY_RELEASE_ARCHITECTURE "$DEVOPS_APTLY_RELEASE_ARCHITECTURE" \
      DEVOPS_APTLY_RELEASE_ARCHIVE_FILENAME "$DEVOPS_APTLY_RELEASE_ARCHIVE_FILENAME" \
      DEVOPS_APTLY_RELEASE_ARCHIVE_ROOT "$DEVOPS_APTLY_RELEASE_ARCHIVE_ROOT" \
      DEVOPS_APTLY_RELEASE_ARCHIVE_FILES "$DEVOPS_APTLY_RELEASE_ARCHIVE_FILES" \
      DEVOPS_APTLY_INSTALL_ROOT "$DEVOPS_APTLY_INSTALL_ROOT" \
      DEVOPS_APTLY_BINARY_PATH "$DEVOPS_APTLY_BINARY_PATH" \
      DEVOPS_OSC_RELEASE_VERSION "$DEVOPS_OSC_RELEASE_VERSION" \
      DEVOPS_OSC_RELEASE_URL "$DEVOPS_OSC_RELEASE_URL" \
      DEVOPS_OSC_RELEASE_SHA256 "$DEVOPS_OSC_RELEASE_SHA256" \
      DEVOPS_OSC_RELEASE_ARCHITECTURE "$DEVOPS_OSC_RELEASE_ARCHITECTURE" \
      DEVOPS_OSC_RELEASE_ARCHIVE_FILENAME "$DEVOPS_OSC_RELEASE_ARCHIVE_FILENAME" \
      DEVOPS_OSC_RELEASE_PACKAGE_ROOT "$DEVOPS_OSC_RELEASE_PACKAGE_ROOT" \
      DEVOPS_OSC_RELEASE_DIST_INFO_ROOT "$DEVOPS_OSC_RELEASE_DIST_INFO_ROOT" \
      DEVOPS_OSC_INSTALL_ROOT "$DEVOPS_OSC_INSTALL_ROOT" \
      DEVOPS_OSC_BINARY_PATH "$DEVOPS_OSC_BINARY_PATH" \
      DEVOPS_OBS_BUILD_TAG "$DEVOPS_OBS_BUILD_TAG" \
      DEVOPS_OBS_BUILD_COMMIT "$DEVOPS_OBS_BUILD_COMMIT" \
      DEVOPS_OBS_BUILD_URL "$DEVOPS_OBS_BUILD_URL" \
      DEVOPS_OBS_BUILD_SHA256 "$DEVOPS_OBS_BUILD_SHA256" \
      DEVOPS_OBS_BUILD_ARCHITECTURE "$DEVOPS_OBS_BUILD_ARCHITECTURE" \
      DEVOPS_OBS_BUILD_ARCHIVE_FILENAME "$DEVOPS_OBS_BUILD_ARCHIVE_FILENAME" \
      DEVOPS_OBS_BUILD_ARCHIVE_ROOT "$DEVOPS_OBS_BUILD_ARCHIVE_ROOT" \
      DEVOPS_OBS_BUILD_INSTALL_ROOT "$DEVOPS_OBS_BUILD_INSTALL_ROOT" \
      DEVOPS_OBS_BUILD_BINARY_PATH "$DEVOPS_OBS_BUILD_BINARY_PATH" \
      DEVOPS_OBS_BUILD_ENTRYPOINTS "$DEVOPS_OBS_BUILD_ENTRYPOINTS"
  then
    rm -f -- "$helper_host_path" "$policy_host_path" "$plugins_manifest_host_path"
    devops_fatal "failed to render upstream DevOps tool policy"
  fi
  chown root:root "$policy_host_path"
  chmod 0600 "$policy_host_path"

  if ! run_in_target \
    "download, validate, and install pinned upstream DevOps tools" \
    __INSTALLER_PATH_DIR_USR_BIN__/python3 "$helper_target_path" --policy "$policy_target_path"
  then
    rm -f -- "$helper_host_path" "$policy_host_path" "$plugins_manifest_host_path"
    devops_fatal "upstream DevOps tool provisioning failed"
  fi
  rm -f -- "$helper_host_path" "$policy_host_path" "$plugins_manifest_host_path"
  unset plugins_manifest_target_path plugins_manifest_host_path \
    plugins_manifest_source_path plugins_manifest_rendered_path
}

devops_install_pinned_rustup() {
  # Rustup's official archive publishes a checksum-addressed bootstrap
  # executable. Stage that profile-selected executable atomically at the
  # requested global path; account toolchains remain in /pool-backed state.
  # shellcheck disable=SC2016
  run_in_target "download and install pinned Rustup bootstrap" __INSTALLER_PATH_DIR_BIN__/sh -eu -c '
umask 022

rustup_fatal() {
  printf "fatal: %s\n" "$*" >&2
  exit 1
}

[ "$#" -eq 7 ] || rustup_fatal "Rustup argument contract requires 7 values (received $#)"

rustup_require_command() {
  command -v "$1" >__INSTALLER_PATH_DIR_DEV__/null 2>&1 ||
    rustup_fatal "required command is unavailable: $1"
}

rustup_validate_positive_integer() {
  label=$1
  value=$2

  case "$value" in
    ""|*[!0123456789]*) rustup_fatal "${label} must be a positive integer" ;;
  esac
  [ "$value" -gt 0 ] || rustup_fatal "${label} must be greater than zero"
}

rustup_version=$1
rustup_url=$2
expected_sha256=$3
target_triple=$4
install_dir=$5
rustup_init_path=$6
download_timeout=$7
rustup_archive_filename=${rustup_url##*/}
install_parent=${install_dir%/*}
binary_dir=${rustup_init_path%/*}

printf "%s\n" "$rustup_version" |
  grep -Eq "^[0-9]+\.[0-9]+\.[0-9]+$" ||
  rustup_fatal "Rustup version is not semantic"
[ "$target_triple" = x86_64-unknown-linux-gnu ] ||
  rustup_fatal "Rustup target triple is not the managed Linux AMD64 target"
case "$rustup_url" in
  https://*/*) ;;
  *) rustup_fatal "Rustup source URL must be HTTPS and include a release filename" ;;
esac
[ -n "$rustup_archive_filename" ] ||
  rustup_fatal "Rustup source URL has no release filename"
case "$rustup_archive_filename" in
  */*) rustup_fatal "Rustup source URL filename must not contain a slash" ;;
esac
case "$install_dir" in
  /*|/*/*) ;;
  *) rustup_fatal "Rustup install root must be absolute" ;;
esac
case "$rustup_init_path" in
  "$install_dir"/*) ;;
  *) rustup_fatal "Rustup binary path must be below the managed install root" ;;
esac
[ "${#expected_sha256}" -eq 64 ] ||
  rustup_fatal "Rustup SHA-256 must contain 64 lowercase hexadecimal characters"
case "$expected_sha256" in
  *[!0123456789abcdef]*)
    rustup_fatal "Rustup SHA-256 must contain 64 lowercase hexadecimal characters"
    ;;
esac
rustup_validate_positive_integer "download timeout" "$download_timeout"

for required_command in awk chown curl grep install mktemp rm sha256sum tr wc; do
  rustup_require_command "$required_command"
done
unset required_command

[ -d "$install_parent" ] || install -d -m 0755 "$install_parent"
[ ! -L "$install_parent" ] ||
  rustup_fatal "${install_parent} must not be a symlink"
[ ! -e "$install_dir" ] && [ ! -L "$install_dir" ] ||
  rustup_fatal "Rustup install path already exists; this fresh-install helper will not replace it: $install_dir"

staging_dir=$(mktemp -d "${install_parent}/.devops-rustup.XXXXXXXX") ||
  rustup_fatal "unable to allocate Rustup staging directory"
cleanup() {
  rm -rf -- "$staging_dir"
}
trap cleanup EXIT HUP INT TERM

payload_path="${staging_dir}/${rustup_archive_filename}"
curl \
  --fail \
  --silent \
  --show-error \
  --location \
  --proto "=https" \
  --tlsv1.2 \
  --retry 3 \
    --retry-delay 2 \
    --connect-timeout 15 \
    --max-time "$download_timeout" \
  --output "$payload_path" \
  "$rustup_url" ||
    rustup_fatal "failed to download pinned Rustup bootstrap: $rustup_url"

actual_sha256=$(sha256sum "$payload_path" | awk "{print \$1}")
[ "$actual_sha256" = "$expected_sha256" ] ||
  rustup_fatal "Rustup bootstrap SHA-256 mismatch"

install -d -m 0755 "$binary_dir"
install -m 0755 "$payload_path" "$rustup_init_path"
chown root:root "$install_dir" "$binary_dir" "$rustup_init_path"
{
  printf "version=%s\n" "$rustup_version"
  printf "source_url=%s\n" "$rustup_url"
  printf "sha256=%s\n" "$expected_sha256"
  printf "architecture=%s\n" "$target_triple"
} >"${install_dir}/.rustup-bootstrap"
chmod 0644 "${install_dir}/.rustup-bootstrap"
chown root:root "${install_dir}/.rustup-bootstrap"

printf "installed Rustup %s bootstrap at %s\n" "$rustup_version" "$rustup_init_path"
' sh \
    "$DEVOPS_RUSTUP_VERSION" \
    "$DEVOPS_RUSTUP_URL" \
    "$DEVOPS_RUSTUP_SHA256" \
    "$DEVOPS_RUSTUP_TARGET_TRIPLE" \
    "$DEVOPS_RUSTUP_INSTALL_ROOT" \
    "$DEVOPS_RUSTUP_BINARY_PATH" \
    "$DEVOPS_UPSTREAM_DOWNLOAD_TIMEOUT_SECONDS"
}

devops_install_pinned_rust_cli_binaries() {
  helper_repo_path=$(installer_repo_file_value scripts/late/devops-rust-tools.py)
  helper_target_path=/tmp/installer-devops-rust-tools.py
  helper_host_path="${target_root}${helper_target_path}"

  [ ! -e "$helper_host_path" ] && [ ! -L "$helper_host_path" ] ||
    devops_fatal "temporary prebuilt Rust tool installer path already exists"
  bootstrap_fetch_seed_file \
    "$seed_base" \
    "$helper_repo_path" \
    "$helper_host_path" \
    0755 \
    "prebuilt Rust tool installer ${helper_repo_path}"
  chown root:root "$helper_host_path"

  if ! devops_run_as_account \
    "download, validate, and install selected pinned Rust CLI archives" \
    __INSTALLER_PATH_DIR_USR_BIN__/python3 "$helper_target_path" \
      --install-root "$CARGO_INSTALL_ROOT" \
      --download-timeout-seconds "$DEVOPS_UPSTREAM_DOWNLOAD_TIMEOUT_SECONDS" \
      --max-archive-members "$DEVOPS_UPSTREAM_MAX_ARCHIVE_MEMBERS" \
      --max-extracted-bytes "$DEVOPS_UPSTREAM_MAX_EXTRACTED_BYTES" \
      --binstall-version "$DEVOPS_CARGO_BINSTALL_VERSION" \
      --binstall-url "$DEVOPS_CARGO_BINSTALL_URL" \
      --binstall-sha256 "$DEVOPS_CARGO_BINSTALL_SHA256" \
      --binstall-architecture "$DEVOPS_CARGO_BINSTALL_ARCHITECTURE" \
      --binstall-archive-filename "$DEVOPS_CARGO_BINSTALL_ARCHIVE_FILENAME" \
      --binstall-archive-files "$DEVOPS_CARGO_BINSTALL_ARCHIVE_FILES" \
      --dotslash-source-build "$DEVOPS_DOTSLASH_SOURCE_BUILD" \
      --dotslash-version "$DEVOPS_DOTSLASH_VERSION" \
      --dotslash-url "$DEVOPS_DOTSLASH_URL" \
      --dotslash-sha256 "$DEVOPS_DOTSLASH_SHA256" \
      --dotslash-architecture "$DEVOPS_DOTSLASH_ARCHITECTURE" \
      --dotslash-archive-filename "$DEVOPS_DOTSLASH_ARCHIVE_FILENAME" \
      --dotslash-archive-files "$DEVOPS_DOTSLASH_ARCHIVE_FILES" \
      --uv-source-build "$DEVOPS_UV_SOURCE_BUILD" \
      --uv-version "$DEVOPS_UV_VERSION" \
      --uv-url "$DEVOPS_UV_URL" \
      --uv-sha256 "$DEVOPS_UV_SHA256" \
      --uv-architecture "$DEVOPS_UV_ARCHITECTURE" \
      --uv-archive-filename "$DEVOPS_UV_ARCHIVE_FILENAME" \
      --uv-archive-root "$DEVOPS_UV_ARCHIVE_ROOT" \
      --uv-archive-files "$DEVOPS_UV_ARCHIVE_FILES"
  then
    rm -f -- "$helper_host_path"
    devops_fatal "prebuilt Rust CLI tool provisioning failed"
  fi

  rm -f -- "$helper_host_path"
  [ ! -e "$helper_host_path" ] && [ ! -L "$helper_host_path" ] ||
    devops_fatal "temporary prebuilt Rust tool installer remains after installation"
}
