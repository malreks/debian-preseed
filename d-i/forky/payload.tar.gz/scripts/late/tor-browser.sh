#!/bin/sh
# shellcheck disable=SC2154
# Sourced only by the Software installer after its class/architecture gates.

software_install_tor_media_runtime() {
  # Forky's unversioned libavcodec-extra now selects FFmpeg 9 / ABI 63.
  # The pinned Firefox ESR 140 browser supports ABI 62, not ABI 63. Keep
  # the versioned compatibility libraries alongside the current system FFmpeg.
  # Existing signed repository policy supplies these packages (currently Sid);
  # never add a repository, weaken signature checks or replace the system ABI.
  if ! run_in_target "install Tor Browser compatible FFmpeg runtime" \
    __INSTALLER_PATH_DIR_USR_BIN__/env -i DEBIAN_FRONTEND=noninteractive DEBCONF_NONINTERACTIVE_SEEN=true \
    NEEDRESTART_SUSPEND=1 HOME=__INSTALLER_PATH_DIR_ROOT_HOME__ LC_ALL=C.UTF-8 PATH=__INSTALLER_PATH_DIR_USR__/sbin:__INSTALLER_PATH_DIR_USR__/bin:__INSTALLER_PATH_DIR_SBIN__:__INSTALLER_PATH_DIR_BIN__ \
    __INSTALLER_PATH_DIR_USR_BIN__/timeout --signal=TERM --kill-after=5s 300s \
    __INSTALLER_PATH_DIR_USR_BIN__/apt-get -y -o DPkg::Lock::Timeout=60 -o DPkg::Use-Pty=0 \
      --no-remove --no-install-recommends --no-install-suggests \
      install libavcodec62 libavutil60 libswresample6
  then
    software_fatal "Tor Browser requires libavcodec62, libavutil60 and libswresample6 from the configured signed repositories; the unversioned FFmpeg 9 packages do not supply ABI 62"
  fi
}

software_download_tor_browser_asset() {
  tor_asset_label=$1
  tor_primary_url=$2
  tor_archive_url=$3
  tor_asset_destination=$4
  tor_asset_content_policy=$5

  if software_download \
    "$tor_asset_label" \
    "$tor_primary_url" \
    "$tor_asset_destination" \
    "$tor_asset_content_policy" \
    retry
  then
    return 0
  fi

  software_info "${tor_asset_label} primary URL failed; retrying the configured official Tor fallback"
  if software_download \
    "$tor_asset_label" \
    "$tor_archive_url" \
    "$tor_asset_destination" \
    "$tor_asset_content_policy" \
    retry
  then
    return 0
  fi
  software_warn "${tor_asset_label} failed at both official origins after the three-retry budget"
  return 75
}

software_install_tor_browser() (
  tor_version=${SOFTWARE_TOR_BROWSER_VERSION:?SOFTWARE_TOR_BROWSER_VERSION must be set}
  tor_url=${SOFTWARE_TOR_BROWSER_URL:?SOFTWARE_TOR_BROWSER_URL must be set}
  tor_sha=${SOFTWARE_TOR_BROWSER_SHA256:?SOFTWARE_TOR_BROWSER_SHA256 must be set}
  tor_key_sha=${SOFTWARE_TOR_BROWSER_KEY_SHA256:?SOFTWARE_TOR_BROWSER_KEY_SHA256 must be set}
  software_validate_release_version SOFTWARE_TOR_BROWSER_VERSION "$tor_version"
  software_validate_sha256 SOFTWARE_TOR_BROWSER_SHA256 "$tor_sha"
  software_validate_sha256 SOFTWARE_TOR_BROWSER_KEY_SHA256 "$tor_key_sha"
  case "$tor_url" in https://*/*) ;; *) software_fatal "Tor Browser URL must be an HTTPS release URL" ;; esac
  tor_archive_url=${SOFTWARE_TOR_BROWSER_ARCHIVE_FALLBACK_URL:?SOFTWARE_TOR_BROWSER_ARCHIVE_FALLBACK_URL must be set}
  software_install_tor_media_runtime
  tor_archive="${work_dir}/tor-browser.tar.xz"
  tor_signature="${work_dir}/tor-browser.tar.xz.asc"
  tor_key=__INSTALLER_PATH_DIR_USR_LOCAL_SHARE_SOFTWARE__/tor-browser/developers.asc
  tor_install_helper=__INSTALLER_PATH_DIR_USR_LOCAL_LIBEXEC__/tor-browser-install
  software_stage_seed_asset \
    "$(installer_repo_file_value hooks/target/usr/local/share/desktop/software/tor-browser/developers.asc)" \
    "$tor_key" 0644
  software_stage_seed_asset \
    "$(installer_repo_file_value hooks/target/usr/local/libexec/desktop/tor-browser-install)" \
    "$tor_install_helper" 0755
  software_download_tor_browser_asset \
    "Tor Browser" \
    "$tor_url" \
    "$tor_archive_url" \
    "$tor_archive" \
    artifact
  software_download_tor_browser_asset \
    "Tor Browser signature" \
    "${tor_url}.asc" \
    "${tor_archive_url}.asc" \
    "$tor_signature" \
    signature
  # Target execution does not inherit installer path variables. Pass the
  # rendered helper and private work directory as data, never shell source.
  run_in_target "authenticate and install Tor Browser" __INSTALLER_PATH_DIR_BIN__/sh -eu -c '
    umask 077
    archive=$1; signature=$2; key=$3; expected=$4; key_expected=$5; fingerprint=$6
    installer=$7; work_dir=$8
    key_actual=$(sha256sum "$key"); [ "${key_actual%% *}" = "$key_expected" ]
    actual=$(sha256sum "$archive"); [ "${actual%% *}" = "$expected" ]
    key_home=$(mktemp -d "$work_dir/tor-verify.XXXXXX")
    trap '\''rm -rf -- "$key_home"'\'' 0
    trap '\''exit 129'\'' HUP
    trap '\''exit 130'\'' INT
    trap '\''exit 143'\'' TERM
    __INSTALLER_PATH_DIR_USR_BIN__/gpg --batch --no-options --homedir "$key_home" --dearmor \
      --output "$key_home/developers.gpg" "$key"
    __INSTALLER_PATH_DIR_USR_BIN__/gpgv --homedir "$key_home" --keyring "$key_home/developers.gpg" \
      --status-fd 1 "$signature" "$archive" >"$key_home/status"
    __INSTALLER_PATH_DIR_USR_BIN__/awk -v expected="$fingerprint" '\''$1 == "[GNUPG:]" && $2 == "VALIDSIG" &&
      ($3 == expected || $NF == expected) { valid++ }
      END { exit valid != 1 }'\'' "$key_home/status"
    __INSTALLER_PATH_DIR_USR_BIN__/python3 -I -B "$installer" "$archive"
  ' sh "$tor_archive" "$tor_signature" "$tor_key" "$tor_sha" "$tor_key_sha" \
    "$SOFTWARE_TOR_BROWSER_SIGNING_FINGERPRINT" "$tor_install_helper" "$work_dir"
  # The root-owned immutable bundle is maintained through release pins and
  # installer publication; never permit a browser-owned binary replacement.
  software_stage_seed_asset \
    "$(installer_repo_file_value hooks/target/opt/tor-browser/Browser/distribution/policies.json)" \
    __INSTALLER_PATH_DIR_OPT_TOR_BROWSER__/Browser/distribution/policies.json 0644
  software_stage_seed_asset \
    "$(installer_repo_file_value hooks/target/usr/local/libexec/desktop/tor-browser-run)" \
    __INSTALLER_PATH_DIR_USR_LOCAL_LIBEXEC__/tor-browser-run 0755
  software_stage_seed_asset \
    "$(installer_repo_file_value hooks/target/usr/local/share/desktop/applications/tor-browser.desktop.tmpl)" \
    __INSTALLER_PATH_DIR_USR_LOCAL_SHARE_APPLICATIONS__/tor-browser.desktop 0644
  software_info "installed authenticated Tor Browser version=${tor_version} sha256=${tor_sha}"
)
