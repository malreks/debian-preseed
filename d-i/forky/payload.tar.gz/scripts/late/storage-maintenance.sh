#!/bin/sh
# Shared late_command storage maintenance helpers. This file is sourced, not executed.


finish_target_pkgsel_apt_state() {
  # pkgsel owns the complete compiled package list. Only retire its
  # temporary legacy-NVIDIA/CUDA repository here; do not rescan/reinstall it.
  # Driver-only selections also publish this source and need the same cleanup.
  installer_cuda_remove_target_source
}

managed_target_policy_assets() {
  cat <<'EOF'
etc/login.defs|__INSTALLER_PATH_DIR_ETC__/login.defs|0644
etc/pam.d/polkit-1|__INSTALLER_PATH_DIR_ETC__/pam.d/polkit-1|0644
etc/pam.d/systemd-user|__INSTALLER_PATH_DIR_ETC__/pam.d/systemd-user|0644
etc/systemd/system/apt-daily-upgrade.service.d/50-unattended-upgrades-notify.conf|__INSTALLER_PATH_DIR_SYSTEMD_SYSTEM_APT_DAILY_UPGRADE_DROPIN__/50-unattended-upgrades-notify.conf|0644
etc/systemd/system/fwupd.service.d/20-upower-ordering.conf|__INSTALLER_PATH_DIR_SYSTEMD_SYSTEM_FWUPD_DROPIN__/20-upower-ordering.conf|0644
etc/systemd/system/unattended-upgrades.service.d/override.conf|__INSTALLER_PATH_DIR_SYSTEMD_SYSTEM_UNATTENDED_UPGRADES_DROPIN__/override.conf|0644
usr/local/libexec/unattended-upgrades-notify|__INSTALLER_PATH_DIR_USR_LOCAL__/libexec/unattended-upgrades-notify|0755
EOF
}

stage_target_apt_login_policy_assets() {
  installer_apt_install_target_policy "$TARGET_ROOT" install
  while IFS='|' read -r repo_relpath target_path mode || [ -n "$repo_relpath" ]; do
    [ -n "$repo_relpath" ] || continue
    stage_target_asset "$(installer_repo_asset_path DIR_HOOKS_TARGET "$repo_relpath")" "$target_path" "$mode"
  done <<EOF
$(managed_target_policy_assets)
EOF
}

stage_target_conditional_apt_refresh_assets() {
  if tmpfs_policy_enabled TMPFS_VAR_LIB_APT_LISTS; then
    render_target_template "$TMP_ENV_DIR/apt-refresh-lists.tmpl" "${TARGET_ROOT}${FILE_APT_REFRESH_LISTS_HELPER}" 0755
    render_target_template "$TMP_ENV_DIR/apt-refresh-lists.service.tmpl" "${TARGET_ROOT}${FILE_APT_REFRESH_LISTS_SERVICE}" 0644
  else
    remove_target_asset "${FILE_APT_REFRESH_LISTS_HELPER}"
    remove_target_asset "${FILE_APT_REFRESH_LISTS_SERVICE}"
    remove_target_asset "__INSTALLER_PATH_DIR_ETC__/systemd/system/multi-user.target.wants/apt-refresh-lists.service"
  fi
}

validate_target_tmpfiles_policy_path() {
  case "${1:-}" in
    /*) ;;
    *) installer_fatal "managed tmpfiles policy path must be absolute: ${1:-unset}" ;;
  esac
  case "$1" in
    /|*..*|*//*|*[!ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._/-]*)
      installer_fatal "managed tmpfiles policy path contains unsupported syntax: ${1}"
      ;;
  esac
}

normalize_target_tmpfiles_directory_policy() {
  tmpfiles_policy_path=$1
  tmpfiles_policy_label=${2:-managed tmpfiles directory policy}

  validate_target_tmpfiles_policy_path "$tmpfiles_policy_path"
  # Desktop staging may have queued this policy in the shared publication
  # batch. The shell reads it before the target setup helper reaches
  # target_exec, so publish pending inputs at this direct-reader boundary.
  installer_asset_batch_flush || return $?
  [ -r "${TARGET_ROOT}${tmpfiles_policy_path}" ] ||
    installer_fatal "managed tmpfiles policy is missing before normalization: ${tmpfiles_policy_path}"

  # The short-lived installer program validates the complete d-row plan,
  # pins directory identities and retains durable recovery data on uncertainty.
  # Non-directory tmpfiles records remain the native tool's separate owner.
  installer_run_target_setup scripts/late/tmpfiles-directories.py.tmpl \
    "normalize ${tmpfiles_policy_label}" "$tmpfiles_policy_path" "$tmpfiles_policy_label" || return "$?"
}

stage_target_runtime_storage_root_policy() {
  render_target_asset "$(installer_repo_file_value hooks/target/etc/tmpfiles.d/desktop/10-runtime-storage-roots.conf.tmpl)" "__INSTALLER_PATH_DIR_ETC__/tmpfiles.d/10-runtime-storage-roots.conf" 0644
}

ensure_target_managed_runtime_storage_roots() {
  run_in_target_quiet "ensure shared devops group" __INSTALLER_PATH_DIR_BIN__/sh -eu -c '
getent group devops >__INSTALLER_PATH_DIR_DEV__/null 2>&1 || groupadd --system devops
' sh
  stage_target_runtime_storage_root_policy
  normalize_target_tmpfiles_directory_policy "__INSTALLER_PATH_DIR_ETC__/tmpfiles.d/10-runtime-storage-roots.conf" "shared runtime storage roots"
}

# Global manager/delegation policy is installed even without the desktop role.
# Manager defaults are not tied to a filesystem or to user-slice publication.
# Reapply at the final desktop boundary so the selected profile is authoritative.
stage_target_systemd_manager_accounting() (
  set -eu
  for resource_asset in \
    etc/systemd/system.conf.d/60-resource-accounting.conf \
    etc/systemd/user.conf.d/60-resource-accounting.conf
  do
    render_target_resource_asset \
      "$(installer_repo_asset_path DIR_HOOKS_TARGET "$resource_asset")" \
      "/$resource_asset" 0644 || exit 1
  done
)

stage_target_systemd_resource_policy_assets() (
  set -eu
  # Base-stage already validated the frozen resource map used by publication.
  stage_target_systemd_manager_accounting || exit 1
  for resource_asset in \
    etc/systemd/system/user@.service.d/60-resource-delegation.conf \
    etc/systemd/coredump.conf.d/60-limits.conf \
    etc/systemd/system/systemd-coredump.socket.d/60-poll-limit.conf \
    etc/systemd/system/system-maintenance.slice \
    etc/systemd/system/system-maintenance.slice.d/60-resources.conf \
    etc/systemd/system/system-background.slice \
    etc/systemd/system/system-background.slice.d/60-resources.conf \
    etc/systemd/system/apt-daily.service.d/60-resource-class.conf \
    etc/systemd/system/apt-daily-upgrade.service.d/60-resource-class.conf
  do
    render_target_resource_asset \
      "$(installer_repo_asset_path DIR_HOOKS_TARGET "$resource_asset")" \
      "/$resource_asset" 0644 || exit 1
  done
)

stage_target_common_storage_maintenance_assets() {
  # Shared by scheduled APT and desktop network consumers. Stage code only;
  # never probe connectivity or contact a service while preparing the target.
  stage_target_asset "$(installer_repo_file_value hooks/target/usr/local/libexec/common/network-online-check)" "${DIR_USR_LOCAL_LIBEXEC}/network-online-check" 0755 || return 1
  # Shared by both storage families. Install rules only; never retrigger live
  # installer devices or modify their PCI configuration while staging the target.
  stage_target_asset "$(installer_repo_file_value hooks/target/etc/udev/rules.d/74-nvme-link-idle.rules)" "__INSTALLER_PATH_DIR_ETC__/udev/rules.d/74-nvme-link-idle.rules" 0644 || return 1
  stage_target_asset "$(installer_repo_file_value hooks/target/usr/local/sbin/common/nvme-pcie-status)" "__INSTALLER_PATH_DIR_USR_LOCAL__/sbin/nvme-pcie-status" 0755 || return 1
  stage_target_asset "$(installer_repo_file_value hooks/target/etc/initramfs-tools/hooks/nvme-link-idle)" "__INSTALLER_PATH_DIR_ETC__/initramfs-tools/hooks/nvme-link-idle" 0755 || return 1
  stage_target_runtime_storage_root_policy
  stage_target_asset "$(installer_repo_file_value hooks/target/etc/tmpfiles.d/common/tmp.conf)" "__INSTALLER_PATH_DIR_ETC__/tmpfiles.d/tmp.conf" 0644
  grep -Fxq 'D! /tmp 1777 root root 0' ${TARGET_ROOT}${DIR_ETC}/tmpfiles.d/tmp.conf &&
    grep -Fxq 'e /tmp 1777 root root 7d' ${TARGET_ROOT}${DIR_ETC}/tmpfiles.d/tmp.conf &&
    grep -Fxq 'd __INSTALLER_PATH_DIR_VAR__/tmp 1777 root root 30d' ${TARGET_ROOT}${DIR_ETC}/tmpfiles.d/tmp.conf ||
    installer_fatal "managed temporary-directory tmpfiles policy is incomplete"
  stage_target_apt_login_policy_assets
  render_target_template "$TMP_ENV_DIR/apt-daily.override.conf.tmpl" "${TARGET_ROOT}${FILE_APT_DAILY_SERVICE_OVERRIDE}" 0644
  stage_target_asset "$(installer_repo_file_value scripts/late/assets/etc/apt/listchanges.conf.installer-base)" "${FILE_APT_LISTCHANGES_CONF}" 0644
  stage_target_asset "$(installer_repo_file_value hooks/target/etc/systemd/common/system/fstrim.service.d/override.conf)" "${FILE_FSTRIM_SERVICE_OVERRIDE}" 0644
  stage_target_asset "$(installer_repo_file_value hooks/target/etc/systemd/common/system/fstrim.timer.d/override.conf)" "${FILE_FSTRIM_TIMER_OVERRIDE}" 0644
}

target_xfs_scrub_cpuaccounting_units() {
  printf '%s\n' \
    xfs_scrub@.service \
    xfs_scrub_all.service \
    xfs_scrub_media@.service \
    system-xfs_scrub.slice \
    xfs_healer@.service \
    xfs_healer_start.service \
    system-xfs_healer.slice
}

sanitize_target_xfs_scrub_systemd_units() {
  sanitized_count=0

  for xfs_unit in $(target_xfs_scrub_cpuaccounting_units); do
    xfs_unit_path=$(target_systemd_unit_path "$xfs_unit" system 2>__INSTALLER_PATH_DIR_DEV__/null || true)
    [ -n "$xfs_unit_path" ] || continue
    [ -r "${TARGET_ROOT}${xfs_unit_path}" ] || continue
    grep -q '^[[:space:]]*CPUAccounting[[:space:]]*=' "${TARGET_ROOT}${xfs_unit_path}" || continue

    xfs_unit_dest="${TARGET_ROOT}${DIR_SYSTEMD_SYSTEM}/${xfs_unit}"
    xfs_unit_tmp="${xfs_unit_dest}.tmp.$$"
    install -d -m 0755 "${TARGET_ROOT}${DIR_SYSTEMD_SYSTEM}"
    if ! sed '/^[[:space:]]*CPUAccounting[[:space:]]*=/d' "${TARGET_ROOT}${xfs_unit_path}" >"$xfs_unit_tmp"; then
      rm -f "$xfs_unit_tmp"
      installer_fatal "failed to sanitize xfs scrub unit: ${xfs_unit_path}"
    fi
    [ -s "$xfs_unit_tmp" ] || {
      rm -f "$xfs_unit_tmp"
      installer_fatal "sanitized xfs scrub unit is empty: ${xfs_unit_path}"
    }
    install -m 0644 "$xfs_unit_tmp" "$xfs_unit_dest"
    rm -f "$xfs_unit_tmp"
    grep -q '^[[:space:]]*CPUAccounting[[:space:]]*=' "$xfs_unit_dest" &&
      installer_fatal "sanitized xfs scrub unit still contains a CPUAccounting directive: ${xfs_unit_dest#${TARGET_ROOT}}"

    for xfs_unit_link in "${TARGET_ROOT}${DIR_SYSTEMD_SYSTEM}"/*.wants/"$xfs_unit" "${TARGET_ROOT}${DIR_SYSTEMD_SYSTEM}"/*.requires/"$xfs_unit"; do
      [ -L "$xfs_unit_link" ] || continue
      ln -sf "${DIR_SYSTEMD_SYSTEM}/${xfs_unit}" "$xfs_unit_link"
    done
    sanitized_count=$((sanitized_count + 1))
  done

  [ "$sanitized_count" -eq 0 ] ||
    installer_info "sanitized xfs scrub systemd units with removed CPUAccounting directives: ${sanitized_count}"

  # Only stage the drop-in offline. The target's own system manager refreshes
  # its unit cache before the native healer starter scans existing mounts.
  if target_systemd_unit_path xfs_healer_start.service system >__INSTALLER_PATH_DIR_DEV__/null 2>&1; then
    stage_target_asset \
      "$(installer_repo_file_value hooks/target/etc/systemd/common/system/xfs_healer_start.service.d/20-refresh-unit-cache.conf)" \
      __INSTALLER_PATH_DIR_SYSTEMD_SYSTEM_XFS_HEALER_START_DROPIN__/20-refresh-unit-cache.conf 0644 || return 1
  fi
}




apply_apt_refresh_placeholders() {
  target_path=$1
  installer_apply_scalar_placeholders "$target_path" "$target_path.apt-refresh.$$" \
    APT_REFRESH_LISTS_TIMEOUT "$APT_REFRESH_LISTS_TIMEOUT" \
    APT_REFRESH_LISTS_CONNECTIVITY_URL "$APT_REFRESH_LISTS_CONNECTIVITY_URL"
  mv "$target_path.apt-refresh.$$" "$target_path"
}

# A subshell guarantees restoration even if the general update fails or is
# interrupted. Preserve the selected CUDA lists without extending its explicit
# authentication exception to the ordinary Debian/vendor metadata refresh.
refresh_non_cuda_target_metadata() (
  set -eu
  target="${INSTALLER_TARGET_DIR:-${TARGET_ROOT}}"
  source="${target}__INSTALLER_PATH_DIR_APT__/sources.list"
  held="${source}.installer-disabled"
  repository=${CUDA_LEGACY_REPOSITORY_URL:-}
  [ -n "$repository" ] || { installer_fatal 'CUDA legacy repository URL is unavailable while suspending its source'; exit 1; }
  temp=
  restore_cuda_source() {
    status=$?
    trap - 0 HUP INT TERM
    [ -z "$temp" ] || rm -f "$temp"
    if [ -f "$held" ]; then
      rm -f "$source"
      mv -f "$held" "$source" || [ "$status" -ne 0 ] || status=$?
    fi
    exit "$status"
  }
  [ ! -e "$held" ] || { installer_fatal 'stale CUDA source suspension; restore it before retrying'; exit 1; }
  if [ -f "$source" ] && grep -Fq "$repository" "$source"; then
    installer_apt_safe_path "$source" || exit 1
    [ "$(installer_metadata_value "$source" links)" = 1 ] || exit 1
    trap restore_cuda_source 0 HUP INT TERM
    ln "$source" "$held"
    temp=$(mktemp "${source}.cuda-free.XXXXXX")
    awk -v repository="$repository" 'index($0, repository) == 0 {print}' "$source" >"$temp"
    source_mode=$(installer_metadata_value "$source" mode)
    chmod "$source_mode" "$temp"
    mv -f "$temp" "$source"
  fi
  run_in_target 'refresh non-CUDA apt metadata with the default crypto policy' "$@"
)
