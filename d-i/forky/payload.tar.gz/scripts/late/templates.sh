#!/bin/sh
# shellcheck disable=SC2154
# Shared late_command target-template renderer. This file is sourced, not executed.

render_target_template_placeholder_map() {
  # Keep direct template rendering on the same canonical path contract as
  # plain target assets.  The map uses PATH_* names so it cannot collide with
  # the template-specific scalar records below; missing runtime values remain
  # unresolved and are rejected by the publication boundary.
  installer_runtime_path_placeholder_map ||
    installer_fatal 'unable to build the target runtime path placeholder map'
  # Runtime layout env fragments provide the zram device names for template rendering.
  # shellcheck disable=SC2153
  zram_swap_device=${ZRAM_SWAP_DEVICE}
  zram_setup_unit=${FILE_ZRAM_SETUP_SERVICE##*/}
  zram_swap_device_name=${ZRAM_SWAP_DEVICE##*/}
  zram_sysfs=${ZRAM_SYSFS:-__INSTALLER_PATH_DIR_SYS__/block/${zram_swap_device_name}}
  zram_runtime_dir=${ZRAM_RUNTIME_DIR:-__INSTALLER_PATH_DIR_RUN__/zram}
  zram_lock_file=${ZRAM_LOCK_FILE:-${zram_runtime_dir}/zram-writeback.lock}
  zram_enable=${ZRAM_ENABLE:-1}
  zram_backing_reserve_mib=${ZRAM_BACKING_RESERVE_MIB:-128}
  zram_policy_config=${ZRAM_POLICY_CONFIG:-$FILE_ZRAM_CONFIG}
  zram_backing_raw_partuuid=${ZRAM_BACKING_RAW_PARTUUID:-}
  if [ -z "$zram_backing_raw_partuuid" ] && command -v blkid >__INSTALLER_PATH_DIR_DEV__/null 2>&1; then
    zram_backing_raw_partuuid=$(blkid -s PARTUUID -o value "$ZRAM_BACKING_RAW_DEVICE" 2>__INSTALLER_PATH_DIR_DEV__/null || true)
  fi
  [ -n "$zram_backing_raw_partuuid" ] || installer_fatal "unable to determine PARTUUID for zram backing device ${ZRAM_BACKING_RAW_DEVICE}"
  zram_backing_raw_device="__INSTALLER_PATH_DIR_DEV__/disk/by-partuuid/${zram_backing_raw_partuuid}"
  account_username=${ACCOUNT_USERNAME:-}

  cat <<EOF
DIR_RUN_SYSCTL=$DIR_RUN_SYSCTL
DIR_SYSCTL_PROFILES=$DIR_SYSCTL_PROFILES
BOOTPROFILE_DEFAULT=$BOOTPROFILE_DEFAULT
BOOTPROFILE_HARDENED=$BOOTPROFILE_HARDENED
BOOTPROFILE_PERFORMANCE=$BOOTPROFILE_PERFORMANCE
FILE_BOOTPROFILE_APPLY=$FILE_BOOTPROFILE_APPLY
DIR_VAR_LOG=$DIR_VAR_LOG
DIR_VAR_CACHE=$DIR_VAR_CACHE
DIR_APT_LISTS=$DIR_APT_LISTS
DIR_APT_STATE=$DIR_APT_STATE
DIR_SYSTEMD=$DIR_SYSTEMD
DIR_SYSTEMD_COREDUMP=$DIR_SYSTEMD_COREDUMP
DIR_DATA_RUN=$DIR_DATA_RUN
DIR_DATA_RUN_MNT=$DIR_DATA_RUN_MNT
DIR_RUN_MEDIA=$DIR_RUN_MEDIA
DIR_DATA=$DIR_DATA
DIR_DATA_CONFIG=$DIR_DATA_CONFIG
DIR_DATA_SERVICES=$DIR_DATA_SERVICES
DIR_DATA_SERVICES_USR=$DIR_DATA_SERVICES_USR
DIR_DATA_BIN=$DIR_DATA_BIN
DIR_DATA_DOCS=$DIR_DATA_DOCS
DIR_DATA_DOWNLOADS=$DIR_DATA_DOWNLOADS
DIR_DATA_PKI=$DIR_DATA_PKI
DIR_DATA_BACKUP=$DIR_DATA_BACKUP
DIR_POOL=$DIR_POOL
DIR_POOL_TMP=$DIR_POOL_TMP
DIR_POOL_BUILD=$DIR_POOL_BUILD
DIR_POOL_BUILD_RUNNERS=$DIR_POOL_BUILD_RUNNERS
DIR_POOL_CACHE=$DIR_POOL_CACHE
DIR_POOL_CACHE_RUNNERS=$DIR_POOL_CACHE_RUNNERS
DIR_POOL_DB=$DIR_POOL_DB
DIR_POOL_PODMAN=$DIR_POOL_PODMAN
DIR_POOL_LOG=$DIR_POOL_LOG
DIR_POOL_APTLY=$DIR_POOL_APTLY
DIR_POLKIT_LOCAL_RULES_D=${DIR_POLKIT_LOCAL_RULES_D:-}
DIR_POLKIT_RUNTIME_RULES_D=${DIR_POLKIT_RUNTIME_RULES_D:-}
ACCOUNT_USERNAME=$account_username
SYSTEM_HOSTNAME=${SYSTEM_HOSTNAME:-}
SYSTEM_DOMAIN=${SYSTEM_DOMAIN:-}
INSTALLER_DEBUG_LOGS=${INSTALLER_DEBUG_LOGS:-0}
SYSTEMD_LOG_LEVEL=${SYSTEMD_LOG_LEVEL:-error}
NFTABLES_LOG_LEVEL=${NFTABLES_LOG_LEVEL:-none}
DIR_VAR_TMP=${DIR_VAR_TMP:-}
DIR_TMP=$DIR_TMP
DIR_DEV_SHM=$DIR_DEV_SHM
FILE_ZRAM_DEFAULT=$FILE_ZRAM_DEFAULT
FILE_ZRAM_CONFIG=$FILE_ZRAM_CONFIG
FILE_ZRAM_SETUP_HELPER=$FILE_ZRAM_SETUP_HELPER
FILE_ZRAM_WRITEBACK_HELPER=$FILE_ZRAM_WRITEBACK_HELPER
GRUB_DEFAULT_ENTRY=$GRUB_DEFAULT_ENTRY
GRUB_ROOT_FLAGS=$GRUB_ROOT_FLAGS
GRUB_INITRAMFS_FLAGS=$GRUB_INITRAMFS_FLAGS
GRUB_NVME_FLAGS=${GRUB_NVME_FLAGS:-}
GRUB_SYSTEMD_MASK_FLAGS=${GRUB_SYSTEMD_MASK_FLAGS:-}
GRUB_CGROUP_FLAGS=$GRUB_CGROUP_FLAGS
GRUB_SECURITY_CORE_FLAGS=$GRUB_SECURITY_CORE_FLAGS
GRUB_BLACKLIST_FLAGS=${GRUB_BLACKLIST_FLAGS:-}
GRUB_VFIO_FLAGS=${GRUB_VFIO_FLAGS:-}
GRUB_MEMORY_CORE_FLAGS=$GRUB_MEMORY_CORE_FLAGS
GRUB_HARDENING_FLAGS=$GRUB_HARDENING_FLAGS
GRUB_ASPM_FLAGS=${GRUB_ASPM_FLAGS:-}
GRUB_MOK_MANAGER_EFI_PATH=$INSTALLER_GRUB_MOK_MANAGER_EFI_PATH
GRUB_REMOVABLE_BOOT_EFI_PATH=$INSTALLER_GRUB_REMOVABLE_BOOT_EFI_PATH
FILE_SECURE_BOOT_TOOL=$FILE_SECURE_BOOT_TOOL
FILE_SECURE_BOOT_MOK_KEY=$FILE_SECURE_BOOT_MOK_KEY
FILE_SECURE_BOOT_MOK_CERT_DER=$FILE_SECURE_BOOT_MOK_CERT_DER
SECURE_BOOT_DEFER_HOOK_FAILURES=${SECURE_BOOT_DEFER_HOOK_FAILURES:-0}
FILE_SWAP_FALLBACK_CONFIG=$FILE_SWAP_FALLBACK_CONFIG
FILE_SWAP_FALLBACK_HELPER=$FILE_SWAP_FALLBACK_HELPER
ZRAM_ENABLE=$zram_enable
ZRAM_SWAP_DEVICE=$zram_swap_device
ZRAM_SETUP_UNIT=$zram_setup_unit
ZRAM_SWAP_DEVICE_NAME=$zram_swap_device_name
ZRAM_SYSFS=$zram_sysfs
ZRAM_RUNTIME_DIR=$zram_runtime_dir
ZRAM_LOCK_FILE=$zram_lock_file
ZRAM_LOG_LEVEL=${ZRAM_LOG_LEVEL:-info}
ZRAM_ALGORITHM_PARAMS=${ZRAM_ALGORITHM_PARAMS:-}
ZRAM_BACKING_RAW_PARTUUID=$zram_backing_raw_partuuid
ZRAM_BACKING_RAW_DEVICE=$zram_backing_raw_device
ZRAM_BACKING_MAPPER_NAME=$ZRAM_BACKING_MAPPER_NAME
ZRAM_BACKING_DEVICE=$ZRAM_BACKING_DEVICE
ZRAM_BACKING_RESERVE_MIB=$zram_backing_reserve_mib
DMCRYPT_EPHEMERAL_CIPHER=$DMCRYPT_EPHEMERAL_CIPHER
DMCRYPT_EPHEMERAL_KEY_SIZE=$DMCRYPT_EPHEMERAL_KEY_SIZE
DMCRYPT_EPHEMERAL_HASH=$DMCRYPT_EPHEMERAL_HASH
DMCRYPT_RANDOM_KEY_FILE=$DMCRYPT_RANDOM_KEY_FILE
ZRAM_COMPRESSION_ALGORITHM=$ZRAM_COMPRESSION_ALGORITHM
ZRAM_TIER1_ENABLE=$ZRAM_TIER1_ENABLE
ZRAM_TIER1_ALGORITHM=$ZRAM_TIER1_ALGORITHM
ZRAM_TIER1_PRIORITY=$ZRAM_TIER1_PRIORITY
ZRAM_TIER1_LEVEL=$ZRAM_TIER1_LEVEL
ZRAM_TIER1_THRESHOLD_BYTES=$ZRAM_TIER1_THRESHOLD_BYTES
ZRAM_TIER1_MAX_PAGES_NORMAL=$ZRAM_TIER1_MAX_PAGES_NORMAL
ZRAM_TIER1_MAX_PAGES_PRESSURE=$ZRAM_TIER1_MAX_PAGES_PRESSURE
ZRAM_TIER1_MAX_PAGES_EMERGENCY=$ZRAM_TIER1_MAX_PAGES_EMERGENCY
ZRAM_TIER2_ENABLE=$ZRAM_TIER2_ENABLE
ZRAM_TIER2_ALGORITHM=$ZRAM_TIER2_ALGORITHM
ZRAM_TIER2_PRIORITY=$ZRAM_TIER2_PRIORITY
ZRAM_TIER2_LEVEL=$ZRAM_TIER2_LEVEL
ZRAM_TIER2_THRESHOLD_BYTES=$ZRAM_TIER2_THRESHOLD_BYTES
ZRAM_TIER2_MAX_PAGES_NORMAL=$ZRAM_TIER2_MAX_PAGES_NORMAL
ZRAM_TIER2_MAX_PAGES_PRESSURE=$ZRAM_TIER2_MAX_PAGES_PRESSURE
ZRAM_TIER2_MAX_PAGES_EMERGENCY=$ZRAM_TIER2_MAX_PAGES_EMERGENCY
ZRAM_TIER3_ENABLE=$ZRAM_TIER3_ENABLE
ZRAM_TIER3_ALGORITHM=$ZRAM_TIER3_ALGORITHM
ZRAM_TIER3_PRIORITY=$ZRAM_TIER3_PRIORITY
ZRAM_TIER3_LEVEL=$ZRAM_TIER3_LEVEL
ZRAM_TIER3_THRESHOLD_BYTES=$ZRAM_TIER3_THRESHOLD_BYTES
ZRAM_TIER3_MAX_PAGES_NORMAL=$ZRAM_TIER3_MAX_PAGES_NORMAL
ZRAM_TIER3_MAX_PAGES_PRESSURE=$ZRAM_TIER3_MAX_PAGES_PRESSURE
ZRAM_TIER3_MAX_PAGES_EMERGENCY=$ZRAM_TIER3_MAX_PAGES_EMERGENCY
ZRAM_SWAP_PRIORITY=$ZRAM_SWAP_PRIORITY
ZRAM_MAX_COMP_STREAMS=$ZRAM_MAX_COMP_STREAMS
ZRAM_COMPRESSED_WRITEBACK=$ZRAM_COMPRESSED_WRITEBACK
ZRAM_HOT_AGE_SEC=$ZRAM_HOT_AGE_SEC
ZRAM_IDLE_AGE_SEC=$ZRAM_IDLE_AGE_SEC
ZRAM_PRESSURE_IDLE_AGE_SEC=$ZRAM_PRESSURE_IDLE_AGE_SEC
ZRAM_EMERGENCY_IDLE_AGE_SEC=$ZRAM_EMERGENCY_IDLE_AGE_SEC
ZRAM_WRITEBACK_ENABLE=$ZRAM_WRITEBACK_ENABLE
ZRAM_WRITEBACK_BATCH_SIZE=$ZRAM_WRITEBACK_BATCH_SIZE
ZRAM_WRITEBACK_BATCH_SIZE_ADAPTIVE=$ZRAM_WRITEBACK_BATCH_SIZE_ADAPTIVE
ZRAM_WRITEBACK_BATCH_SIZE_NORMAL=$ZRAM_WRITEBACK_BATCH_SIZE_NORMAL
ZRAM_WRITEBACK_BATCH_SIZE_PRESSURE=$ZRAM_WRITEBACK_BATCH_SIZE_PRESSURE
ZRAM_WRITEBACK_BATCH_SIZE_EMERGENCY=$ZRAM_WRITEBACK_BATCH_SIZE_EMERGENCY
ZRAM_WRITEBACK_BATCH_SIZE_ROTATIONAL_MAX=$ZRAM_WRITEBACK_BATCH_SIZE_ROTATIONAL_MAX
ZRAM_WRITEBACK_BATCH_SIZE_MAX=$ZRAM_WRITEBACK_BATCH_SIZE_MAX
ZRAM_WRITEBACK_MAX_PAGES_PRESSURE=$ZRAM_WRITEBACK_MAX_PAGES_PRESSURE
ZRAM_WRITEBACK_MAX_PAGES_EMERGENCY=$ZRAM_WRITEBACK_MAX_PAGES_EMERGENCY
ZRAM_EMERGENCY_WORK_MAX_PAGES=$ZRAM_EMERGENCY_WORK_MAX_PAGES
ZRAM_PRESSURE_WORK_MAX_PAGES=$ZRAM_PRESSURE_WORK_MAX_PAGES
ZRAM_IO_PSI_ENABLE=$ZRAM_IO_PSI_ENABLE
ZRAM_IO_PSI_SOME_AVG10_THRESHOLD=$ZRAM_IO_PSI_SOME_AVG10_THRESHOLD
ZRAM_IO_PSI_FULL_AVG10_THRESHOLD=$ZRAM_IO_PSI_FULL_AVG10_THRESHOLD
ZRAM_IO_PSI_BATCH_SIZE_PRESSURE=$ZRAM_IO_PSI_BATCH_SIZE_PRESSURE
ZRAM_IO_PSI_BATCH_SIZE_EMERGENCY=$ZRAM_IO_PSI_BATCH_SIZE_EMERGENCY
ZRAM_IO_PSI_MAX_PAGES_PRESSURE=$ZRAM_IO_PSI_MAX_PAGES_PRESSURE
ZRAM_IO_PSI_MAX_PAGES_EMERGENCY=$ZRAM_IO_PSI_MAX_PAGES_EMERGENCY
ZRAM_WRITEBACK_PASS_PAGES_MAX=$ZRAM_WRITEBACK_PASS_PAGES_MAX
ZRAM_BLOCK_STATE_MAX_LINES=$ZRAM_BLOCK_STATE_MAX_LINES
ZRAM_BLOCK_STATE_FALLBACK_LINES=$ZRAM_BLOCK_STATE_FALLBACK_LINES
ZRAM_LOGICAL_BLOCK_SIZE_FALLBACK=$ZRAM_LOGICAL_BLOCK_SIZE_FALLBACK
ZRAM_WRITEBACK_SPEC_MAX_BYTES=$ZRAM_WRITEBACK_SPEC_MAX_BYTES
ZRAM_WRITEBACK_CHUNKS_PER_CLASS_MAX=$ZRAM_WRITEBACK_CHUNKS_PER_CLASS_MAX
ZRAM_WRITEBACK_LIMIT_ENABLE=$ZRAM_WRITEBACK_LIMIT_ENABLE
ZRAM_DAILY_WRITEBACK_LIMIT=${ZRAM_DAILY_WRITEBACK_LIMIT:-}
ZRAM_PRESSURE_MEM_AVAILABLE_PCT=$ZRAM_PRESSURE_MEM_AVAILABLE_PCT
ZRAM_EMERGENCY_MEM_AVAILABLE_PCT=$ZRAM_EMERGENCY_MEM_AVAILABLE_PCT
ZRAM_PRESSURE_SOME_AVG10_THRESHOLD=$ZRAM_PRESSURE_SOME_AVG10_THRESHOLD
ZRAM_PRESSURE_FULL_AVG10_THRESHOLD=$ZRAM_PRESSURE_FULL_AVG10_THRESHOLD
ZRAM_EMERGENCY_SOME_AVG10_THRESHOLD=$ZRAM_EMERGENCY_SOME_AVG10_THRESHOLD
ZRAM_EMERGENCY_FULL_AVG10_THRESHOLD=$ZRAM_EMERGENCY_FULL_AVG10_THRESHOLD
ZRAM_PRESSURE_ENABLE=$ZRAM_PRESSURE_ENABLE
ZRAM_MIN_FREE_MEMORY=${ZRAM_MIN_FREE_MEMORY:-0}
ZRAM_WRITEBACK_MIN_REMAINING_PAGES=$ZRAM_WRITEBACK_MIN_REMAINING_PAGES
ZRAM_DAEMON_ENABLE=$ZRAM_DAEMON_ENABLE
ZRAM_DAEMON_PSI_WINDOW_US=$ZRAM_DAEMON_PSI_WINDOW_US
ZRAM_DAEMON_PSI_WINDOW_MIN_US=$ZRAM_DAEMON_PSI_WINDOW_MIN_US
ZRAM_DAEMON_PSI_WINDOW_MAX_US=$ZRAM_DAEMON_PSI_WINDOW_MAX_US
ZRAM_DAEMON_PSI_SOME_STALL_US=$ZRAM_DAEMON_PSI_SOME_STALL_US
ZRAM_DAEMON_PSI_FULL_STALL_US=$ZRAM_DAEMON_PSI_FULL_STALL_US
ZRAM_DAEMON_POLL_TIMEOUT_SEC=$ZRAM_DAEMON_POLL_TIMEOUT_SEC
ZRAM_DAEMON_PRESSURE_COOLDOWN_SEC=$ZRAM_DAEMON_PRESSURE_COOLDOWN_SEC
ZRAM_DAEMON_EMERGENCY_COOLDOWN_SEC=$ZRAM_DAEMON_EMERGENCY_COOLDOWN_SEC
ZRAM_DAEMON_RECOVERY_HYSTERESIS_SEC=$ZRAM_DAEMON_RECOVERY_HYSTERESIS_SEC
ZRAM_DAEMON_SECONDS_MAX=$ZRAM_DAEMON_SECONDS_MAX
ZRAM_IDLE_WRITEBACK_ENABLE=$ZRAM_IDLE_WRITEBACK_ENABLE
ZRAM_COLD_TIER_ENABLE=$ZRAM_COLD_TIER_ENABLE
ZRAM_COLD_TIER_RECOMPRESS_ENABLE=$ZRAM_COLD_TIER_RECOMPRESS_ENABLE
ZRAM_COLD_TIER_WRITEBACK_ENABLE=$ZRAM_COLD_TIER_WRITEBACK_ENABLE
ZRAM_COLD_TIER_COMPACT_ENABLE=$ZRAM_COLD_TIER_COMPACT_ENABLE
ZRAM_COLD_TIER_MIN_ZRAM_FILL_PCT=$ZRAM_COLD_TIER_MIN_ZRAM_FILL_PCT
ZRAM_COLD_TIER_MIN_COLD_PAGES=$ZRAM_COLD_TIER_MIN_COLD_PAGES
ZRAM_COLD_TIER_MIN_IDLE_PAGES=$ZRAM_COLD_TIER_MIN_IDLE_PAGES
ZRAM_COLD_TIER_MIN_HUGE_IDLE_PAGES=$ZRAM_COLD_TIER_MIN_HUGE_IDLE_PAGES
ZRAM_COLD_TIER_MIN_HUGE_PAGES=$ZRAM_COLD_TIER_MIN_HUGE_PAGES
ZRAM_COLD_TIER_MIN_INCOMPRESSIBLE_PAGES=$ZRAM_COLD_TIER_MIN_INCOMPRESSIBLE_PAGES
ZRAM_COLD_TIER_RECOMPRESS_IDLE_MAX_PAGES=$ZRAM_COLD_TIER_RECOMPRESS_IDLE_MAX_PAGES
ZRAM_COLD_TIER_RECOMPRESS_HUGE_IDLE_MAX_PAGES=$ZRAM_COLD_TIER_RECOMPRESS_HUGE_IDLE_MAX_PAGES
ZRAM_COLD_TIER_RECOMPRESS_HUGE_MAX_PAGES=$ZRAM_COLD_TIER_RECOMPRESS_HUGE_MAX_PAGES
ZRAM_COLD_TIER_WRITEBACK_INCOMPRESSIBLE_MAX_PAGES=$ZRAM_COLD_TIER_WRITEBACK_INCOMPRESSIBLE_MAX_PAGES
ZRAM_COLD_TIER_WRITEBACK_SPEC_CHUNK_PAGE_LIMIT=$ZRAM_COLD_TIER_WRITEBACK_SPEC_CHUNK_PAGE_LIMIT
ZRAM_MAINTENANCE_PAGE_INDEXES=$ZRAM_MAINTENANCE_PAGE_INDEXES
ZRAM_PCT=$ZRAM_PCT
ZRAM_MIN_MIB=$ZRAM_MIN_MIB
ZRAM_MAX_MIB=$ZRAM_MAX_MIB
ZRAM_MEM_LIMIT_PCT=$ZRAM_MEM_LIMIT_PCT
ZRAM_WRITEBACK_LIMIT_PCT=$ZRAM_WRITEBACK_LIMIT_PCT
ZRAM_POLICY_CONFIG=$zram_policy_config
CPU_CRC32C_MODULE=${CPU_CRC32C_MODULE:-}
ZRAM_MAINTENANCE_IO_WRITE_BANDWIDTH_MAX=$ZRAM_MAINTENANCE_IO_WRITE_BANDWIDTH_MAX
ZRAM_MAINTENANCE_MEMORY_HIGH=$ZRAM_MAINTENANCE_MEMORY_HIGH
ZRAM_MAINTENANCE_MEMORY_MAX=$ZRAM_MAINTENANCE_MEMORY_MAX
ZRAM_IDLE_WRITEBACK_INTERVAL=$ZRAM_IDLE_WRITEBACK_INTERVAL
ZRAM_IDLE_WRITEBACK_RANDOMIZED_DELAY=$ZRAM_IDLE_WRITEBACK_RANDOMIZED_DELAY
ZRAM_COLD_TIER_INTERVAL=$ZRAM_COLD_TIER_INTERVAL
ZRAM_COLD_TIER_RANDOMIZED_DELAY=$ZRAM_COLD_TIER_RANDOMIZED_DELAY
SYSCTL_PROFILE_BALANCED_SWAPPINESS=$SYSCTL_PROFILE_BALANCED_SWAPPINESS
SYSCTL_PROFILE_BALANCED_VFS_CACHE_PRESSURE=$SYSCTL_PROFILE_BALANCED_VFS_CACHE_PRESSURE
SYSCTL_PROFILE_BALANCED_WATERMARK_SCALE_FACTOR=$SYSCTL_PROFILE_BALANCED_WATERMARK_SCALE_FACTOR
SYSCTL_PROFILE_BALANCED_COMPACTION_PROACTIVENESS=$SYSCTL_PROFILE_BALANCED_COMPACTION_PROACTIVENESS
SYSCTL_PROFILE_BALANCED_DIRTY_BACKGROUND_BYTES=$SYSCTL_PROFILE_BALANCED_DIRTY_BACKGROUND_BYTES
SYSCTL_PROFILE_BALANCED_DIRTY_BYTES=$SYSCTL_PROFILE_BALANCED_DIRTY_BYTES
SYSCTL_PROFILE_BALANCED_DIRTY_EXPIRE_CENTISECS=$SYSCTL_PROFILE_BALANCED_DIRTY_EXPIRE_CENTISECS
SYSCTL_PROFILE_BALANCED_DIRTY_WRITEBACK_CENTISECS=$SYSCTL_PROFILE_BALANCED_DIRTY_WRITEBACK_CENTISECS
SYSCTL_PROFILE_HARDENED_SWAPPINESS=$SYSCTL_PROFILE_HARDENED_SWAPPINESS
SYSCTL_PROFILE_HARDENED_VFS_CACHE_PRESSURE=$SYSCTL_PROFILE_HARDENED_VFS_CACHE_PRESSURE
SYSCTL_PROFILE_HARDENED_WATERMARK_SCALE_FACTOR=$SYSCTL_PROFILE_HARDENED_WATERMARK_SCALE_FACTOR
SYSCTL_PROFILE_HARDENED_COMPACTION_PROACTIVENESS=$SYSCTL_PROFILE_HARDENED_COMPACTION_PROACTIVENESS
SYSCTL_PROFILE_HARDENED_DIRTY_BACKGROUND_BYTES=$SYSCTL_PROFILE_HARDENED_DIRTY_BACKGROUND_BYTES
SYSCTL_PROFILE_HARDENED_DIRTY_BYTES=$SYSCTL_PROFILE_HARDENED_DIRTY_BYTES
SYSCTL_PROFILE_HARDENED_DIRTY_EXPIRE_CENTISECS=$SYSCTL_PROFILE_HARDENED_DIRTY_EXPIRE_CENTISECS
SYSCTL_PROFILE_HARDENED_DIRTY_WRITEBACK_CENTISECS=$SYSCTL_PROFILE_HARDENED_DIRTY_WRITEBACK_CENTISECS
SYSCTL_PROFILE_PERFORMANCE_SWAPPINESS=$SYSCTL_PROFILE_PERFORMANCE_SWAPPINESS
SYSCTL_PROFILE_PERFORMANCE_VFS_CACHE_PRESSURE=$SYSCTL_PROFILE_PERFORMANCE_VFS_CACHE_PRESSURE
SYSCTL_PROFILE_PERFORMANCE_WATERMARK_SCALE_FACTOR=$SYSCTL_PROFILE_PERFORMANCE_WATERMARK_SCALE_FACTOR
SYSCTL_PROFILE_PERFORMANCE_COMPACTION_PROACTIVENESS=$SYSCTL_PROFILE_PERFORMANCE_COMPACTION_PROACTIVENESS
SYSCTL_PROFILE_PERFORMANCE_DIRTY_BACKGROUND_BYTES=$SYSCTL_PROFILE_PERFORMANCE_DIRTY_BACKGROUND_BYTES
SYSCTL_PROFILE_PERFORMANCE_DIRTY_BYTES=$SYSCTL_PROFILE_PERFORMANCE_DIRTY_BYTES
SYSCTL_PROFILE_PERFORMANCE_DIRTY_EXPIRE_CENTISECS=$SYSCTL_PROFILE_PERFORMANCE_DIRTY_EXPIRE_CENTISECS
SYSCTL_PROFILE_PERFORMANCE_DIRTY_WRITEBACK_CENTISECS=$SYSCTL_PROFILE_PERFORMANCE_DIRTY_WRITEBACK_CENTISECS
EOF
}

# Module lists are blocks, not scalar NAME=value records. Passing newline
# lists through the scalar map used to keep only the first module silently.
render_target_module_placeholders() (
  set -eu
  module_file=$1
  if LC_ALL=C grep -Eq '__(INSTALLER_)?(INITRAMFS_PLATFORM_MODULES|GRAPHICS_INITRAMFS_MODULES|VFIO_INITRAMFS_MODULES|VIRT_HOST_INITRAMFS_MODULES)__' "$module_file"; then
    :
  else
    module_status=$?
    [ "$module_status" -eq 1 ] && exit 0
    exit "$module_status"
  fi
  module_map=$(mktemp "${TMP_ENV_DIR}/module-map.XXXXXX") || exit 1
  trap 'rm -f -- "$module_map"' 0
  printf 'INITRAMFS_PLATFORM_MODULES=%s\nGRAPHICS_INITRAMFS_MODULES=%s\nVFIO_INITRAMFS_MODULES=%s\nVIRT_HOST_INITRAMFS_MODULES=%s\n' \
    "${INITRAMFS_PLATFORM_MODULES:-}" "${GRAPHICS_INITRAMFS_MODULES:-}" \
    "${VFIO_INITRAMFS_MODULES:-}" "${VIRT_HOST_INITRAMFS_MODULES:-}" >"$module_map"
  installer_target_perl_render "$module_file" "$module_file" "$module_map" modules
)

render_target_scalar_placeholders() (
  installer_target_perl_render "$1" "$1" "$2"
)

_render_target_template_in_place() {
  src=$1
  dest=$2
  mode=$3
  dest_parent=$(dirname "$dest")
  map_tmp="${TMP_ENV_DIR}/template-placeholder-map.$$.tmp"
  [ -d "$dest_parent" ] || install -d -m 0755 "$dest_parent"
  cp "$src" "$dest" || return 1
  # The base-stage pass resolved static system/profile templates. Copy those
  # bytes directly; only explicitly deferred markers reach a late consumer.
  if LC_ALL=C grep -Eq '__[A-Z][A-Z0-9]*(_[A-Z0-9]+)*__' "$dest"; then
    :
  else
    template_probe=$?
    [ "$template_probe" -eq 1 ] || return "$template_probe"
    chmod "$mode" "$dest"
    return
  fi
  render_target_module_placeholders "$dest" || return 1
  if ! render_target_template_placeholder_map >"$map_tmp"; then
    rm -f "$map_tmp"
    installer_fatal "failed to render template placeholder map for ${dest}"
  fi
  if ! render_target_scalar_placeholders "$dest" "$map_tmp"; then
    rm -f "$map_tmp"
    installer_fatal "failed to render scalar placeholders into ${dest}"
  fi
  rm -f "$map_tmp"
  apply_tmpfs_policy_placeholders "$dest" || return 1
  apply_tmpfs_pre_clean_placeholders "$dest" || return 1
  apply_apt_refresh_placeholders "$dest" || return 1
  apply_sysctl_profile_placeholders "$dest" || return 1
  installer_assert_no_unresolved_installer_placeholders "$dest" "rendered template ${src}" || return 1
  chmod "$mode" "$dest"
}

# Direct renderer callers get the same atomic publication guarantee as assets.
render_target_template() (
  set -eu
  umask 077
  template_source=$1
  template_destination=$2
  template_mode=$3
  template_parent=$(dirname "$template_destination")
  [ -d "$template_parent" ] || install -d -m 0755 "$template_parent" || exit 1
  [ ! -d "$template_destination" ] || exit 1
  template_work=$(mktemp -d "$template_parent/.installer-render.XXXXXX") || exit 1
  trap 'rm -rf -- "$template_work"' EXIT
  trap 'exit 129' HUP
  trap 'exit 130' INT
  trap 'exit 143' TERM
  # Isolate the legacy renderer's shell variables and all of its scratch files.
  (TMP_ENV_DIR=$template_work; _render_target_template_in_place "$template_source" "$template_work/payload" "$template_mode") || exit 1
  mv -fT -- "$template_work/payload" "$template_destination" || exit 1
)


# This allowlist is intentionally limited to managed resource-policy assets.
# Existing zram/Podman policies and the generic renderer remain independent.
# Values are data: indirect variable names below are literal, never user input.
systemd_journal_policy_map() (
  set -eu
  case "${SYSTEMD_JOURNAL_VOLATILE_ENABLE-}" in
    true) journal_storage=volatile ;;
    false) journal_storage=persistent ;;
    *) installer_fatal "SYSTEMD_JOURNAL_VOLATILE_ENABLE must be true or false"; exit 1 ;;
  esac
  printf 'SYSTEMD_JOURNAL_STORAGE=%s\n' "$journal_storage"
  # __INSTALLER_PATH_DIR_VAR__/log/journal is a separate disk-backed ext4 mount even when its
  # parent __INSTALLER_PATH_DIR_VAR__/log is tmpfs. Seal the actual persistent journal backend.
  case "${TMPFS_VAR_LOG-}" in
    true|false) [ "$journal_storage" = persistent ] && journal_seal=yes || journal_seal=no ;;
    *) installer_fatal "TMPFS_VAR_LOG must be true or false"; exit 1 ;;
  esac
  printf 'SYSTEMD_JOURNAL_SEAL=%s\n' "$journal_seal"

)

systemd_resource_placeholder_map() (
  set -eu
  systemd_journal_policy_map || exit 1
  if [ "${INSTALLER_HOST_VARIANT:-}" != server ]; then
    for name in SYSTEMD_MEMORY_LOW_DESKTOP_ANCESTRY SYSTEMD_MEMORY_LOW_USER_SESSION SYSTEMD_MEMORY_LOW_USER_APP \
      SYSTEMD_BUILD_MEMORY_HIGH SYSTEMD_BUILD_MEMORY_MAX SYSTEMD_BUILD_MEMORY_SWAP_MAX
    do
      case "$name" in
        SYSTEMD_MEMORY_LOW_DESKTOP_ANCESTRY) value=$SYSTEMD_MEMORY_LOW_DESKTOP_ANCESTRY ;;
        SYSTEMD_MEMORY_LOW_USER_SESSION) value=$SYSTEMD_MEMORY_LOW_USER_SESSION ;;
        SYSTEMD_MEMORY_LOW_USER_APP) value=$SYSTEMD_MEMORY_LOW_USER_APP ;;
        SYSTEMD_BUILD_MEMORY_HIGH) value=$SYSTEMD_BUILD_MEMORY_HIGH ;;
        SYSTEMD_BUILD_MEMORY_MAX) value=$SYSTEMD_BUILD_MEMORY_MAX ;;
        SYSTEMD_BUILD_MEMORY_SWAP_MAX) value=$SYSTEMD_BUILD_MEMORY_SWAP_MAX ;;
      esac
      number=${value%\%}
      case "$value:$number" in *%:|*[!0-9%:]*) installer_fatal "$name must be a percentage"; exit 1 ;; esac
      case "$number" in ''|0*|*[!0-9]*) installer_fatal "$name must be 1..100 percent"; exit 1 ;; esac
      [ "$value" = "${number}%" ] && [ "${#number}" -le 3 ] && [ "$number" -le 100 ] || exit 1
      printf '%s=%s\n' "$name" "$value"
    done
    for name in SYSTEMD_BUILD_CPU_WEIGHT SYSTEMD_BUILD_IO_WEIGHT SYSTEMD_BUILD_TASKS_MAX; do
      case "$name" in
        SYSTEMD_BUILD_CPU_WEIGHT) value=$SYSTEMD_BUILD_CPU_WEIGHT ;;
        SYSTEMD_BUILD_IO_WEIGHT) value=$SYSTEMD_BUILD_IO_WEIGHT ;;
        SYSTEMD_BUILD_TASKS_MAX) value=$SYSTEMD_BUILD_TASKS_MAX ;;
      esac
      case "$value" in ''|0*|*[!0-9]*) installer_fatal "$name must be a positive integer"; exit 1 ;; esac
      [ "${#value}" -le 5 ] && [ "$value" -le 10000 ] || exit 1
      printf '%s=%s\n' "$name" "$value"
    done
    [ "${SYSTEMD_BUILD_MEMORY_HIGH%\%}" -lt "${SYSTEMD_BUILD_MEMORY_MAX%\%}" ] || {
      installer_fatal 'build memory high must be below memory max'; exit 1;
    }
  fi
  case "${SYSTEMD_DEFAULT_IOACCOUNTING_ENABLE-}" in
    true) io_accounting=yes ;;
    false) io_accounting=no ;;
    *) installer_fatal "SYSTEMD_DEFAULT_IOACCOUNTING_ENABLE must be true or false"; exit 1 ;;
  esac
  case "${SYSTEMD_IOWEIGHT_ENABLE-}" in
    true|false) ;;
    *) installer_fatal "SYSTEMD_IOWEIGHT_ENABLE must be true or false"; exit 1 ;;
  esac
  printf 'SYSTEMD_DEFAULT_IOACCOUNTING_ENABLE=%s\n' "$io_accounting"
  for name in \
    SYSTEMD_IOWEIGHT_HOME_USER_SESSION_SLICE_D \
    SYSTEMD_IOWEIGHT_HOME_USER_APP_SLICE_D \
    SYSTEMD_IOWEIGHT_HOME_USER_BACKGROUND_SLICE_D \
    SYSTEMD_IOWEIGHT_HOME_USER_LABWC_COMPOSITOR_SERVICE_D \
    SYSTEMD_IOWEIGHT_SYSTEM_MAINTENANCE_SLICE_D \
    SYSTEMD_IOWEIGHT_SYSTEM_BACKGROUND_SLICE_D
  do
    if [ "$name" = SYSTEMD_IOWEIGHT_HOME_USER_LABWC_COMPOSITOR_SERVICE_D ] &&
       [ "${INSTALLER_HOST_VARIANT:-}" = server ]; then continue; fi
    eval 'present=${'"$name"'+yes}'
    [ "$present" = yes ] || { installer_fatal "$name must be defined (empty is allowed)"; exit 1; }
    eval 'value=${'"$name"'-}'
    case "$value" in
      '') ;;
      IOWeight=*)
        number=${value#IOWeight=}
        case "$number" in ''|*[!0-9]*|0*)
          installer_fatal "$name must be empty or IOWeight=1..10000"; exit 1 ;;
        esac
        [ "${#number}" -le 5 ] && [ "$number" -le 10000 ] || {
          installer_fatal "$name must be empty or IOWeight=1..10000"; exit 1;
        }
        ;;
      *) installer_fatal "$name must be empty or IOWeight=1..10000"; exit 1 ;;
    esac
    [ "$SYSTEMD_IOWEIGHT_ENABLE" = true ] || value=
    printf '%s=%s\n' "$name" "$value"
  done
  # CPU preference is independent of both I/O accounting and I/O weighting.
  case "${SYSTEMD_CPUWEIGHT_ENABLE-}" in
    true|false) ;;
    *) installer_fatal "SYSTEMD_CPUWEIGHT_ENABLE must be true or false"; exit 1 ;;
  esac
  for name in \
    SYSTEMD_CPUWEIGHT_HOME_USER_SESSION_SLICE_D \
    SYSTEMD_CPUWEIGHT_HOME_USER_APP_SLICE_D \
    SYSTEMD_CPUWEIGHT_HOME_USER_BACKGROUND_SLICE_D \
    SYSTEMD_CPUWEIGHT_HOME_USER_LABWC_COMPOSITOR_SERVICE_D \
    SYSTEMD_CPUWEIGHT_USER_AUDIO_SERVICE_D \
    SYSTEMD_CPUWEIGHT_SYSTEM_MAINTENANCE_SLICE_D \
    SYSTEMD_CPUWEIGHT_SYSTEM_BACKGROUND_SLICE_D
  do
    if [ "$name" = SYSTEMD_CPUWEIGHT_HOME_USER_LABWC_COMPOSITOR_SERVICE_D ] &&
       [ "${INSTALLER_HOST_VARIANT:-}" = server ]; then continue; fi
    eval 'present=${'"$name"'+yes}'
    [ "$present" = yes ] || { installer_fatal "$name must be defined (empty is allowed)"; exit 1; }
    eval 'value=${'"$name"'-}'
    case "$value" in
      '') ;;
      CPUWeight=*)
        number=${value#CPUWeight=}
        case "$number" in ''|*[!0-9]*|0*)
          installer_fatal "$name must be empty or CPUWeight=1..10000"; exit 1 ;;
        esac
        [ "${#number}" -le 5 ] && [ "$number" -le 10000 ] || {
          installer_fatal "$name must be empty or CPUWeight=1..10000"; exit 1;
        }
        ;;
      *) installer_fatal "$name must be empty or CPUWeight=1..10000"; exit 1 ;;
    esac
    [ "$SYSTEMD_CPUWEIGHT_ENABLE" = true ] || value=
    printf '%s=%s\n' "$name" "$value"
  done
  for name in \
    SYSTEMD_COREDUMP_POLL_LIMIT_INTERVAL_SEC \
    SYSTEMD_COREDUMP_POLL_LIMIT_BURST
  do
    eval 'value=${'"$name"'-}'
    # Bound integer input before numeric comparisons (also on 32-bit shells).
    case "$name" in
      SYSTEMD_COREDUMP_POLL_LIMIT_INTERVAL_SEC) minimum=2; maximum=60 ;;
      SYSTEMD_COREDUMP_POLL_LIMIT_BURST) minimum=1; maximum=1000000 ;;
    esac
    case "$value" in ''|*[!0-9]*|0*)
      installer_fatal "$name must be an integer from $minimum to $maximum"; exit 1 ;;
    esac
    [ "${#value}" -le 7 ] && [ "$value" -ge "$minimum" ] && [ "$value" -le "$maximum" ] || {
      installer_fatal "$name must be an integer from $minimum to $maximum"; exit 1;
    }
    printf '%s=%s\n' "$name" "$value"
  done
  case "${SYSTEMD_COREDUMP_STORAGE-}" in
    external|none) printf 'SYSTEMD_COREDUMP_STORAGE=%s\n' "$SYSTEMD_COREDUMP_STORAGE" ;;
    *) installer_fatal "SYSTEMD_COREDUMP_STORAGE must be external or none"; exit 1 ;;
  esac
  for name in \
    SYSTEMD_COREDUMP_PROCESS_SIZE_MAX \
    SYSTEMD_COREDUMP_EXTERNAL_SIZE_MAX \
    SYSTEMD_COREDUMP_MAX_USE \
    SYSTEMD_COREDUMP_KEEP_FREE \
    SYSTEMD_JOURNAL_SYSTEM_MAX_USE \
    SYSTEMD_JOURNAL_SYSTEM_KEEP_FREE \
    SYSTEMD_JOURNAL_SYSTEM_MAX_FILE_SIZE \
    SYSTEMD_JOURNAL_RUNTIME_MAX_USE \
    SYSTEMD_JOURNAL_RUNTIME_KEEP_FREE \
    SYSTEMD_JOURNAL_RUNTIME_MAX_FILE_SIZE
  do
    eval 'value=${'"$name"'-}'
    # Single-line bounded subset of systemd's size grammar; no signs, shell
    # expansions, whitespace, ambiguous leading zeroes or unbounded sizes.
    case "$value" in ''|*[!0-9BKMG]*)
      installer_fatal "$name must be a bounded size (bytes or B/K/M/G)"; exit 1 ;;
    esac
    printf '%s\n' "$value" | LC_ALL=C grep -Eq '^(0|[1-9][0-9]{0,8}[BKMG]?)$' || {
      installer_fatal "$name must be a bounded size (bytes or B/K/M/G)"; exit 1;
    }
    case "$name:$value" in
      SYSTEMD_COREDUMP_PROCESS_SIZE_MAX:0|SYSTEMD_COREDUMP_EXTERNAL_SIZE_MAX:0) ;;
      *:0) installer_fatal "$name must be nonzero"; exit 1 ;;
    esac
    printf '%s=%s\n' "$name" "$value"
  done
  for name in SYSTEMD_JOURNAL_SYSTEM_MAX_FILES SYSTEMD_JOURNAL_RUNTIME_MAX_FILES; do
    eval 'value=${'"$name"'-}'
    case "$value" in ''|*[!0-9]*|0*)
      installer_fatal "$name must be an integer from 1 to 1000000"; exit 1 ;;
    esac
    [ "${#value}" -le 7 ] && [ "$value" -le 1000000 ] || {
      installer_fatal "$name must be an integer from 1 to 1000000"; exit 1;
    }
    printf '%s=%s\n' "$name" "$value"
  done
)

apply_systemd_resource_placeholders() (
  set -eu
  [ -n "${BOOTSTRAP_PREPARED_SOURCE_ROOT:-}" ] || {
    installer_fatal 'resource publication requires base-stage rendering'; exit 1;
  }
  # The batch has already replaced resource fields. Most assets now need no
  # interpreter or rewrite; only deferred fields or disabled weight directives
  # require the typed Perl operation. Keep controller policy explicit.
  resource_pending='__INSTALLER_|__[A-Z][A-Z0-9]*(_[A-Z0-9]+)*__'
  case "${SYSTEMD_IOWEIGHT_ENABLE-}" in
    true) ;;
    false) resource_pending="$resource_pending|^[[:space:]]*(Startup)?IOWeight[[:space:]]*=" ;;
    *) installer_fatal 'resource publication requires SYSTEMD_IOWEIGHT_ENABLE=true or false'; exit 1 ;;
  esac
  case "${SYSTEMD_CPUWEIGHT_ENABLE-}" in
    true) ;;
    false) resource_pending="$resource_pending|^[[:space:]]*(Startup)?CPUWeight[[:space:]]*=" ;;
    *) installer_fatal 'resource publication requires SYSTEMD_CPUWEIGHT_ENABLE=true or false'; exit 1 ;;
  esac
  [ -f "$1" ] && [ ! -L "$1" ] &&
    [ "$(installer_metadata_value "$1" links)" = 1 ] || exit 1
  if LC_ALL=C grep -Eq "$resource_pending" "$1"; then
    :
  else
    resource_probe=$?
    [ "$resource_probe" -eq 1 ] && exit 0
    exit "$resource_probe"
  fi
  installer_target_perl_render "$1" "$1" \
    "${BOOTSTRAP_PREPARED_SOURCE_ROOT%/source}/inputs/resources.map" resources
)
