#!/bin/sh
# APT source publication shared by early bootstrap and apt-setup. No APT update
# is safe until this has run; a Pre-Invoke hook would be too late for source parsing.
installer_apt_load_runtime_paths() {
  [ "${INSTALLER_APT_RUNTIME_PATHS_READY:-0}" = 1 ] && return 0
  installer_apt_host_env="${DIR_INSTALLER_ENV:-}/host.env"
  if [ -n "${DIR_INSTALLER_ENV:-}" ] && [ -r "$installer_apt_host_env" ]; then
    # shellcheck disable=SC1090,SC1091
    . "$installer_apt_host_env"
  fi
  INSTALLER_APT_RUNTIME_PATHS_READY=1
}

installer_apt_safe_path() (
  set -eu
  p=$1
  case "$p" in /*) ;; *) exit 1 ;; esac
  case "/${p#/}/" in *'/../'*|*'/./'*|*'//'*) exit 1 ;; esac
  while [ "$p" != / ]; do
    [ ! -L "$p" ] || exit 1
    if [ -e "$p" ]; then
      [ "$(installer_metadata_value "$p" uid)" = "$(id -u)" ] || exit 1
      mode=$(installer_metadata_value "$p" mode) || exit 1
      [ "$((0$mode & 0022))" -eq 0 ] || { [ -d "$p" ] && [ "$((0$mode & 01000))" -ne 0 ]; } || exit 1
    fi
    p=${p%/*}; [ -n "$p" ] || p=/
  done
)

installer_apt_strip_cdrom() (
  set -eu
  umask 077
  target=$1
  installer_apt_load_runtime_paths
  apt_dir=${DIR_APT:?DIR_APT is unavailable}
  apt_sources_dir=${DIR_APT_SOURCES_LIST_D:?DIR_APT_SOURCES_LIST_D is unavailable}
  installer_apt_safe_path "$target${apt_sources_dir}" || exit 1
  for src in "$target${apt_dir}/sources.list" "$target${apt_sources_dir}/"*; do
    [ -e "$src" ] || [ -L "$src" ] || continue
    case "$src" in *.list|*.list.*|*.sources|*.sources.*) ;; *) continue ;; esac
    installer_apt_safe_path "$src" || exit 1
    [ -f "$src" ] && [ "$(installer_metadata_value "$src" links)" = 1 ] || exit 1
    if grep -Fq 'cdrom:' "$src"; then
      :
    else
      source_status=$?
      [ "$source_status" -eq 1 ] && continue
      exit 1
    fi
    tmp=$(mktemp "${src%/*}/.installer-source.XXXXXX") || exit 1
    trap 'rm -f "$tmp"' 0
    case "$src" in
      *.sources|*.sources.*)
        awk 'BEGIN {RS=""; ORS="\n\n"} index($0,"cdrom:")==0 {print}' "$src" >"$tmp" || exit 1 ;;
      *) awk 'index($0,"cdrom:")==0 {print}' "$src" >"$tmp" || exit 1 ;;
    esac
    source_mode=$(installer_metadata_value "$src" mode) || exit 1
    chmod "$source_mode" "$tmp" || exit 1
    mv -fT -- "$tmp" "$src" || exit 1
  done
)

installer_apt_bootstrap_source() (
  set -eu
  umask 077
  target=$1; protocol=$2; host=$3; directory=$4; suite=$5
  installer_apt_load_runtime_paths
  apt_dir=${DIR_APT:?DIR_APT is unavailable}
  apt_conf_dir=${DIR_APT_CONF_D:?DIR_APT_CONF_D is unavailable}
  apt_sources_dir=${DIR_APT_SOURCES_LIST_D:?DIR_APT_SOURCES_LIST_D is unavailable}
  archive_keyring=${FILE_APT_DEBIAN_ARCHIVE_KEYRING:?FILE_APT_DEBIAN_ARCHIVE_KEYRING is unavailable}
  case "$protocol" in http|https) ;; *) exit 1 ;; esac
  case "$host" in ''|*[!A-Za-z0-9.:-]*) exit 1 ;; esac
  case "$directory" in /*) ;; *) exit 1 ;; esac
  case "$directory" in *[!A-Za-z0-9/_-]*|*..*|*//*) exit 1 ;; esac
  case "$suite" in ''|*[!A-Za-z0-9_-]*) exit 1 ;; esac
  installer_apt_safe_path "$target${apt_dir}/sources.list" || exit 1
  installer_apt_safe_path "$target${apt_conf_dir}" || exit 1
  [ -s "$target${archive_keyring}" ] || exit 1
  mkdir -p "$target${apt_sources_dir}" "$target${apt_conf_dir}" || exit 1
  installer_apt_strip_cdrom "$target" || exit 1
  tmp=$(mktemp "$target${apt_dir}/.installer-bootstrap.XXXXXX") || exit 1
  trap 'rm -f "$tmp"' 0
  printf 'deb [signed-by=%s] %s://%s%s %s main contrib non-free non-free-firmware\n' \
    "$archive_keyring" "$protocol" "$host" "$directory" "$suite" >"$tmp" || exit 1
  if [ -f "$target${apt_dir}/sources.list" ]; then
    if cmp -s "$tmp" "$target${apt_dir}/sources.list"; then
      source_mode=$(installer_metadata_value "$target${apt_dir}/sources.list" mode) || exit 1
      [ "$source_mode" != 644 ] || exit 0
    else
      source_status=$?
      [ "$source_status" -eq 1 ] || exit 1
    fi
  fi
  chmod 0644 "$tmp" || exit 1
  mv -fT -- "$tmp" "$target${apt_dir}/sources.list" || exit 1
  # Bootstrap retries/timeouts are command options, never permanent target policy.
)
