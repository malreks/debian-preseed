#!/bin/sh
set -eu

target_root=${1:-${TARGET_ROOT}}
[ -d "$target_root" ] || exit 0

crypto_fatal() {
  crypto_message=$(printf '%s' "$*" | tr '\r\n\t' '   ')
  if command -v installer_error >/dev/null 2>&1; then
    installer_error "crypto: ${crypto_message}"
  else
    printf 'fatal: %s\n' "$crypto_message" >&2
    if [ -c /dev/tty4 ] && [ -w /dev/tty4 ]; then
      printf '[late:crypto] fatal: %s\n' "$crypto_message" >/dev/tty4 || :
    fi
    if command -v logger >/dev/null 2>&1; then
      logger -t preseed-crypto "fatal: $crypto_message" 2>/dev/null || :
    fi
  fi
  exit 1
}

crypto_info() {
  printf '[late:crypto] %s\n' "$*" >&2
}

crypto_validate_abs_path() {
  case "${2:-}" in
    /*) ;;
    *) crypto_fatal "$1 must be an absolute path: ${2:-unset}" ;;
  esac
  case "$2" in
    /|*..*|*//*|*[!ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._/@%:+,-]*)
      crypto_fatal "$1 contains unsupported path syntax: $2"
      ;;
  esac
}

crypto_stage_target_asset() {
  repo_path=$1
  target_path=$2
  mode=$3
  tmp_asset="${tmp_env_dir}/$(basename "$target_path").$$"
  target_host_path="${target_root}${target_path}"

  crypto_validate_abs_path "target path" "$target_path"
  bootstrap_fetch_seed_file "$seed_base" "$repo_path" "$tmp_asset" 0600 "crypto asset ${repo_path}"
  tmp_paths_rendered="${tmp_asset}.paths"
  installer_apply_scalar_placeholders "$tmp_asset" "$tmp_paths_rendered"
  mv -f "$tmp_paths_rendered" "$tmp_asset"
  installer_assert_no_unresolved_installer_placeholders "$tmp_asset" "crypto asset ${repo_path}"
  install -d -m 0755 "${target_root}$(dirname "$target_path")"
  install -m "$mode" "$tmp_asset" "$target_host_path"
  chmod "$mode" "$target_host_path"
  rm -f "$tmp_asset"
}

crypto_render_target_template() {
  repo_path=$1
  target_path=$2
  mode=$3
  shift 3
  tmp_template="${tmp_env_dir}/$(basename "$target_path").$$.tmpl"
  tmp_rendered="${tmp_env_dir}/$(basename "$target_path").$$.rendered"
  target_host_path="${target_root}${target_path}"

  crypto_validate_abs_path "rendered target path" "$target_path"
  [ $(( $# % 2 )) -eq 0 ] ||
    crypto_fatal "crypto template placeholders must be name/value pairs: ${repo_path}"
  bootstrap_fetch_seed_file "$seed_base" "$repo_path" "$tmp_template" 0600 "crypto template ${repo_path}"
  installer_apply_scalar_placeholders "$tmp_template" "$tmp_rendered" "$@" || {
    rm -f "$tmp_template" "$tmp_rendered"
    crypto_fatal "failed to render crypto template: ${repo_path}"
  }
  installer_assert_no_unresolved_installer_placeholders \
    "$tmp_rendered" \
    "crypto template ${repo_path}"
  install -d -m 0755 "${target_root}$(dirname "$target_path")"
  install -m "$mode" "$tmp_rendered" "$target_host_path"
  chmod "$mode" "$target_host_path"
  rm -f "$tmp_template" "$tmp_rendered"
}

runtime_env_path() {
  [ -n "${DIR_INSTALLER_ENV:-}" ] || return 1
  [ -n "${DIR_INSTALLER_RUNTIME_STATE:-}" ] || return 1
  installer_env_dir=${DIR_INSTALLER_ENV:-}
  installer_state_dir=${DIR_INSTALLER_RUNTIME_STATE:-}
  for candidate in "${installer_env_dir}/runtime.env" "${installer_state_dir}/runtime.env"; do
    [ -r "$candidate" ] || continue
    printf '%s\n' "$candidate"
    return 0
  done
  return 1
}

crypto_require_luks2() {
  device=$1
  cryptsetup isLuks "$device" >__INSTALLER_PATH_DIR_DEV__/null 2>&1 || crypto_fatal "$device is not a LUKS container"
  luks_version=$(cryptsetup luksDump "$device" 2>__INSTALLER_PATH_DIR_DEV__/null |
    awk '$1 == "Version:" { print $2; exit }')
  [ "$luks_version" = 2 ] || crypto_fatal "$device is not LUKS2"
}

crypto_passphrase_works() {
  device=$1
  key_file=$2
  cryptsetup open --test-passphrase --type luks2 --key-file "$key_file" "$device" >__INSTALLER_PATH_DIR_DEV__/null 2>&1
}

crypto_validate_install_passphrase_file() {
  key_file=$1
  expected_key=$2
  [ -f "$key_file" ] && [ ! -L "$key_file" ] ||
    crypto_fatal "installer passphrase file must be a regular non-symlink file: ${key_file}"
  key_value=$(cat "$key_file") ||
    crypto_fatal "unable to read installer passphrase file: ${key_file}"
  [ "$key_value" = "$expected_key" ] ||
    crypto_fatal "installer passphrase file does not match the installer bootstrap key"
}

crypto_stage_install_passphrase_file() {
  bootstrap_key_file=$1
  target_key_file=$2
  bootstrap_key=

  [ -f "$bootstrap_key_file" ] && [ ! -L "$bootstrap_key_file" ] ||
    crypto_fatal "crypto bootstrap key is unsafe: ${bootstrap_key_file}"
  bootstrap_key=$(cat "$bootstrap_key_file") ||
    crypto_fatal "unable to read crypto bootstrap key: ${bootstrap_key_file}"
  case "$bootstrap_key" in
    ????????-????-????-????-????????????) ;;
    *) crypto_fatal "crypto bootstrap key has an invalid UUID shape" ;;
  esac
  case "$bootstrap_key" in
    *[!0123456789abcdefABCDEF-]*)
      crypto_fatal "crypto bootstrap key has unsupported characters"
      ;;
  esac

  install -d -m 0755 "$(dirname "$target_key_file")"
  install -m 0400 "$bootstrap_key_file" "$target_key_file" ||
    crypto_fatal "unable to stage the installer passphrase file"
  crypto_validate_install_passphrase_file "$target_key_file" "$bootstrap_key"
}

crypto_write_config() {
  : "${FILE_CRYPTO_STATE_CONFIG:?FILE_CRYPTO_STATE_CONFIG must be set}"
  crypto_render_target_template \
    "$(installer_repo_file_value FILE_FIRSTBOOT_ASSET_TPM_CONFIG_TMPL)" \
    "$FILE_CRYPTO_STATE_CONFIG" \
    0600 \
    CRYPTO_PRIMARY_USER_VALUE "$(shell_single_quote "$ACCOUNT_USERNAME")" \
    CRYPTO_ROOT_LUKS_UUID_VALUE "$(shell_single_quote "$root_luks_uuid")" \
    CRYPTO_HOME_LUKS_UUID_VALUE "$(shell_single_quote "$home_luks_uuid")" \
    CRYPTO_ROOT_CRYPT_NAME_VALUE "$(shell_single_quote "$ROOT_CRYPT_NAME")" \
    CRYPTO_HOME_CRYPT_NAME_VALUE "$(shell_single_quote "$HOME_CRYPT_NAME")" \
    CRYPTO_HOME_KEY_FILE_VALUE "$(shell_single_quote "$home_key_target")" \
    CRYPTO_INSTALL_PASSPHRASE_FILE_VALUE "$(shell_single_quote "$install_passphrase_target")" \
    CRYPTO_TPM2_FINAL_PCRS_VALUE "$(shell_single_quote 7+8+9+14)"
}

crypto_write_crypttab() {
  # Keep unrelated d-i entries; render root/home rows from the native template.
  # Never truncate the authoritative file before the complete replacement exists.
  crypttab_path="${target_root}__INSTALLER_PATH_DIR_ETC__/crypttab"
  crypttab_tmp="${tmp_env_dir}/crypttab.$$"
  if [ -r "$crypttab_path" ]; then
    awk \
      -v root_name="$ROOT_CRYPT_NAME" \
      -v home_name="$HOME_CRYPT_NAME" \
      -v root_source="UUID=$root_luks_uuid" \
      -v home_source="UUID=$home_luks_uuid" \
      -v root_by_uuid="__INSTALLER_PATH_DIR_DEV__/disk/by-uuid/$root_luks_uuid" \
      -v home_by_uuid="__INSTALLER_PATH_DIR_DEV__/disk/by-uuid/$home_luks_uuid" \
      -v root_device="$DEV_PART_ROOT" \
      -v home_device="$DEV_PART_HOME" '
        $0 == "# Generated by installer automation for addon/crypto." ||
        $0 == "# Root is TPM2-token aware through the initramfs-tools local-top hook." {
          next
        }
        /^[[:space:]]*#/ || NF == 0 {
          print
          next
        }
        $1 == root_name || $1 == home_name ||
        $2 == root_source || $2 == home_source ||
        $2 == root_by_uuid || $2 == home_by_uuid ||
        $2 == root_device || $2 == home_device {
          next
        }
        {
          print
        }
      ' "$crypttab_path" >"$crypttab_tmp"
  else
    : >"$crypttab_tmp"
  fi
  crypttab_template=$(mktemp "${tmp_env_dir}/crypttab-template.XXXXXX") || crypto_fatal "cannot stage crypttab template"
  crypttab_records=$(mktemp "${tmp_env_dir}/crypttab-records.XXXXXX") || crypto_fatal "cannot stage crypttab records"
  bootstrap_fetch_seed_file "$seed_base" \
    "$(installer_repo_file_value FILE_TARGET_CRYPTTAB_TMPL)" "$crypttab_template" 0600 "crypttab template"
  installer_apply_scalar_placeholders "$crypttab_template" "$crypttab_records" \
    ROOT_CRYPT_NAME "$ROOT_CRYPT_NAME" ROOT_LUKS_UUID "$root_luks_uuid" \
    HOME_CRYPT_NAME "$HOME_CRYPT_NAME" HOME_LUKS_UUID "$home_luks_uuid" HOME_KEY_FILE "$home_key_target" ||
    crypto_fatal "cannot render crypttab records"
  installer_assert_no_unresolved_installer_placeholders "$crypttab_records" crypttab
  crypttab_publish=$(mktemp "${target_root}__INSTALLER_PATH_DIR_ETC__/.crypttab.XXXXXX") || crypto_fatal "cannot stage crypttab"
  [ ! -L "$crypttab_path" ] || crypto_fatal "refusing a symlinked crypttab"
  if ! (cat "$crypttab_tmp" "$crypttab_records" >"$crypttab_publish" &&
        chmod 0600 "$crypttab_publish" && mv -fT -- "$crypttab_publish" "$crypttab_path"); then
    rm -f -- "$crypttab_publish" "$crypttab_template" "$crypttab_records" "$crypttab_tmp"
    crypto_fatal "cannot publish crypttab"
  fi
  rm -f -- "$crypttab_template" "$crypttab_records" "$crypttab_tmp"
}

crypto_write_initramfs_config() {
  crypto_render_target_template \
    "$(installer_repo_file_value FILE_TARGET_TPM2_CRYPTROOT_TMPL)" \
    __INSTALLER_PATH_DIR_ETC__/tpm2-cryptroot.conf \
    0600 \
    TPM2_CRYPTROOT_NAME_VALUE "$(shell_single_quote "$ROOT_CRYPT_NAME")" \
    TPM2_CRYPTROOT_UUID_VALUE "$(shell_single_quote "$root_luks_uuid")"
  crypto_stage_target_asset \
    "$(installer_repo_file_value FILE_TARGET_CRYPTSETUP_INITRAMFS_CONF_HOOK)" \
    __INSTALLER_PATH_DIR_ETC__/cryptsetup-initramfs/conf-hook \
    0644
}

crypto_verify_initramfs() {
  found_initrd=false
  for initrd in "${target_root}"__INSTALLER_PATH_DIR_BOOT__/initrd.img-*; do
    [ -f "$initrd" ] || continue
    found_initrd=true
    relative_initrd=${initrd#"$target_root"}
    listing="${tmp_env_dir}/lsinitramfs.$$.txt"
    if ! run_in_target \
      "inspect TPM2 initramfs payload" \
      __INSTALLER_PATH_DIR_USR_BIN__/lsinitramfs \
      "$relative_initrd" >"$listing"
    then
      rm -f "$listing"
      crypto_fatal "unable to inspect ${relative_initrd}"
    fi
    grep -q 'scripts/local-top/00-tpm2-cryptroot$' "$listing" ||
      crypto_fatal "early TPM2 local-top script is missing from ${relative_initrd}"
    grep -q 'scripts/local-top/cryptroot$' "$listing" ||
      crypto_fatal "stock cryptroot fallback is missing from ${relative_initrd}"
    grep -q 'libcryptsetup-token-systemd-tpm2.so$' "$listing" ||
      crypto_fatal "systemd TPM2 token plugin is missing from ${relative_initrd}"
    grep -q 'etc/tpm2-cryptroot.conf$' "$listing" ||
      crypto_fatal "TPM2 root config is missing from ${relative_initrd}"
    if grep -q 'etc/cryptsetup-keys.d/crypthome.key$' "$listing"; then
      crypto_fatal "root-contained __INSTALLER_PATH_DIR_HOME__ key leaked into ${relative_initrd}"
    fi
    # Compare normalized archive members, not an obsolete hard-coded location.
    for secret_path in "${install_passphrase_target:-__INSTALLER_PATH_DIR_VAR__/lib/tpm2-enrollment/install-passphrase}" \
      __INSTALLER_PATH_DIR_USR_LOCAL__/lib/crypto/install-passphrase __INSTALLER_PATH_DIR_VAR__/lib/tpm2-enrollment/config.env; do
      if sed 's,^\./,,; s,^/,,; s,/$,,' "$listing" | grep -Fqx "${secret_path#/}"; then
        crypto_fatal "installer enrollment material leaked into ${relative_initrd}"
      fi
    done
    rm -f "$listing"
  done
  [ "$found_initrd" = true ] || crypto_fatal "no target initramfs image was found"
}

crypto_require_secure_boot_tpm2() {
  secure_boot_state=$(capture_in_target "read Secure Boot state for TPM2 policy" __INSTALLER_PATH_DIR_USR_BIN__/mokutil --sb-state)
  printf '%s\n' "$secure_boot_state" | grep -q '^SecureBoot enabled' ||
    crypto_fatal "addon/crypto requires UEFI Secure Boot to be enabled"

  tpm2_devices=$(capture_in_target "discover target TPM2 devices" __INSTALLER_PATH_DIR_USR_BIN__/systemd-cryptenroll --tpm2-device=list)
  printf '%s\n' "$tpm2_devices" | grep -Eq '__INSTALLER_PATH_DIR_DEV__/tpm(rm)?[0-9]+' ||
    crypto_fatal "addon/crypto requires a usable TPM2 device"
}

crypto_enroll_installer_tpm2() {
  run_in_target "enroll TPM2 installer token for encrypted root" \
    __INSTALLER_PATH_DIR_USR_BIN__/systemd-cryptenroll \
      --wipe-slot=tpm2 \
      --unlock-key-file="$install_passphrase_target" \
      --tpm2-device=auto \
      --tpm2-pcrs=7 \
      "$DEV_PART_ROOT"
}

runtime_dir=${INSTALLER_RUNTIME_DIR:-/tmp/install-runtime}
bootstrap_lib=${INSTALLER_BOOTSTRAP_LIB:-${runtime_dir}/bootstrap/bootstrap.sh}
tmp_env_dir=${INSTALLER_LATE_TMP_ENV_DIR:-${DIR_INSTALLER_LATE_ENV}/crypto}

[ -s "$bootstrap_lib" ] || crypto_fatal "installer bootstrap library is unavailable: ${bootstrap_lib}"
# shellcheck disable=SC1090,SC1091
. "$bootstrap_lib"
bootstrap_source_common_lib "" || crypto_fatal "failed to source installer common library"
installer_operation_context_repo FILE_LATE_CRYPTO 297 crypto
seed_base=$(installer_current_seed_base 2>__INSTALLER_PATH_DIR_DEV__/null || installer_seed_base "")
bootstrap_source_common_support_libs "$seed_base" "$tmp_env_dir" fetch hook target || {
  crypto_fatal "failed to source installer late support libraries"
}
installer_ensure_context_loaded "$seed_base"

installer_selected_class_reference_is_selected addon/crypto 2>__INSTALLER_PATH_DIR_DEV__/null || exit 0

account_env=${INSTALLER_LATE_ACCOUNT_ENV:-${DIR_INSTALLER_LATE_ENV}/account.env}
[ -r "$account_env" ] || installer_fetch_account_env "$seed_base" "$account_env" 0600
# shellcheck disable=SC1090,SC1091
. "$account_env"

runtime_env=$(runtime_env_path) || crypto_fatal "installer runtime env is unavailable"
# shellcheck disable=SC1090,SC1091
. "$runtime_env"

: "${ACCOUNT_USERNAME:?ACCOUNT_USERNAME must be set before crypto staging}"
: "${ROOT_HOME_CRYPTO_ENABLED:?ROOT_HOME_CRYPTO_ENABLED must be set}"
: "${DEV_PART_ROOT:?DEV_PART_ROOT must be set}"
: "${DEV_PART_HOME:?DEV_PART_HOME must be set}"
: "${ROOT_CRYPT_NAME:?ROOT_CRYPT_NAME must be set}"
: "${HOME_CRYPT_NAME:?HOME_CRYPT_NAME must be set}"
: "${FILE_CRYPTO_PENDING:?FILE_CRYPTO_PENDING must be set}"
: "${FILE_CRYPTO_COMPLETE:?FILE_CRYPTO_COMPLETE must be set}"
[ "$ROOT_HOME_CRYPTO_ENABLED" = true ] || crypto_fatal "addon/crypto selected without root/home crypto runtime state"
[ -b "$DEV_PART_ROOT" ] || crypto_fatal "encrypted root partition is missing: $DEV_PART_ROOT"
[ -b "$DEV_PART_HOME" ] || crypto_fatal "encrypted home partition is missing: $DEV_PART_HOME"

run_in_target "verify crypto package baseline" __INSTALLER_PATH_DIR_BIN__/sh -eu -c '
dpkg-query -s cryptsetup-initramfs systemd-cryptsetup systemd-tpm tpm2-tools tpm-udev mokutil >__INSTALLER_PATH_DIR_DEV__/null
command -v cryptsetup >__INSTALLER_PATH_DIR_DEV__/null
command -v mokutil >__INSTALLER_PATH_DIR_DEV__/null
command -v systemd-cryptenroll >__INSTALLER_PATH_DIR_DEV__/null
command -v update-initramfs >__INSTALLER_PATH_DIR_DEV__/null
command -v lsinitramfs >__INSTALLER_PATH_DIR_DEV__/null
' sh || crypto_fatal "target crypto package baseline is incomplete"

crypto_require_secure_boot_tpm2
crypto_require_luks2 "$DEV_PART_ROOT"
crypto_require_luks2 "$DEV_PART_HOME"
root_luks_uuid=$(cryptsetup luksUUID "$DEV_PART_ROOT")
home_luks_uuid=$(cryptsetup luksUUID "$DEV_PART_HOME")
[ -n "$root_luks_uuid" ] || crypto_fatal "unable to read root LUKS UUID"
[ -n "$home_luks_uuid" ] || crypto_fatal "unable to read home LUKS UUID"

home_key_target=__INSTALLER_PATH_DIR_ETC__/cryptsetup-keys.d/crypthome.key
home_key_host="${target_root}${home_key_target}"
install_passphrase_target=__INSTALLER_PATH_DIR_VAR__/lib/tpm2-enrollment/install-passphrase
install_passphrase_host="${target_root}${install_passphrase_target}"
bootstrap_key_file="${runtime_dir}/state/crypto-bootstrap.key"
install -d -m 0700 "$tmp_env_dir" "${target_root}__INSTALLER_PATH_DIR_ETC__/cryptsetup-keys.d"
crypto_stage_install_passphrase_file "$bootstrap_key_file" "$install_passphrase_host"
crypto_passphrase_works "$DEV_PART_ROOT" "$install_passphrase_host" ||
  crypto_fatal "installer bootstrap key does not unlock encrypted root"
crypto_passphrase_works "$DEV_PART_HOME" "$install_passphrase_host" ||
  crypto_fatal "installer bootstrap key does not unlock encrypted home"

if [ ! -s "$home_key_host" ]; then
  dd if=__INSTALLER_PATH_DIR_DEV__/urandom of="$home_key_host" bs=64 count=1 2>__INSTALLER_PATH_DIR_DEV__/null
  chmod 0400 "$home_key_host"
fi
crypto_passphrase_works "$DEV_PART_HOME" "$home_key_host" || {
  cryptsetup luksAddKey \
    --batch-mode \
    --type luks2 \
    --key-file "$install_passphrase_host" \
    "$DEV_PART_HOME" \
    "$home_key_host"
}
crypto_passphrase_works "$DEV_PART_HOME" "$home_key_host" ||
  crypto_fatal "root-contained home key does not unlock ${DEV_PART_HOME}"

crypto_write_crypttab
crypto_write_config
crypto_write_initramfs_config

crypto_stage_target_asset \
  "$(installer_repo_file_value FILE_TARGET_INITRAMFS_HOOKS_TPM2_CRYPTROOT)" \
  __INSTALLER_PATH_DIR_ETC__/initramfs-tools/hooks/tpm2-cryptroot \
  0755
crypto_stage_target_asset \
  "$(installer_repo_file_value FILE_TARGET_INITRAMFS_SCRIPTS_LOCAL_TOP_00_TPM2_CRYPTROOT)" \
  __INSTALLER_PATH_DIR_ETC__/initramfs-tools/scripts/local-top/00-tpm2-cryptroot \
  0755
crypto_stage_target_asset \
  "$(installer_repo_file_value FILE_TARGET_LIBEXEC_TPM2_POLICY_CHECK)" \
  "${DIR_USR_LOCAL_LIBEXEC}/tpm2-policy-check" \
  0755
crypto_stage_target_asset \
  "$(installer_repo_file_value FILE_TARGET_DEFAULT_GRUB_D_45_TPM2_MEASURED_BOOT)" \
  __INSTALLER_PATH_DIR_ETC__/default/grub.d/45-tpm2-measured-boot.cfg \
  0644
crypto_stage_target_asset \
  "$(installer_repo_file_value FILE_TARGET_AA_USR_LOCAL_SBIN_TPM2_ENROLL)" \
  __INSTALLER_PATH_DIR_ETC__/apparmor.d/usr.local.sbin.tpm2-enroll.sh \
  0644
run_in_target "enable packaged GRUB TPM measurements" __INSTALLER_PATH_DIR_USR_SBIN__/update-grub
crypto_stage_target_asset \
  "$(installer_repo_file_value FILE_FIRSTBOOT_ASSET_SBIN_TPM2_ENROLL)" \
  __INSTALLER_PATH_DIR_USR_LOCAL__/sbin/tpm2-enroll.sh \
  0755
crypto_stage_target_asset \
  "$(installer_repo_file_value FILE_FIRSTBOOT_ASSET_BIN_TPM2_ENROLL_LAUNCH)" \
  __INSTALLER_PATH_DIR_USR_LOCAL__/bin/tpm2-enroll-launch \
  0755
crypto_stage_target_asset \
  "$(installer_repo_file_value FILE_FIRSTBOOT_ASSET_PROFILE_TPM2_ENROLL_PROMPT)" \
  __INSTALLER_PATH_DIR_ETC__/profile.d/tpm2-enroll-prompt.sh \
  0644
crypto_stage_target_asset \
  "$(installer_repo_file_value FILE_FIRSTBOOT_ASSET_AUTOSTART_TPM2_ENROLL)" \
  __INSTALLER_PATH_DIR_ETC__/xdg/autostart/tpm2-enroll.desktop \
  0644

install -d -m 0755 "${target_root}$(dirname "$FILE_CRYPTO_PENDING")" "${target_root}$(dirname "$FILE_CRYPTO_COMPLETE")"
printf '%s\n' "$ACCOUNT_USERNAME" >"${target_root}${FILE_CRYPTO_PENDING}"
chmod 0644 "${target_root}${FILE_CRYPTO_PENDING}"
rm -f "${target_root}${FILE_CRYPTO_COMPLETE}"

crypto_enroll_installer_tpm2
run_in_target "refresh initramfs-tools images for TPM2 root unlock" __INSTALLER_PATH_DIR_USR_SBIN__/update-initramfs -u -k all
crypto_verify_initramfs
rm -f "${runtime_dir}/state/crypto.answers.cfg" "$bootstrap_key_file"

crypto_info "staged LUKS2 root/home policy using a random installer bootstrap key with deferred TPM2+PIN enrollment"
