#!/bin/sh
set -eu

RUNTIME_DIR=${INSTALLER_RUNTIME_DIR:-/tmp/install-runtime}
BOOTSTRAP_LIB=${INSTALLER_BOOTSTRAP_LIB:-${RUNTIME_DIR}/bootstrap/bootstrap.sh}
if [ ! -s "$BOOTSTRAP_LIB" ]; then
  SELF_DIR=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
  BOOTSTRAP_LIB="${SELF_DIR}/../common/bootstrap.sh"
fi
[ -s "$BOOTSTRAP_LIB" ] || {
  dispatch_message="installer bootstrap library is unavailable: ${BOOTSTRAP_LIB}"
  printf 'fatal: %s\n' "$dispatch_message" >&2
  if [ -c /dev/tty4 ] && [ -w /dev/tty4 ]; then
    printf '[late-dispatch] fatal: %s\n' "$dispatch_message" >/dev/tty4 || :
  fi
  if command -v logger >/dev/null 2>&1; then
    logger -t preseed-late-dispatch "fatal: $dispatch_message" 2>/dev/null || :
  fi
  exit 1
}
# shellcheck disable=SC1090,SC1091
. "$BOOTSTRAP_LIB"
bootstrap_source_common_lib "${1:-}"
installer_init_log_file "$(installer_runtime_log_file)" "" "late dispatch" late-dispatch late_command
installer_operation_context_repo FILE_LATE_DISPATCH 25 late_dispatch
trap 'installer_finalize_log "$?"' EXIT

seed_base=$(installer_seed_base "${1:-}")
installer_ensure_context_loaded "$seed_base"
host_profile=$(installer_resolve_host_profile "")
hook_family=${INSTALLER_HOOK_FAMILY:-${INSTALLER_HOST_FAMILY}}
shared_hook_path=$(installer_repo_file_value FILE_INST_LATE_COMMAND)
shared_hook_dest="${RUNTIME_DIR}/bootstrap/shared-late.sh"
role_hook_path=$(installer_repo_file_value FILE_LATE_DESKTOP)
role_hook_dest="${RUNTIME_DIR}/bootstrap/role-late.sh"
helper_dir="${RUNTIME_DIR}/bootstrap/late-helpers"
shared_module_dir="${RUNTIME_DIR}/bootstrap/late-modules"
shared_modules="core target-assets iocost volatile-storage storage-maintenance mullvad templates network network-sharing grub security dbus-broker podman zram-swap btrfs-family f2fs-family account"
if installer_selected_class_reference_is_selected addon/cuda-legacy 2>/dev/null; then
  shared_modules="${shared_modules} cuda-legacy"
fi

# Load the validated composite host environment before any late module is
# fetched. Shared modules are sourced directly by the storage-family child
# shell, so their canonical path tokens must be rendered while they are still
# private installer files rather than after a function has already been
# defined with literal placeholder words.
dispatch_host_env="${RUNTIME_DIR}/bootstrap/dispatch-host.env"
installer_fetch_host_env "$seed_base" "$host_profile" "$dispatch_host_env" 0600
# shellcheck disable=SC1090,SC1091
. "$dispatch_host_env"

render_dispatch_asset() {
  dispatch_asset=$1
  dispatch_asset_mode=$2
  if LC_ALL=C grep -q '__INSTALLER_PATH_' "$dispatch_asset"; then
    # The caller supplies the fixed mode used by installer_fetch_file.  Do
    # not probe metadata with the unavailable d-i `stat` applet.
    dispatch_asset_rendered="${dispatch_asset}.path-rendered"
    installer_apply_scalar_placeholders "$dispatch_asset" "$dispatch_asset_rendered" || return 1
    installer_assert_no_unresolved_path_placeholders "$dispatch_asset_rendered" "$dispatch_asset" || return 1
    chmod "$dispatch_asset_mode" "$dispatch_asset_rendered" || return 1
    mv -f -- "$dispatch_asset_rendered" "$dispatch_asset" || return 1
  else
    dispatch_asset_probe_status=$?
    [ "$dispatch_asset_probe_status" = 1 ] || return 1
  fi
}

late_dispatch_module_source() {
  case "$1" in
    core) late_dispatch_selector=FILE_LATE_CORE ;;
    target-assets) late_dispatch_selector=FILE_LATE_TARGET_ASSETS ;;
    iocost) late_dispatch_selector=FILE_LATE_IOCOST ;;
    volatile-storage) late_dispatch_selector=FILE_LATE_VOLATILE_STORAGE ;;
    storage-maintenance) late_dispatch_selector=FILE_LATE_STORAGE_MAINTENANCE ;;
    mullvad) late_dispatch_selector=FILE_LATE_MULLVAD ;;
    templates) late_dispatch_selector=FILE_LATE_TEMPLATES ;;
    network) late_dispatch_selector=FILE_LATE_NETWORK ;;
    network-sharing) late_dispatch_selector=FILE_LATE_NETWORK_SHARING_SH ;;
    grub) late_dispatch_selector=FILE_LATE_GRUB ;;
    security) late_dispatch_selector=FILE_LATE_SECURITY ;;
    dbus-broker) late_dispatch_selector=FILE_LATE_DBUS_BROKER ;;
    podman) late_dispatch_selector=FILE_LATE_PODMAN ;;
    zram-swap) late_dispatch_selector=FILE_LATE_ZRAM_SWAP ;;
    btrfs-family) late_dispatch_selector=FILE_LATE_BTRFS_FAMILY ;;
    f2fs-family) late_dispatch_selector=FILE_LATE_F2FS_FAMILY ;;
    account) late_dispatch_selector=FILE_LATE_ACCOUNT ;;
    cuda-legacy) late_dispatch_selector=FILE_LATE_CUDA_LEGACY ;;
    *) installer_fatal "unsupported shared late module: ${1:-unset}" ;;
  esac
  installer_repo_file_value "$late_dispatch_selector"
}

installer_fetch_file "$seed_base" "$shared_hook_path" "$shared_hook_dest" 0644
install -d -m 0700 "$shared_module_dir"
for shared_module in $shared_modules; do
  installer_operation_context_repo FILE_LATE_DISPATCH 98 "fetch_shared_module:${shared_module}"
  shared_module_source=$(late_dispatch_module_source "$shared_module") || {
    late_dispatch_status=$?
    installer_fatal_status "$late_dispatch_status" \
      "late-dispatch shared module selector resolution failed: module=${shared_module}"
  }
  installer_fetch_file \
    "$seed_base" \
    "$shared_module_source" \
    "${shared_module_dir}/${shared_module}.sh" \
    0644
  render_dispatch_asset "${shared_module_dir}/${shared_module}.sh" 0644
done
install -d -m 0700 "$helper_dir"
case "$hook_family" in
  btrfs|vm)
    installer_operation_context_repo FILE_LATE_DISPATCH 118 "run_btrfs_family_late_command:${hook_family}"
    if INSTALLER_BOOTSTRAP_LIB=$BOOTSTRAP_LIB \
       INSTALLER_LATE_MODULE_DIR=$shared_module_dir \
       SHARED_LATE_COMMAND=$shared_hook_dest \
         /bin/sh -eu -c '. "$SHARED_LATE_COMMAND"; run_btrfs_family_late_command "$@"' sh \
         "$hook_family" "$seed_base" "$host_profile"
    then
      :
    else
      late_dispatch_status=$?
      installer_fatal_status "$late_dispatch_status" \
        "Btrfs-family late command failed: family=${hook_family} profile=${host_profile:-unset}"
    fi
    ;;
  f2fs)
    installer_operation_context_repo FILE_LATE_DISPATCH 133 run_f2fs_family_late_command
    if INSTALLER_BOOTSTRAP_LIB=$BOOTSTRAP_LIB \
       INSTALLER_LATE_MODULE_DIR=$shared_module_dir \
       SHARED_LATE_COMMAND=$shared_hook_dest \
         /bin/sh -eu -c '. "$SHARED_LATE_COMMAND"; run_f2fs_family_late_command "$@"' sh \
         "$seed_base" "$host_profile"
    then
      :
    else
      late_dispatch_status=$?
      installer_fatal_status "$late_dispatch_status" \
        "F2FS-family late command failed: profile=${host_profile:-unset}"
    fi
    ;;
  *)
    installer_fatal "unsupported shared late storage family: ${hook_family}"
    ;;
esac
run_helper_script() {
  helper_path=$1
  helper_dest=$2
  shift 2

  installer_fetch_file "$seed_base" "$helper_path" "$helper_dest" 0755
  render_dispatch_asset "$helper_dest" 0755
  installer_operation_context_repo FILE_LATE_DISPATCH 155 "late_helper:${helper_path}"
  "$helper_dest" "$@" </dev/null
}

run_selected_class_helpers() {
  selected_records_path=$(installer_selected_class_records_path)
  helper_records="${helper_dir}/selected-helpers.tsv"
  helper_sorted="${helper_dir}/selected-helpers.sorted.tsv"
  [ -r "$selected_records_path" ] || return 0
  : >"$helper_records"
  while IFS='|' read -r group_name class_name _class_relpath || [ -n "$group_name" ]; do
    [ -n "$group_name" ] || continue
    helper_name=$(installer_class_meta_value "$seed_base" "$group_name" "$class_name" late_helper)
    [ -n "$helper_name" ] || continue
    helper_order=$(installer_class_helper_order "$seed_base" "$group_name" "$class_name")
    printf '%08d\t%s\t%s\t%s\n' \
      "$helper_order" \
      "$group_name" \
      "$class_name" \
      "$helper_name" >>"$helper_records"
  done <"$selected_records_path"

  [ -s "$helper_records" ] || return 0
  sort -t "$(printf '\t')" -k1,1n -k2,2 -k3,3 "$helper_records" >"$helper_sorted"
  while IFS="$(printf '\t')" read -r _helper_order group_name class_name helper_name || [ -n "${group_name:-}" ]; do
    [ -n "${group_name:-}" ] || continue
    helper_path=$(installer_repo_asset_path DIR_SCRIPTS_LATE "${helper_name}.sh")
    helper_dest="${helper_dir}/${helper_name}.sh"
    run_helper_script "$helper_path" "$helper_dest" "$TARGET_ROOT"
  done <"$helper_sorted"
}

run_selected_class_helpers

installer_fetch_file "$seed_base" "$role_hook_path" "$role_hook_dest" 0755
render_dispatch_asset "$role_hook_dest" 0755
installer_operation_context_repo FILE_LATE_DISPATCH 194 "role_late:${role_hook_path}"
{
  INSTALLER_BOOTSTRAP_LIB=$BOOTSTRAP_LIB \
  INSTALLER_LATE_MODULE_DIR=$shared_module_dir \
    "$role_hook_dest" "$seed_base" "$host_profile"
}
