Combined installer source bundle (format 2)

This archive is flat: d-i/debian contains the complete shared installer snapshot
and compiled catalogs; d-i/forky and d-i/trixie contain the suite sources and
local bootstraps. There are no nested payload archives and no package files.
Select file=${EXTRACTED_ROOT}/d-i/forky/preseed.cfg or the corresponding Trixie
preseed. The bundled bootstrap verifies and copies the sibling Debian source
tree into its private runtime snapshot using payload.manifest and preseed pins.
Normal network publications and authored installer sources are unchanged.

official.json accounts for every pkgsel request and lists exact Debian package
versions, architectures, GLESYS pool URLs, sizes, hashes and dependency fields.
It lists matching repository candidates, not a solved APT transaction or a
transitive dependency lock. Vendor-only/unavailable requests are cross-listed
in http.json. Signed InRelease files and index SHA256 identities are retained;
this generator does not independently verify OpenPGP release signatures.

git.json inventories Git repositories, Git-hosted archives/assets and source
references, including expanded .env profile URLs and their provenance.
http.json inventories other external acquisition URLs and vendor repositories.
Runtime URL templates and latest/discovery endpoints remain explicitly visible
as source references; private repositories still require separate credentials.

The catalogs describe excluded downloads. Package pools, vendor installers,
Git/source archives, model data and other third-party bytes must be supplied
separately before a complete network-free installation. This is not bootable
media and does not add GTK prompts, cache transport for external installers,
or alter suite/profile support policy. SHA256SUMS covers all other members.
