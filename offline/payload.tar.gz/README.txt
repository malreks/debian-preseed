Combined installer source bundle (format 3)

The flat d-i/debian tree contains the shared installer snapshot and compiled
catalogs. Both d-i/forky and d-i/trixie provide local bootstraps and frontend
products. Select file=${EXTRACTED_ROOT}/d-i/forky/preseed.cfg or Trixie.
The bootstrap authenticates the source tree against the manifest/preseed pins.
No nested payload archive, Debian package, udeb or vendor installer is included.

The JSON catalogs use format 3 for APT metadata. A reference with catalog and
id resolves to the entry with that id in packages or source_packages. Package
records contain exact repository URLs, versions, architectures, SHA256 hashes,
sizes, original relationship fields, dependency_links and source_links.
A source record includes every SHA256-listed source file and exact URL.
Request source_candidates link directly to matching source records. requests
contains each request once; pkgsel, installer_requests and base_requests contain
request IDs resolved through official.json requests.
Within each APT catalog, package dependency_links refer to dependency_groups
by key. Context IDs resolve through selection_policy.contexts; each describes
suite, role family, package/native architecture, optional classes and any
explicit release request. selection_links resolve winning pin/priority records
through selection_policy.decisions and selection_policy.pins (source and line).
selection_policy.staging lists the exact installed filenames and source members.
Package source_links refer to the catalog's source_links table by key. Shared
groups retain full candidate references without repeating large provider or
Built-Using lists for every package and installation context.

official.json includes the codebase's pkgsel, anna, base-installer and literal
installer-helper requests and Essential/Protected/required/important base roots,
respecting base exclusions. It exports one selected version/provider for each
request context and one selected branch for each required dependency group.
Only the selected Depends/Pre-Depends closure is exported. Recommends/Suggests
are retained as metadata but not followed: this checkout disables them.
Authored suite/family APT preferences, explicit suite/version requests and Debian
version ordering choose records. Immediate preference files follow the
installer FILE catalog and installed filename order. NVIDIA opt-out, current
and legacy NVIDIA/CUDA policy sets remain separate. Only contexts compatible
with each request's authored class architecture/family are traversed. Base and
udeb requests use their earlier native-suite phase, before target pins exist.
Explicit package/release requests and their required release dependency fallback
are marked separately from normal pin selection. Identical version instances
use authored source order; selecting a higher-priority version does not turn its
dependencies into requests for the same archive. Other repository versions, unrelated udebs, unused
providers and unselected alternative branches are never exported.
This is a union of the codebase's installation contexts, not a SAT solver or a
claim that mutually exclusive roles/hardware choices form one install transaction.
Separate binary-all indexes and published i386 records satisfy all-architecture
packages and explicit foreign-architecture dependencies. Dependency contexts
retain the package architecture and, when different, native_architecture for
:native references. An udeb dependency found only in a normal binary index is
marked binary_index_fallback; its actual deb record and URL remain explicit.
Build-Depends, Built-Using and Static-Built-Using are retained as original
control fields. They do not seed installation roots or additional source records;
every exported source record corresponds to a selected binary. Sources are not built.

vendors.json covers all other APT declarations. Vendor binaries and sources
retain the actual vendor origin URL; dependencies may link to official.json.
Absent source indexes and unavailable exact source versions are explicit.
Unavailable repositories, missing requests and unresolved dependencies remain
visible; inspect complete and bundle.json catalog_complete before preparing media.
HTTPS transport disables proxies, checks redirects and pins public DNS results.
Release signatures are verified only against each declaration's scoped public
keys. Index sizes/SHA256 are checked against that signed release before parsing.
Signing keys are acquired from authored key URLs; no ambient host keyring is used.

git.json retains configured repositories, Git-hosted assets, refs and provenance.
http.json retains other external software acquisitions, including ChatGPT,
Tuta, Filen, Bitwarden, Postman, Discord, Ledger and the other configured apps.
Runtime templates and discovery/latest endpoints remain labeled references.

Catalogs describe downloads to supply separately. GTK/USB media wiring, package
cache acquisition, enrollment credentials and full installation are separate.
SHA256SUMS covers every other archive member. Normal products are untouched.
