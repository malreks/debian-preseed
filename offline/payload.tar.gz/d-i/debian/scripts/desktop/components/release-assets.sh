#!/bin/sh
# Verified release archives used by the desktop role.

desktop_validate_release_pin() {
  release_label=$1
  release_tag=$2
  release_url=$3
  release_sha256=$4
  release_filename=$5

  case "$release_filename:$release_tag" in
    desktop-themes.tar.gz:themes-v[0-9]*.[0-9]*.[0-9]*) ;;
    wallpapers.tar.gz:wallpapers-v[0-9]*.[0-9]*.[0-9]*) ;;
    *) installer_fatal "${release_label} release tag is invalid: ${release_tag:-unset}" ;;
  esac
  case "$release_url" in
    https://*/"${release_tag}"/"${release_filename}") ;;
    *) installer_fatal "${release_label} release URL does not match its configured tag and filename" ;;
  esac
  [ "${#release_sha256}" -eq 64 ] ||
    installer_fatal "${release_label} release SHA-256 must contain 64 hexadecimal characters"
  case "$release_sha256" in
    *[!0123456789abcdef]*)
      installer_fatal "${release_label} release SHA-256 is not lowercase hexadecimal" ;;
  esac
}

desktop_download_release_archive() (
  set -eu
  release_label=$1
  release_tag=$2
  release_url=$3
  release_sha256=$4
  release_filename=$5
  destination=$6
  maximum_bytes=$7

  desktop_validate_release_pin "$release_label" "$release_tag" "$release_url" \
    "$release_sha256" "$release_filename"
  case "$maximum_bytes" in
    ''|*[!0123456789]*|0) installer_fatal "${release_label} release byte limit is invalid" ;;
  esac
  # The role runs in a fresh shell. Repository/module fetches load their
  # transport in subshells, so use the public API that loads it for this call.
  installer_fetch_url "${release_url%/*}" "${release_url##*/}" "$destination" 0600 ||
    installer_fatal "failed to download ${release_label} release archive"
  [ -f "$destination" ] && [ ! -L "$destination" ] ||
    installer_fatal "downloaded ${release_label} release archive is not a regular file"

  release_bytes=$(wc -c <"$destination" 2>__INSTALLER_PATH_DIR_DEV__/null || true)
  release_bytes=${release_bytes##* }
  case "$release_bytes" in
    ''|*[!0123456789]*|0) installer_fatal "${release_label} release archive size is invalid" ;;
  esac
  [ "$release_bytes" -le "$maximum_bytes" ] ||
    installer_fatal "${release_label} release archive exceeds ${maximum_bytes} bytes"
  release_actual_sha256=$(sha256sum "$destination" | awk '{print $1}')
  [ "$release_actual_sha256" = "$release_sha256" ] ||
    installer_fatal "${release_label} release archive SHA-256 mismatch"
  desktop_log "downloaded_verified_release label=${release_label} tag=${release_tag} bytes=${release_bytes} sha256=${release_sha256}"
)
